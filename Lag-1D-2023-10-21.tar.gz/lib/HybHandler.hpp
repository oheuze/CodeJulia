#ifndef _HybHandler_ 
#define _HybHandler_ 

#include <iostream> 
#include <fstream>
#include <map>
#include <math.h>
#include "SAXHandler.hpp"
#include <vector>  
#include "EoS.hpp"
#include "Box.h" 
#include "ZoneParam.h" 
#include "ZoneGeom.h" 
#include "PointXY.h" 
#include "BiPoint.h" 
using namespace std;

class HybHandler : public SAXHandler {

protected:

public:
	vector <ZoneParam> zonesP; 
	vector <ZoneGeom>  zonesG; 
	string element,atts,chaine,argument,biZone,listCases,strBox; 
	BiPoint bip,bipc;
	vector <BiPoint> bips; 
	map <string,string> attributs;
	int nZ,nz1,nz2;
	ofstream ficPts;
	
	int nV,nE; 
	double Vmin,Vmax,Emin,Emax,Punit,Vunit,Eunit; 
	std::string nom,Vscale,Escale; 
	Box boxIJ;
	vector < vector <Box>  > grille;
	vector <EoS*> eoz;

	void StartDocument();
	void StartElement(string Element,map <string,string>  Attributs);
	void EndElement(string Element);
	void Characters(string CaracStr);
	void EndDocument();
	
	string 	recupString(std::string motClef,map <string,string> Attr);
	int  	recupInt   (std::string motClef,map <string,string> Attr);
	double 	recupDouble(std::string motClef,map <string,string> Attr);
	string trim(string str);
};

#endif
