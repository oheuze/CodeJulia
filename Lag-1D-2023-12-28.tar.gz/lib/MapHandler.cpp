#include "MapHandler.hpp"
	
void  MapHandler::StartDocument(){
	if (details) cout << "Début Lecteur XML->map"  << endl;
} 

void  MapHandler::StartElement(string Element,map <string,string> Attributs){
	if (details) cout << "Début Element(" << Element << ")" << endl ;
	parametres=Attributs;
	if (Element==(string)"Materiau"){ 
		nom= recupString( (string) "nom" ,Attributs); 
		if (details) cout << "	Matériau : " << nom	<< endl;
	} ;
	if (Element==(string)"Parametres"){ 
		parametres=Attributs; 
		if (details) cout << "	" << parametres.size() << " paramètres lus ." << endl;
	} ;
}

void  MapHandler::EndElement(string Element){
	if (details) cout << "Fin Element   : " << Element  << endl;
}

void MapHandler::Characters(string CaracStr){
	argument = trim(CaracStr);	
	if (details) if ( argument.size()>0 ) cout << "#	Argument : " << argument  << endl;
}

void  MapHandler::EndDocument(){	
	if (details) cout << "Fin Lecteur XML->map "  << endl;
}

string MapHandler::recupString(string motClef,map <string,string> Attributs) { 
	string valStr = Attributs[motClef]; 
	string valeur;
	if ( valStr.size()>1 ) {valeur = valStr.substr(0,valStr.size());} else { valeur=""; };
	return valeur; 
} 

int MapHandler::recupInt(string motClef,map <string,string> Attributs) { 
	string valStr = Attributs[motClef];
	int valeur;
	if ( valStr.size()>1 ) {valeur = (int) stoi( valStr.substr(0,valStr.size()) );} else { valeur=0; };  
	return valeur; 
} 

double MapHandler::recupDouble(string motClef,map <string,string> Attributs) { 
	string valStr = Attributs[motClef];
	double valeur;
	if ( valStr.size()>1 ) {valeur = stod(valStr.substr(0,valStr.size()));} else { valeur=0; }; 
	return valeur; 
} 

string  MapHandler::trim(string str){
	while( 	str.find(" ") ==0 || str.find("\n")==0  || 
		str.find("\t")==0  ) str=str.substr(1,str.size());
	string last=str.substr(str.size(),str.size());
	while( last.compare(" ")==0 || last.compare("\n")==0  || last.compare("\t")==0  ) 		
			str=str.substr(0,str.size()-1);
	return str;
}


