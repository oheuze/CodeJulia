#include "LecteurMap.hpp" 
	
LecteurMap::LecteurMap(){ 
	//cout <<" Appel de LecteurMap "<< endl;
} 

LecteurMap::~LecteurMap(){} 

void LecteurMap::ecrire(){ 
	//	cout <<" { ( "<< pt1.x <<" , "<< pt1.y <<" ) , ( "<< pt2.x <<" , " << pt2.y <<" ) } "; 
} 

int LecteurMap::LireDonnees(string ficXML) { 
	ParserSAX* parser =new ParserSAX();
	parser->detailed=false;
	MapHandler* handler = new MapHandler();
	parser->InitHandler(handler);
	parser->parse(ficXML);
	parametres = handler->parametres;
	return 0; 
} 
