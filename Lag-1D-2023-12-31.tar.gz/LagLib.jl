#  OH-4/12/2023
using Printf

struct Milieu
	Nom  :: String
	ρ    :: Float64
	u    :: Float64
	e   :: Float64
	xmax :: Float64
	ncells ::Int
	EOSmodel	:: String
	materiau	:: String
end	

struct Cas
	test  		:: String
	nom  		:: String 
	scheme  	:: String 
	ieee_bits  	:: Int
	maxcycle  	:: Int
	riemann  	:: String 
	iterations  	:: Int 
	nghost 		:: Int 
	silent 		:: Int 
	maxtime 	:: Float64 
	cfl 		:: Float64  
	Dt  		:: Float64  
	xmin   		:: Float64 
	bcDeb 		:: String
	bcFin 		:: String
	milieux 	::Vector{Milieu}	
end	

function functions()
	println("
LagLib.jl:
	Initialisation()
 	MemoryAllocation()
	boundaryConditions!(bcDeb, bcFin, ρmat, umat, pmat, cmat, gmat, ideb, ifin, nghost)
	dtCFL(cfl, Dt, dta, x, cmat, ideb, ifin)
	NumericalFluxes!(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)
	cellUpdate!(test, dt, x, X, ustar, pstar, ρmat, umat, emat, Emat, pmat, tmat, cmat, gmat, Smat, ideb, ifin) 
	UpdateCell(ρ,E,u,xm,xM,psm,psM,usm,usM,dt)
	EcriEntrees(OutputFile)
	EcriCas(cas::Cas)
	ExpandCas(cas::Cas)
	Ecritures(OutputFile,time::Float64,x,ρ,u,p,e,t,c,g,ideb::Int,ifin::Int)
	AffMaille(nmin,nmax)
	focus()
	Iteration()
	Run()   
")
end

#######################################################################
# Initialisation
#######################################################################

function Initialisation()
	global test 
	global nom 
	global scheme = "Godunov" 
	global ieee_bits = 64
	global nbcell 
	global maxcycle = 500000
	global riemann = "acoustic" 
	global iterations = 4 
	global nghost=2
	global silent = 0 
	global maxtime = 0 
	global cfl = 0.  
	global Dt = 0  
	global xmin = 0. 
	global ifin
	k=0
	for arg in ARGS 
		k += 1
	        if arg == "--help" || arg == "-h"
			println("")
			println("1D Lagrange hydrocode")
			println("")
			println("Usage:")
			println("")
			println(" -n nom ( pour lancer avec le fichier de données nom.XML )")
			println(" --help")
		end
	        if arg == "-t"			test=ARGS[k+1]	end
	        if arg == "-n"			nom=ARGS[k+1]	end
	end
	ficXML=nom*".xml"
	println("Fichier de données 		: ",pwd(),'/',ficXML)
	global casTest=LireXML(ficXML)
	EcriCas(casTest)
	ExpandCas(casTest)
	#println("Equations d'état : \n\t",tabMat,"\n",)
	cd("../Matériaux");
	global Mats=Vector{Any}(undef, length(tabMat))
	for i=1: length(tabMat)
           commande=Meta.parse("Materiau."*tabMat[i].Modele*"(\""*tabMat[i].Parametres*"\")")
           Mati=eval(commande)
           ficMat=pwd()*"/"*tabMat[i].Parametres
           if isfile(ficMat)!=true println("Le fichier ",ficMat," n'existe pas.") end
           if (tabMat[i].details=="Oui") Materiau.detailler(Mati)  end
           Materiau.LireDonnees(Mati,ficMat)
           Mats[i]=Mati
	end

	mapSigle=Dict{String,Int}()
	for i=1:length(tabMat)
           get!(mapSigle,tabMat[i].Sigle,i)
	end
	println("Etat initial : ");
	#	Initialisation des milieux et des mailles
	global debMilieu=Vector{Int}(undef, length(cas.milieux))
	global finMilieu=Vector{Int}(undef, length(cas.milieux))
	global milMat=Vector{Any}(undef, length(cas.milieux))
	global EtatInitial=Vector{EtatThermo}(undef, length(cas.milieux))
	ifin=nbcell+nghost
	for i=1:nghost
           	ρmat[i]=cas.milieux[1].ρ
           	umat[i]=cas.milieux[1].u
           	emat[i]=cas.milieux[1].e
        end	
	lasti=nghost
	for i = 1:length(cas.milieux)
           imat = get(mapSigle,cas.milieux[i].materiau,1)
           milMat[i]=Mats[imat]
           debMilieu[i]=lasti+1
           finMilieu[i]=lasti+cas.milieux[i].ncells
           for j=debMilieu[i]:finMilieu[i]
           	ρmat[j]=cas.milieux[i].ρ
           	umat[j]=cas.milieux[i].u
           	emat[j]=cas.milieux[i].e
           end	
           lasti=finMilieu[i]
           EtatInitial[i]=Etat(milMat[i],cas.milieux[i].Nom,cas.milieux[i].ρ,cas.milieux[i].e)
	end
        AffEtats(EtatInitial)
        for i=ifin+1:ifin+nghost
           	ρmat[i]=cas.milieux[length(cas.milieux)].ρ
           	umat[i]=cas.milieux[length(cas.milieux)].u
           	emat[i]=cas.milieux[length(cas.milieux)].e
        end
	cd(dirCas)
	Materiau.calculEtats(milMat[1],1,nghost, pmat, cmat, tmat, gmat, Smat, ρmat, emat)
	for i=1: length(cas.milieux)
		Materiau.calculEtats(milMat[i],debMilieu[i],finMilieu[i], pmat, cmat, tmat, gmat, Smat, ρmat, emat) 
	end
	Materiau.calculEtats(milMat[length(cas.milieux)],ifin+1,ifin+nghost, pmat, cmat, tmat, gmat, Smat, ρmat, emat)
	if length(ficPre)>0
		println("Pré-processing : exécution de ",ficPre)
		println("================================")
		for line in eachline(ficPre)  println(line) end
		println("================================")
		include(dirCas*"/"*ficPre)
	end	
	
	#Couleur=Dict(1=>colorant"navajowhite",2=>colorant"gray",3=>colorant"yellow")
        #      if EOS[i]==modele[j] couleur[i]=Couleur[j];end
        global t=0
        global cycle=0
	println("Fin d'initialisation.")
	println("Pour poursuivre :		Run()		Iteration()	focus()")
	println("	ou	 :		include(\"../DiagMarche.jl\")")
end

######################
# Memory allocations
######################

function MemoryAllocation()
	if ieee_bits == 32
		floatType =Float32
	else
		floatType=Float64
	end
	global x=Vector{floatType}(undef, nbcell+2*nghost)
	global X=Vector{floatType}(undef, nbcell+2*nghost)
	global ρmat=Vector{floatType}(undef, nbcell+2*nghost)
	global umat=Vector{floatType}(undef, nbcell+2*nghost)
	global emat=Vector{floatType}(undef, nbcell+2*nghost)
	global Emat=Vector{floatType}(undef, nbcell+2*nghost)
	global pmat=Vector{floatType}(undef, nbcell+2*nghost)
	global tmat=Vector{floatType}(undef, nbcell+2*nghost)
	global cmat=Vector{floatType}(undef, nbcell+2*nghost)
	global gmat=Vector{floatType}(undef, nbcell+2*nghost)
	global Smat=Vector{floatType}(undef, nbcell+2*nghost)
	global ustar=zeros(nbcell+2*nghost)
	global pstar=zeros(nbcell+2*nghost)
end	


#######################################################################
# Boundary conditions: wall, outflow... for left and right boundaries
#######################################################################

function boundaryConditions!(bcDeb, bcFin, ρmat, umat, pmat, cmat, gmat, ideb, ifin, nghost)
# 	bc deb
	ρmat[ideb-1] = ρmat[ideb];pmat[ideb-1] = pmat[ideb];cmat[ideb-1] = cmat[ideb];gmat[ideb-1]=gmat[ideb]
	if bcDeb == bcMur	umat[ideb-1] = -umat[ideb];	end	
	if bcDeb == bcLibre 	umat[ideb-1] = umat[ideb];	end
# 	bc fin
	ρmat[ifin+1] = ρmat[ifin]; pmat[ifin+1] = pmat[ifin];cmat[ifin+1] = cmat[ifin];gmat[ifin+1]=gmat[ifin]
	if bcFin == bcMur	umat[ifin+1] = -umat[ifin]; 	end
	if bcFin == bcLibre	umat[ifin+1] = umat[ifin];	end
end

########################################################
# Time step computation (loop on cells, CFL condition)
########################################################

function dtCFL(cfl, Dt, dta, x, cmat, ideb, ifin)
	dt = 1.e99   
	for i in ideb:ifin
		dt = min(dt, (x[i+1]-x[i])/cmat[i])
	end
	if dta == 0  # First cycle 
		if Dt != 0
			return Dt
		else
			return cfl*dt
		end
	else
		return min(cfl*dt, 1.05*dta)   # CFL condition and maximum increase per cycle of the time step
	end
end

####################
# Numerical fluxes
####################


function NumericalFluxes!(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	if riemann == "strong-shock_Dukowicz" || riemann == "weak-shock_Dukowicz"
		RiemannDukowicz(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

       	elseif riemann  == "exact_Godunov" || riemann == "two-shock_Godunov" || riemann == "two-rarefaction_Godunov"
		RiemannGodunov(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann  == "Despres"    # 1-state acoustic solver (Després)
		RiemannDespres(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann == "acoustic"    # 2-state acoustic solver (Godunov)
		RiemannAcoustic(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann == "one-iteration_acoustic"
		RiemannItAcoustic(riemann, 1, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann == "two-iteration_acoustic"
		RiemannItAcoustic(riemann, 2, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann == "three-term_acoustic"
		Riemann3TermsAcoustic(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)
	else
		println("The choice of Riemann solver is not recognized\n")
		exit()
	end
end

#########################################
# Cell update: flux balance + EOS calls
#########################################

function cellUpdate!(test, dt, x, X, ustar, pstar, ρmat, umat, emat, Emat, pmat, tmat, cmat, gmat, Smat, ideb, ifin) 

	Threads.@threads for i in ideb:ifin+1
		X[i] = x[i] + dt*ustar[i]
	end

	Threads.@threads for i in ideb:ifin
		dm = ρmat[i]*(x[i+1]-x[i])
		ρmat[i] = dm/(X[i+1]-X[i])
		umat[i] = umat[i] + dt/dm*(pstar[i]-pstar[i+1])
		Emat[i] = Emat[i] + dt/dm*(pstar[i]*ustar[i]-pstar[i+1]*ustar[i+1])
		emat[i] = Emat[i] - 0.5*umat[i]^2
	end
	
	for i=1: length(cas.milieux)
		Materiau.calculEtats(milMat[i],debMilieu[i],finMilieu[i], pmat, cmat, tmat, gmat, Smat, ρmat, emat) 
	end		

	Threads.@threads for i in ideb:ifin+1
		x[i] = X[i]
	end
end

function UpdateCell(ρ,E,u,xm,xM,psm,psM,usm,usM,dt)
#	UpdateCell(ρmat[im],Emat[im],umat[im],x[im],x[im+1],pstar[im],pstar[im+1],ustar[im],ustar[im+1],dt)
#		 m : maille i
#		 M : maille i+1
#	Entrées  : ρ,E,u,xm,xM,psm,psM,usm,usM,dt
#	Sorties  : ρs,es,us,Xm,XM,
	println(" u   ρ  e  xm  xM ")
	println(u,"   ",ρ,"  ",E - 0.5*u^2,"  ",xm,"  ",xM)
	Xm = xm + dt*usm
	XM = xM + dt*usM
	dm = ρ*(xM-xm)
	ρs = dm/(XM-Xm)
	us = u + dt/dm*(psm-psM)
	Es = E + dt/dm*(psm*usm-psM*usM)
	es = Es - 0.5*us^2
	println(" u  ρ  e  Xm  XM ")
	return us,ρs,es,Xm,XM
end

#########################################
# Output File
#########################################
function EcriEntrees(OutputFile)
	println("Fichier d'entrées : ",OutputFile)
	f = open(OutputFile, "w")
	print(f,"# Entrées	","	\n")
	print(f," test       =  \"", test,"\"	\n")
	print(f," nom	     =  \"", nom,"\"	\n")
	print(f," scheme     =  \"", scheme,"\"	\n")
	print(f," ieee_bits  =  ", ieee_bits,"	\n")
	print(f," nbcell     =  ", nbcell,"	\n")
	print(f," maxcycle   =  ", maxcycle,"	\n")
	print(f," riemann    =  \"", riemann,"\"	\n")
	print(f," iterations =  ", iterations,"	\n")
	print(f," nghost     =  ", nghost,"	\n")
	print(f," silent     =  ", silent,"	\n")
	print(f," maxtime    =  ", maxtime,"	\n")
	print(f," cfl        =  ", cfl,"	\n")
	print(f," Dt         =  ", Dt,"		\n")
	print(f," xmin       =  ", xmin,"	\n")
	print(f," bcDeb      =  \"", bcDeb,"\"	\n")
	print(f," bcFin      =  \"", bcFin,"\"	\n\n")
	print(f," nomdeb      =  \"", nomdeb,"\"	\n")
	print(f," ρdeb      =  ", ρdeb,"	\n")
	print(f," udeb      =  ", udeb,"	\n")
	print(f," edeb      =  ", edeb,"	\n")
	print(f," xseuil      =  ", xseuil,"	\n\n")
	print(f," nomfin      =  \"", nomfin,"\"	\n")
	print(f," ρfin      =  ", ρfin,"	\n")
	print(f," ufin      =  ",ufin,"	\n")
	print(f," efin      =  ",efin,"	\n")
	print(f," xmax      =  ", xmax,"	\n")
	close(f)
end	

function EcriCas(cas::Cas)
	println("Cas : ",cas.nom)
	println("	test : ",cas.test,"	scheme : ",cas.scheme,"	ieee_bits = ",cas.ieee_bits)
	println("	maxcycle = ",cas.maxcycle,"	maxtime  = ",cas.maxtime) 
	println("	riemann  : ",cas.riemann,"	iterations = ",cas.iterations) 
	println("	nghost   = ",cas.nghost,"	silent   = ",cas.silent) 
	println("	cfl 	 = ",cas.cfl,"	Dt  	 = ",cas.Dt,"	xmin   	 = ",cas.xmin) 
	println(" 	bcDeb    :  ",cas.bcDeb," 	bcFin    :  ",cas.bcFin)
	nbcell=0
	for i=1:length(cas.milieux)
		milieu = cas.milieux[i]
		nbcell=nbcell+milieu.ncells
		println("Milieu	",milieu.Nom,
		"	: ρ=",milieu.ρ,"	u= ",milieu.u,"	e= ",milieu.e,
		"	ncells= ",milieu.ncells,
		"	xmax= ",milieu.xmax,
		"	materiau = ",milieu.materiau)
	end	
end	

function ExpandCas(cas::Cas)
	global nom=cas.nom
	global test=cas.test
	global scheme=cas.scheme 
	global ieee_bits=cas.ieee_bits
	global maxcycle=cas.maxcycle
	global riemann=cas.riemann 
	global iterations=cas.iterations 
	global nghost=cas.nghost 
	global silent=cas.silent 
	global maxtime=cas.maxtime 
	global cfl=cas.cfl  
	global Dt=cas.Dt   
	global xmin=cas.xmin 
	global bcDeb=cas.bcDeb
	global bcFin=cas.bcFin
	global jmin=nghost+1
	global nbcell=0
	for i=1:length(cas.milieux)
		nbcell=nbcell+cas.milieux[i].ncells
	end
	println("Total nbcell = ",nbcell);
	
	MemoryAllocation()
	
	for j=1:jmin
		x[j]=xmin
	end

	for i=1:length(cas.milieux)
		milieu = cas.milieux[i]
		Δx=(milieu.xmax-xmin)/(milieu.ncells)
		jmax=jmin+milieu.ncells
		for j=jmin:jmax
			x[j]=xmin+(j-jmin)*Δx
			ρmat[j]=milieu.ρ
			umat[j]=milieu.u
			emat[j]=milieu.e
			Emat[j]=milieu.e+milieu.u^2/2
		end
		xmin=milieu.xmax
		jmin=jmax
	end 		
end	

function Ecritures(OutputFile,time::Float64,x,ρ,u,p,e,t,c,g,ideb::Int,ifin::Int)
	f = open(OutputFile, "w")
	print(f,"#  t = ",time," # # \n")
	for i in ideb:ifin
		print(f, 0.5*(x[i]+x[i+1]), " ", ρ[i], " ", u[i], " ", p[i], " ", 
		e[i], " ", t[i], " ", c[i], " ", g[i], "\n")
	end
	close(f)
	println("file "*OutputFile*" closed")
end

function AffMaille(nmin,nmax)
	println("           x           ρ            u                E             p           c")
	for i=nmin:nmax
		@printf("%i    %8g     %8g     %8g     %12g     %12g    %8g   \n",i,x[i],ρmat[i], umat[i],emat[i],pmat[i],cmat[i])
	end
end

function focus()
       nmaille=[]
       push!(nmaille,finMilieu[1]-2)
       push!(nmaille,"*");       push!(nmaille,finMilieu[1]-1)
       push!(nmaille,"*");       push!(nmaille,finMilieu[1]  )     
       push!(nmaille,"*");       push!(nmaille,debMilieu[2]  )
       push!(nmaille,"*");       push!(nmaille,debMilieu[2]+1)
       push!(nmaille,"*");       push!(nmaille,debMilieu[2]+2)
       P=[]
       push!(P,pmat[finMilieu[1]-2])
       push!(P,pstar[finMilieu[1]-1]);       push!(P,pmat[finMilieu[1]-1])
       push!(P,pstar[finMilieu[1]  ]);       push!(P,pmat[finMilieu[1]  ])     
       push!(P,pstar[debMilieu[2]  ]);       push!(P,pmat[debMilieu[2]  ])
       push!(P,pstar[debMilieu[2]+1]);       push!(P,pmat[debMilieu[2]+1])
       push!(P,pstar[debMilieu[2]+2]);       push!(P,pmat[debMilieu[2]+2])
       u=[]
       push!(u,umat[finMilieu[1]-2])
       push!(u,ustar[finMilieu[1]-1]);       push!(u,umat[finMilieu[1]-1])
       push!(u,ustar[finMilieu[1]  ]);       push!(u,umat[finMilieu[1]  ])     
       push!(u,ustar[debMilieu[2]  ]);       push!(u,umat[debMilieu[2]  ])
       push!(u,ustar[debMilieu[2]+1]);       push!(u,umat[debMilieu[2]+1])
       push!(u,ustar[debMilieu[2]+2]);       push!(u,umat[debMilieu[2]+2])
       ρ=[]
       push!(ρ,ρmat[finMilieu[1]-2])
       push!(ρ," ");       push!(ρ,ρmat[finMilieu[1]-1])
       push!(ρ," ");       push!(ρ,ρmat[finMilieu[1]  ])     
       push!(ρ,"----------");       push!(ρ,ρmat[debMilieu[2]  ])
       push!(ρ," ");       push!(ρ,ρmat[debMilieu[2]+1])
       push!(ρ," ");       push!(ρ,ρmat[debMilieu[2]+2])
       E=[]
       push!(E,emat[finMilieu[1]-2])
       push!(E," ");       push!(E,emat[finMilieu[1]-1])
       push!(E," ");       push!(E,emat[finMilieu[1]  ])     
       push!(E,"----------");       push!(E,emat[debMilieu[2]  ])
       push!(E," ");       push!(E,emat[debMilieu[2]+1])
       push!(E," ");       push!(E,emat[debMilieu[2]+2])
       c=[]
       push!(c,cmat[finMilieu[1]-2])
       push!(c," ");       push!(c,cmat[finMilieu[1]-1])
       push!(c," ");       push!(c,cmat[finMilieu[1]  ])     
       push!(c,"----------");       push!(c,cmat[debMilieu[2]  ])
       push!(c," ");       push!(c,cmat[debMilieu[2]+1])
       push!(c," ");       push!(c,cmat[debMilieu[2]+2])
               𝒢=[]
       push!(𝒢,gmat[finMilieu[1]-2])
       push!(𝒢," ");       push!(𝒢,gmat[finMilieu[1]-1])
       push!(𝒢," ");       push!(𝒢,gmat[finMilieu[1]  ])     
       push!(𝒢,"----------");       push!(𝒢,gmat[debMilieu[2]  ])
       push!(𝒢," ");       push!(𝒢,gmat[debMilieu[2]+1])
       push!(𝒢," ");       push!(𝒢,gmat[debMilieu[2]+2])
       df=DataFrame(n=nmaille,p=P,u=u,ρ=ρ,E=E,c=c,𝒢=𝒢)
       println("cycle=",cycle,"		",finMilieu[1] ,"   --------      ",debMilieu[2])
       println("      		",cas.milieux[1].Nom,"             ",cas.milieux[2].Nom)
       println(df)
end
   
function Iteration()
        boundaryConditions!(bcDeb,bcFin, ρmat, umat, pmat, cmat, gmat, ideb, ifin, nghost)
	dt = dtCFL(cfl, Dt, dta, x, cmat, ideb, ifin) 
	NumericalFluxes!(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)
	cellUpdate!(test, dt, x, X, ustar, pstar, ρmat, umat, emat, Emat, pmat, tmat, cmat, gmat, Smat, ideb, ifin)
	global dta = dt
	global cycle += 1
	global t += dt 
	if silent != 1
		println("Cycle = ", cycle, ", dt = ", dt, ", t = ", t)
        end
end     

function Run()   
	##################
	# Main time loop
	##################
	t1 = time()
	while t < maxtime && cycle < maxcycle
		Iteration()
	end
	t2 = time()
	println(" ")
	println("Time: ", t2 - t1, " seconds")
	println("Grind time: ", (t2 - t1) / (cycle*nbcell)*1.e+6, " microseconds/cell/cycle")
	println(" ")
	#####################
	# Final output file
	#####################	
	Ecritures(nom*".dat",t,x,ρmat,umat,pmat,emat,tmat,cmat,gmat,ideb,ifin)
	println("PostProcessing : exécution de ",ficPost)
	include(dirCas*"/"*ficPost)
	println("Fin de ",test," / ",nom)
	println("Pour poursuivre, exécution de : 		include(\"../PostProcessing.jl\")")
end








