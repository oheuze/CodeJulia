# OH 2/10/2023

helpMat = 	[
	"variable helpMat",
	"Chargement des EE : ",
"       gp  = Materiau.GP(&Gaz Parfait&) ",
"       mgc = Materiau.MGC(&Mie-Grüneisen Complète&) ",
"       bz  = Materiau.Bizarrium(&Bz&) ",
"       hyb = Materiau.Hybride(&Hybride&) ",
" Fonctions  : ",
"       LireDonnees :     Materiau.LireDonnees(bz,&Bz.mat&) ",
"       InitParam   :     Materiau.InitParam(mgc) ",
"       setParam    :     Materiau.setParam(gp,&Gamma&,&1.4&) ",
"       getVal      :     Ko=Materiau.getVal(mgc,&Ko&) ", 
"       ecrire      :     Materiau.ecrire(mgc) ",
"       calculEtats :     Materiau.calculEtats(gp,ideb,ifin,p,c,T,ρ,ε) ",
"       calculEtatsRhoT : Materiau.calculEtatsRhoT(gp,ideb,ifin,p,c,ε,ρ,T) ",
"       calculEtatVE:     Materiau.calculEtatVE(gp,V,E) ",
"       detailler   :     Materiau.detailler(mgc) "
]

helpMat

helpCas = 	[
	"variable helpCas",
	"Lancement d'un cas : ",
	"        ",
	" Fonctions  : ",
	"       "
]

helpCas
