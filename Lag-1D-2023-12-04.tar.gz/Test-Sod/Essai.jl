# reconstitution de l'évolution au voisinage de l'interface
nom="Sod"
include("../Init-Lag.jl")
Eg,Ed=EtatInitial
us,ps = RiemannAcoustique(Eg,0.0,Ed,0.0)
focus()
dt=dtCFL(cfl, Dt, dta, x, cmat, ideb, ifin)
ii=102
uii, ρii, eii, Xim, XiM = UpdateCell(ρmat[ii],Emat[ii],umat[ii],x[ii],x[ii+1],Eg.P,ps,0.0,us,dt)
Eii=Etat(milMat[1],"interface gauche",ρii, eii)
AffEtat(Eii)
jj=ii+1
ujj, ρjj, ejj, Xjm, XjM = UpdateCell(ρmat[jj],Emat[jj],umat[jj],x[jj],x[jj+1],ps,Ed.P,us,0.0,dt)
Ejj=Etat(milMat[2],"interface droite",ρjj, ejj)
AffEtat(Ejj) 
Iteration()
focus()







