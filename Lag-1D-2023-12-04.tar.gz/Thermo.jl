#  3/12/2023
#  U+1D4A2	𝒢	\scrG	Mathematical Script Capital G

using Printf,DataFrames

struct EtatThermo
	Nom :: String
	P :: Float64
	ρ :: Float64
	T :: Float64
	S :: Float64
	E :: Float64
	𝒢 :: Float64	#  dérivée fondamentale
	c :: Float64
	u :: Float64
end

signe=1;

function Etat(Mat,nom::String,ρ::Float64,E::Float64)::EtatThermo
    local P = zeros(Float64, 3)
    local c = zeros(Float64, 3)
    local T = zeros(Float64, 3)
    local 𝒢 = zeros(Float64, 3)
    local S = zeros(Float64, 3)
    local r= ones(Float64, 3).* ρ
    local e= ones(Float64, 3).* E
    Materiau.calculEtats(Mat,1,2,P,c,T,𝒢,S,r,e)
    return EtatThermo(nom,P[2],ρ,T[2],S[2],E,𝒢[2],c[2],0)
end

function EtatDyn(Mat,nom::String,ρ::Float64,E::Float64,u::Float64)::EtatThermo
    local P = zeros(Float64, 3)
    local c = zeros(Float64, 3)
    local T = zeros(Float64, 3)
    local 𝒢 = zeros(Float64, 3)
    local S = zeros(Float64, 3)
    local r= ones(Float64, 3).* ρ
    local e= ones(Float64, 3).* E
    Materiau.calculEtats(Mat,1,2,P,c,T,𝒢,S,r,e)
    return EtatThermo(nom,P[2],ρ,T[2],S[2],E,𝒢[2],c[2],u)
end

function AffEtat(etat::EtatThermo)
	@printf(" %20s  ρ = %8g E= %12g P= %12g T= %8g  S=  %12g  c=  %8g  𝒢=  %6g  u=  %6g \n",etat.Nom,etat.ρ,etat.E,etat.P,etat.T,etat.S,etat.c,etat.𝒢,etat.u)
end

function AffEtats(etats::Vector{EtatThermo})
	nom=Vector{String}(undef,length(etats));
	P=Vector{Float64}(undef,length(etats));
	ρ=Vector{Float64}(undef,length(etats));
	E=Vector{Float64}(undef,length(etats));
	T=Vector{Float64}(undef,length(etats));
	c=Vector{Float64}(undef,length(etats));
	S=Vector{Float64}(undef,length(etats));
	𝒢=Vector{Float64}(undef,length(etats));
	u=Vector{Float64}(undef,length(etats));
	for i in 1:length(etats)
		nom[i]=etats[i].Nom
                P[i]  =etats[i].P
                ρ[i]  =etats[i].ρ 
                E[i]  =etats[i].E        
                T[i]  =etats[i].T       
                c[i]  =etats[i].c        
                S[i]  =etats[i].S        
                	𝒢[i]  =etats[i].𝒢          
                u[i]  =etats[i].u      
	end         
	dfE=DataFrame(nom=nom,P=P,ρ=ρ,E=E,T=T,c=c,S=S,𝒢=𝒢,u=u)
	println(dfE)
end

function Hugoniot(Mat,Nom::String,Pole::EtatThermo,ρ::Float64)	
	#	pour une EE Mie-Grüneisen
	E1= 0.0
	etat1=Etat(Mat,"etatE1",ρ,E1)
	E2= 1000.0
	etat2=Etat(Mat,"etatE2",ρ,E2)
	Γρ = (etat2.P-etat1.P)/(E2-E1)
	Ph=(etat1.P+Γρ*(Pole.E+Pole.P*(1/Pole.ρ-1/ρ)/2))/(1. - Γρ*(1/Pole.ρ-1/ρ)/2)
	Eh=Pole.E+(Pole.P+Ph)*(1/Pole.ρ-1/ρ)/2
	u=Pole.u+signe*sqrt((Ph-Pole.P)*(1/Pole.ρ-1/ρ))
	global	D=Pole.u+signe*1/Pole.ρ*sqrt((Ph-Pole.P)/(1/Pole.ρ-1/ρ))
	EtatDyn(Mat,Nom,ρ,Eh,u)
end

function hugoniot(Mat,Pole,uPole,ρ)
	#	pour une EE Mie-Grüneisen
	E1=0.0
	etat1=Etat(Mat,"etatE1",ρ,E1)
	E2=1000.0
	etat2=Etat(Mat,"etatE2",ρ,E2)
	Γρ = (etat2.P-etat1.P)/(E2-E1)
	Ph=(etat1.P+Γρ*(Pole.E+Pole.P*(1/Pole.ρ-1/ρ)/2))/(1. - Γρ*(1/Pole.ρ-1/ρ)/2)
	Eh=Pole.E+(Pole.P+Ph)*(1/Pole.ρ-1/ρ)/2
	u=uPole+sqrt((Ph-Pole.P)*(1/Pole.ρ-1/ρ))
	D=1/Pole.ρ*sqrt((Ph-Pole.P)/(1/Pole.ρ-1/ρ))
	return Ph,Eh,u,D
end

function IsentropeGP(Mat,Pole,uPole,ρ)
	#	pour un gaz parfait γ=1.4
	#	préciser "signe" avant
	γ=1.4
	Ps=Pole.P*(ρ/Pole.ρ)^γ
	Es = Ps/ρ/(γ-1)
	etatS=Etat(Mat,"Is",ρ,Es)
	u=uPole+signe*(etatS.c-Pole.c)/(Pole.𝒢-1)
	return Ps,Es,u
end

function Isentrope(Mat,Nom::String,Pole::EtatThermo,ρ::Float64)
	#  cas général
	#	préciser "signe" avant
	global Es=Pole.E
	for i=1:6	
	    is=Etat(Mat,"Is1",ρ,Es)
	    dS=is.S-Pole.S
	    Es=Es-is.T*dS
	end
	etatS=Etat(Mat,"Is",ρ,Es)  
	#  calcul de u : du = c/ρ dρ .On intègre par la méthode de Simpson.
	n=5;
	h=(ρ-Pole.ρ)/n
	csurρ = [ Pole.c/Pole.ρ for i in 1:2*n+1 ]
	csurρ[2*n+1]= etatS.c/etatS.ρ
	Es=Pole.E
	for i in 2:2*n
        	ρi= ((i-1)*etatS.ρ+(2*n-i)*Pole.ρ)/(2*n-1)
		for i=1:6	
			global isi=Etat(Mat,"Isi",ρi,Es)
			dS=isi.S-Pole.S
			Es=Es-isi.T*dS
		end
		csurρ[i]= isi.c/isi.ρ
	end;
	#	Méthode de Simpson
	du = h/6*(csurρ[1]+csurρ[2*n+1]);
	for j in 1:n-1 du+= h/6*2*csurρ[2*j+1] end
	for j in 1:n   du+= h/6*4*csurρ[2*j]   end
	u=Pole.u+signe*du
	return EtatDyn(Mat,Nom,ρ,Es,u)
end  

function Isentrope2(Mat,Nom::String,Pole::EtatThermo,ρ::Float64)
	#  cas général
	#	préciser "signe" avant
	global Es=Pole.E
	for i=1:6	
	    is=Etat(Mat,"Is1",ρ,Es)
	    dS=is.S-Pole.S
	    Es=Es-is.T*dS
	end
	etatS=Etat(Mat,"Is",ρ,Es)  
	#  calcul de u à partir d'un développement logarithmique d'ordre 4
	x1=log(etatS.ρ/Pole.ρ)
	du=(Pole.c+etatS.c)*x1/2+(Pole.c*(Pole.𝒢-1)-etatS.c*(etatS.𝒢-1))*x1*x1/12
	u=Pole.u+signe*du
	return EtatDyn(Mat,Nom,ρ,Es,u)
end  

function Isentrope4(Mat,Nom::String,Pole::EtatThermo,ρ::Float64)
	#  cas général
	#	préciser "signe" avant
	global Es=Pole.E
	for i=1:6	
	    is=Etat(Mat,"Is1",ρ,Es)
	    dS=is.S-Pole.S
	    Es=Es-is.T*dS
	end
	etatS=Etat(Mat,"Is",ρ,Es)  
	#  calcul de u à partir d'un développement logarithmique d'ordre 4
	x1=log(etatS.ρ/Pole.ρ)
	a1 = Pole.𝒢-1
	a2 = ( Pole.c *(- 3 - 2*x1*(-1 + Pole.𝒢 )) + etatS.c *(3 + x1 - x1 *etatS.𝒢 ) )/(Pole.c* x1^2);
	a3 = ( Pole.c *(2 + x1 *(- 1 + Pole.𝒢 )) + etatS.c *(- 2 + x1* (- 1 + etatS.𝒢 ))) /( Pole.c* x1^3);
	d00 = 1 + 2*a1^2 + 24*a2^2 + a2*(4 - 240*a3) - 2*a1*(1 + 6*a2 -24*a3) -12*a3 + 720*a3^2 ;
	d01 = - 2*(a1^2 + a1*(-1 -6*a2 + 24*a3) + 2*(a2 + 6*a2^2 -60*a2*a3 + 3*a3*(-1+ 60*a3 )));
	d02 = a1^2 - 6*a1*(a2 - 4*a3)           + 2*(a2 + 6*a2^2 -60*a2*a3 + 3*a3*(-1+ 60*a3));
	d03 = 2*(- 2 *a2^2 + a1 *(a2 - 4*a3) + a3 + 20*a2*a3 -60*a3^2 );
	d04 = a2^2 - 10*a2*a3 + 2*a3*(a1 + 15*a3 );
	d05 = 2*(a2 - 3*a3 )*a3;
	d06 = a3^2 ;
	x2=x1*x1
	x3=x2*x1
	x4=x3*x1
	x5=x4*x1
	x6=x5*x1
	x7=x6*x1
	x8=x7*x1
	d0  = - d00 + exp(x1)*(d00 + d01*x1 + d02*x2 + d03*x3 + d04*x4 + d05 *x5 + d06*x6 ) 
	d10 = 24* (1 - 5* a1 + 30* a2 - 210 *a3 );
	d15 = a1 - 6 *a2 + 42 *a3;
	d16 = a2 - 7* a3;
	d17 = a3;
	d1  = - 2 *d10 + 2*exp(x1)*(d10 - d10*x1 + d10*x2/2 - d10*x3/6 + d10*x4/24  + d15*x5 + d16*x6 + d17*x7 ) 
	d2  = -40320 + exp(x1)*(40320 - 40320*x1 + 20160*x2 - 6720*x3 + 1680*x4 - 336*x5 + 56*x6 - 8*x7 + x8 ) 
	W=  etatS.P/ (Pole.ρ* Pole.c^2)
	delta= d1^2 - 4*(d0 - W)* d2
	print("delta=",delta)
	a4p  = (-d1+ sqrt(delta) )/(2* d2)
	a4m  = (-d1- sqrt(delta) )/(2 *d2)
	print("a4p=",a4p,"	a4m=",a4m)
	a4=a4p	# Attention : c'est peut-être l'autre solution a4m
	B34 = a3^2 - 14* a3* a4 + 56* a4^2 ;
	A234 = 1 + 6 *a2 - 24 *a3 + 120 *a4;
	B234 = a2^2 - 10 *a2 *(a3 - 6 *a4 ) + 30* B34;
	C234 = a2 - 3* a3 + 12* a4;
	A1234 = 2 *(a1 *a2 - 4* a1* a3 + 20 *a1* a4 - 2* B234 );
	B0 = - 2* a1^2 - 4*C234 + 2*a1*A234 -24*B234;
	B1 = a1^2 + 2 *C234 - 3* A1234 ;
	B2 = 2* a3 - 8* a4 + A1234 ;
	B3 = 2* a1* a3 + 2* a4 - 10* a1* a4 - 4* a2^2 + 5* a2* a3 + 5* a2* C234 + 30* B34;
	B4 = 2* a1* a4 + 2* a2* a3 - 12* a2* a4 - 6* B34;
	B5 = 2* a2* a4 + B34;
	B6 = 2* a3* a4 - 8 *a4^2 ;
	B7 = a4^2 ;
	du = x1*(Pole.c + etatS.c)/2 + x2*(Pole.c*(Pole.𝒢-1) - etatS.c*(etatS.𝒢-1) + 2/5*Pole.c*a4*x3)/12;
	u=Pole.u+signe*du
	return EtatDyn(Mat,Nom,ρ,Es,u)
end  


function isentrope(Mat,Pole,uPole,ρ)
	#  cas ~général  dérivée fondamentale ~constante
	global Es=Pole.E
	for i=1:6	
	    is=Etat(Mat,"Is1",ρ,Es)
	    dS=is.S-Pole.S
	    Es=Es-is.T*dS
	end
	etatS=Etat(Mat,"Is",ρ,Es)  
	u=uPole-(etatS.c-Pole.c)/(etatS.𝒢-1)
	return etatS.P,Es,u
end  

function AffHug(Mat,Pole,u0,ρmax)
	x=zeros(10)
	y=zeros(10)
	for i=1:10
		local ρ=Pole.ρ+i*(ρmax-Pole.ρ)/10
		(Ph,Eh,uh,Dh)=hugoniot(Mat,Pole,u0,ρ)
		y[i]=Ph
		x[i]=uh
	end
	#figPu=plot(x,y,xlabel="u (m/s)",ylabel="P (Pa)")
	return p
end

function RiemannAcoustique(EtatG,ug::Float64,EtatD,ud::Float64)
	ρcG = EtatG.ρ*EtatG.c
	ρcD = EtatD.ρ*EtatD.c
	ustar = ( ρcG*ug + ρcD*ud + (EtatG.P - EtatD.P) ) / (ρcG + ρcD)
	pstar = ( ρcD*EtatG.P + ρcG*EtatD.P + ρcG*ρcD*(ug - ud) ) / (ρcG + ρcD)
	println("Acoustic  u* = ", ustar, " p* = " , pstar)   
	return ustar,pstar     		
end

function RiemAcoustic(EtatG::EtatThermo,EtatD::EtatThermo)
	ρcG = EtatG.ρ*EtatG.c
	ρcD = EtatD.ρ*EtatD.c
	ustar = ( ρcG*EtatG.u + ρcD*EtatD.u + (EtatG.P - EtatD.P) ) / (ρcG + ρcD)
	pstar = ( ρcD*EtatG.P + ρcG*EtatD.P + ρcG*ρcD*(EtatG.u - EtatD.u) ) / (ρcG + ρcD)
	println("Acoustic  u* = ", ustar, " p* = " , pstar)   
	return ustar,pstar     		
end

function RiemannExact(MatG,EtatG::EtatThermo,MatD,EtatD::EtatThermo)
	etatG=EtatG
	etatD=EtatD
	for i in 1:8
		ρcG = etatG.ρ*etatG.c
		ρcD = etatD.ρ*etatD.c
		ustar = ( ρcG*etatG.u + ρcD*etatD.u + (etatG.P - etatD.P) ) / (ρcG + ρcD)
		pstar = ( ρcD*etatG.P + ρcG*etatD.P + ρcG*ρcD*(etatG.u - etatD.u) ) / (ρcG + ρcD)
		ρG = etatG.ρ +(pstar-etatG.P)/etatG.c/etatG.c
		global signe=-1
		if (pstar>EtatG.P)
			etatG=Hugoniot(MatG,"G*",EtatG,ρG) 
		else
			etatG=Isentrope(MatG,"G*",EtatG,ρG)
		end	
		ρD = etatD.ρ +(pstar-etatD.P)/etatD.c/etatD.c	
		global signe=1
		if (pstar>EtatD.P)
			etatD=Hugoniot(MatD,"D*",EtatD,ρD) 
		else
			etatD=Isentrope(MatD,"D*",EtatD,ρD)
		end 
	end	
		AffEtats([etatG,etatD])
	return etatG,etatD     		
end

function ChercheSauts(Etat,step)
	etatS=Etat;
	diff=1;Pdeb=1;udeb=1;ρdeb=1;
	for i in 1:20; AffEtat(etatS)
		etatH=Hugoniot(bz,"Hug",etatS,etatS.ρ+step);
		ρ0D=sqrt((etatH.P-etatS.P)/(1/etatS.ρ-1/etatH.ρ))
		etatS=Isentrope2(bz,"IsoS",etatS,etatS.ρ+step);
		ρc=etatS.ρ*etatS.c; 
		if (diff*(ρ0D-ρc)<0) 
			println("Changement ρ= ",etatS.ρ,"   ", diff);
			global Pfin=Pdeb;
			global ufin=udeb;
			global ρfin=ρdeb;
			Pdeb=etatS.P;
			udeb=etatS.u;
			ρdeb=etatS.ρ;
			println((Pfin-Pdeb)/(ufin-udeb),"    ",ρ0D,"    ",ρc    );
		end
		diff=ρ0D-ρc
	end; 
	println("ρ= ",ρdeb,"  ",ρfin,"   P=",Pdeb,"  ",Pfin,"  u=",udeb," ",ufin);
end
