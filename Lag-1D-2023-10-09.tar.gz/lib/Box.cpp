#include "Box.h" 

Box::Box() 
{ 
	type=0; 
} 

//Mono
Box::Box(std::string ij,int Nz) { 
	type=1;
	strToIJ (ij); 
	nz=Nz; 
} 

//Mixte
Box::Box(std::string ij,int Nz1,int Nz2,BiPoint Bip){
	type=2;
	strToIJ(ij); 
	nz1=Nz1;
	nz2=Nz2;
	bip=Bip;
}

// Multi
Box::Box(std::string ij,vector <ZoneGeom> ZonesG) { 
	type=3;
	strToIJ(ij); 
	zonesG=ZonesG; 
}

Box::~Box () {} 

void Box::strToIJ(std::string ij) { 
	std::string beg="{", mid=",", end="}"; 
	std::string ichar= ij .substr(ij.find(beg)+1,ij.find(mid)-ij.find(beg)-1) ;
	std::string jchar= ij .substr(ij.find(mid)+1,ij.find(end)-ij.find(mid)-1) ;
	i=atoi(ichar.c_str()); 
	j=atoi(jchar.c_str()); 
}  

vector <Box> Box::strToBoxes(int nzone,std::string ListBoxes){
	std::string listBoxes=ListBoxes.substr(1,ListBoxes.length()-2) ;
	vector <Box> vecBox;
	do { 
		int deb= listBoxes.find("{");
		int fin= listBoxes.find("}");
		string caseStr = listBoxes.substr( deb , fin-deb+1 ); 
		listBoxes = listBoxes.substr( listBoxes.find("}")+1 ); 
		Box boxIJ=Box(caseStr,nzone); 
		vecBox.push_back(boxIJ);
	} while ( listBoxes.find("}") < listBoxes.length() ) ; 
	return vecBox;
} 

void Box::ecrire() { 
	cout << "Box (" << i << "," << j << ")   :  ";
	switch(type)
	{
		case 0: cout <<"Vide " << endl;break;
		case 1: cout <<"Mono  ,  zone= "<< nz << endl;break;
		case 2: cout <<"Mixte ,  zones= (" << nz1 <<"," << nz2 << ")  segment= ";bip.ecrire();cout << endl;break;
		case 3: cout <<"Multi ,  zones= ("; 
			for(std::size_t i=0; i<  zonesG.size();i++){ cout << zonesG[i].nz << " , ";}
			cout << ")" << endl;
			for(std::size_t i=0; i<  zonesG.size();i++) zonesG[i].ecrire(); 
			break;	
	}

} 

