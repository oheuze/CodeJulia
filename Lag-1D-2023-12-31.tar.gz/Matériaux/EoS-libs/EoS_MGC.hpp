﻿#ifndef _EoS_MGC_H 
#define _EoS_MGC_H 

#include "EoS.hpp"
#include <cmath>
#include <iostream>

#	OH	19/11/2023

class EoS_MGC : public EoS {	

protected :
	
public:	
	// paramètres EoS_MGC	
	double Ko,No,Γo,Cvr,Po,dPdT,Tmin,Tmax,Pmin,Pmax,Sr,ur;
		
	// grandeurs EoS_MGC	
	double Es,Ps,PsP,eps,epsP,epsS,psi,psiP;
	
	void Potentiel()

	//Potentiel Inversible  -> eps, epsP
	void PotInv(double V)

	//  Température de Debye   Γ*ρ = cste = Γo*ρ0
	void ThetaGamma(double V)

	// fonction Psi  : psi=log <=>  Cv= cste	
	void Psi(double u)
};

// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_MGC(Parametres);	}
extern "C" void destroy(EoS* p) {	delete p;	}

#endif
