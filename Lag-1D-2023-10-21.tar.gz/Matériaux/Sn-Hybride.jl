# OH 25/04/2023
using Plots,DataFrames,CSV

include("./MateriauJ.jl")

Sn3Ph = Materiau.Hybride("Sn-thèse-24x35.xml")
Materiau.LireDonnees(Sn3Ph,"Sn-thèse-24x35.xml")
# Materiau.InitParam(Sn3Ph)

# CSV.read("Sn-VE.pts",DataFrame;comment="#")
df = DataFrame(CSV.File("Sn-VE.pts";comment="#"))
rename!(df,[:V,:Z,:E])
Vi=df[:,1]
Ei=df[:,3]
for i in 1:Int((nrow(df)-1)/2)
	Vz = [ Vi[2*i] , Vi[2i+1] ]
	Ez = [ Ei[2*i] , Ei[2i+1] ]
	plot!(Vz,Ez,legend=false)
end
# scatter!(Vi,Ei)

ρ = [7287.0,8307.78,7227.42,7571.96 ,12884.4 , 8465.82,12618.8, 7674.96 ,7042.85,7450.46];
ε = [0, 51821.2,46660.4,59357.9 , 1727490.0 , 87301.3 , 2113710.0, 90466.3 , 107411.0, 120314.0];
N=length(ρ);
p = zeros(Float64, N);
c = zeros(Float64, N);
T = zeros(Float64, N); 
g = zeros(Float64, N); 
S = zeros(Float64, N); 
Materiau.calculEtats(Sn3Ph,1,N,p,c,T,g,S,ρ,ε)
p10=p
T10=T;
c10=c;

V =  [ 1000000 / ρ[i] for i = 1:N ]
E =  [ ε[i] for i = 1:N ]
VE = [ (1000000 / ρ[i], ε[i]) for i = 1:N ]
scatter!(V,E)

Materiau.calculEtatVE(Sn3Ph,135.e-6,0)
Materiau.calculEtatVE(Sn3Ph,120e-6,150000)
Materiau.calculEtatVE(Sn3Ph,130e-6,500000)
Materiau.calculEtatVE(Sn3Ph,130e-6, 80000)
Materiau.calculEtatVE(Sn3Ph,135e-6, 100000)
Materiau.calculEtatVE(Sn3Ph,130e-6, 130000)
Materiau.calculEtatVE(Sn3Ph,132e-6, 100000)

ρ7 = [7407.41,8333.33,7692.31,7692.31,7407.41,7692.31,7575.76];
ε7 = [0.,150000.,200000.,80000.,100000.,130000.,100000.];
n=length(ρ7);
p7 = zeros(Float64, n);
c7 = zeros(Float64, n);
T7 = zeros(Float64, n); 
g7 = zeros(Float64, n); 
S7 = zeros(Float64, n);
Materiau.calculEtats(Sn3Ph,1,n,p7,c7,T7,g7,S7,ρ7,ε7)
V7 =  [ 1000000 / ρ7[i] for i = 1:n ]
scatter!(V7,ε7,xaxis = ("V", (110,140)),yaxis = ("E", (-50000,250000)))









