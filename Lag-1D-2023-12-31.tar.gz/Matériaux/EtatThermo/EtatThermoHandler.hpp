#ifndef _EtatThermoHandler_ 
#define _EtatThermoHandler_ 

#include <iostream> 
#include <fstream>
#include <map>
#include <math.h>
#include "SAXHandler.hpp"
#include "ParserSAX.hpp"
#include <vector>  
#include "EtatThermo.h"
using namespace std;

class EtatThermoHandler : public SAXHandler {

protected:

public:
	vector <EtatThermo> etatsThermo; 
	std::string mat,nom,element,chaine;
	double ρ,E,P,T,S,c,𝒢; 
	map <string,string> attributs;

	void StartDocument();
	void StartElement(string Element,map <string,string>  Attributs);
	void EndElement(string Element);
	void Characters(string CaracStr);
	void EndDocument();
	
	string 	recupString(std::string motClef,map <string,string> Attr);
	int  	recupInt   (std::string motClef,map <string,string> Attr);
	double 	recupDouble(std::string motClef,map <string,string> Attr);
	string trim(string str);
};

#endif
