//	OH - 24-10-2023

#include "Mat.h"
#include "LecteurHybride.hpp"

//
// MatHybride
//

MatHybride::MatHybride(const std::string material)
{
	if (details) cout << "MatHybride : "  <<  material  << endl ;
	materiau=material;
}

void MatHybride::LireDonnees(std::string nomfic){
	
	int posPt = nomfic.find(".");
	int len = nomfic.size();
	string suffixe = nomfic.substr(posPt+1,len) ;
	if (details) cout << "Suffixe détecté : " <<  suffixe  << endl ;
	LecteurHybride* lec= new LecteurHybride();
	if (details) lec->details=true;
	if (details) cout << "Début de lecture des données (Lecteur Hybride)" << endl ;
	lec->LireDonnees(nomfic);
	if (details) cout << "Fin de lecture des données " << endl ;
	nom	= lec->nom;
	nV	= lec->nV;
	nE	= lec->nE;
	Vmin	= lec->Vmin;
	Vmax	= lec->Vmax;
	Emin	= lec->Emin;
	Emax	= lec->Emax;
	Punit	= lec->Punit;
	Vunit	= lec->Vunit;
	Eunit	= lec->Eunit;
	Vscale	= lec->Vscale;
	Escale	= lec->Escale;
	zonesP  = lec->zonesP;
	grille	= lec->grille;	
	cout << zonesP.size()-1 << " zones. " << endl;
	cout << "Grille " << grille.size() << "x" << grille[1].size() << endl;
	
	cout << " Equations d'état " << endl;
	// chargement des librairies dynamiques (avec leur constructeur et destructeur )   
	//	le destructeur est-il vraiment utile ici ?  
	// Remplissage des équations d'état des zones :
	//vector <EoS*> eoz;
	eoz.push_back(new EoS());
	for(std::size_t i=1; i<  zonesP.size();i++){ 
		map<string,string> parami=zonesP[i].parametres;
		cout << "Zone " << i << "	"<< parami["Nom"] <<"    ";
		void* EoS_Model = openLib(parami["EOS"]);
		create_t*  create_EoSModel = createur(EoS_Model);
		//destroy_t* destroy_EoSModel=destroy(EoS_Model);
		EoS* eos=create_EoSModel(parami); 
		eoz.push_back(eos);
	}
	cout << " Equations d'état chargées." << endl;
	InitParam(); 
	ecrire();
};

void MatHybride::InitParam(){
	map<string,int> mapPh;
	for(std::size_t i=1; i<  zonesP.size();i++) {
		mapPh[zonesP[i].parametres["Nom"]]=i;	
	}
	// mettre plutôt les noms des phases du mélange dans le fichier XML
	for(std::size_t i=1; i<  zonesP.size();i++) if ( zonesP[i].parametres["EOS"]=="Mel" ){
		cout << "Zone " << i << "	"<< zonesP[i].parametres["EOS"]  << "	Mélange ";
		string nomMel = zonesP[i].parametres["Nom"];
		string nomPhA=nomMel.substr(1,nomMel.find(",")-1);
		string nomPhB=nomMel.substr(nomMel.find(",")+2,nomMel.size()-nomMel.find(",")-3);
		int nA=mapPh[nomPhA];
		int nB=mapPh[nomPhB];
		cout << nA << "-" << nB << endl;
		eoz[i]->eosA=eoz[nA];
		eoz[i]->eosB=eoz[nB];
		eoz[i]->eosA->ecrire();
		eoz[i]->eosB->ecrire();
		
		//map<string,string> paramA=zonesP[nA].parametres;
		//void* EoS_Model;
		//create_t*  create_EoSModel;
		//EoS_Model = openLib(paramA["EOS"]);
		//create_EoSModel = createur(EoS_Model);
		//eoz[i]->eosA=create_EoSModel(paramA); 
		//map<string,string> paramB=zonesP[nB].parametres;
		//EoS_Model = openLib(paramB["EOS"]);
		//create_EoSModel = createur(EoS_Model);
		//eoz[i]->eosB=create_EoSModel(paramB); 
	}		
}
	
void MatHybride::ecrire(){
	cout << "==================================================>" << endl;
	cout << "MatHybride : "<< nom << endl; 
	cout << "	Cadre : Vmin = " << Vmin << " , Vmax = " << Vmax ;
	cout <<	" , Emin = "<< Emin << " , Emax = "<< Emax << endl; 
	cout << "	Resolution : nV=" << nV <<" , nE=" << nE << endl; 
	cout << "	" << eoz.size()-1 <<" zones" << endl;
	cout << "	Echelle : Vscale= " << Vscale << " , Escale= " << Escale << endl; 
	cout << "	Unites : P= " << Punit << " V= " << Vunit <<" , E= "<< Eunit << endl; 
	cout << "	"  <<  zonesP.size()-1 << " Zones. " << endl;		
	vector<ZoneParam>::iterator itP;
	for(itP=zonesP.begin(); itP!=zonesP.end(); ++itP) {if ( itP==zonesP.begin() ) ++itP;itP->ecrire();};
//	PointsToFile(eoz.size(),grille);
	cout <<  "Fin de " << nom << "." << endl;
	cout << "<==================================================" << endl;
}

int MatHybride::FindZone(double V,double E){
	int nz=0;
	double v=V/Vunit;
	double e=E/Eunit;
	int i= (int) nV*(v-Vmin)/(Vmax-Vmin)+1;
	int j= (int) nE*(e-Emin)/(Emax-Emin)+1;
	//cout << "		V="<< V <<",	E="<< E<< "	->	";
	//cout << "case("<< i <<","<< j<< ") : ";
	Box boxIJ=grille[i][j];
	switch (boxIJ.type){
		case 0 : ;break; 		//cout << "Vide "
		case 1 : nz=boxIJ.nz;break;	//cout << "Mono ";
		case 2 : if ( ineqPos(v,e,boxIJ.bip) ) {nz=boxIJ.nz1;} else {nz=boxIJ.nz2;};break;				//cout << "Mixte ";
		case 3 : for(std::size_t k=0; k< boxIJ.zonesG.size();k++)
		{
		 ZoneGeom zk=boxIJ.zonesG[k];
		 bool testZone=true;
		 for(std::size_t p=0; p< zk.bips.size();p++){ testZone=testZone && ineqPos(v,e,zk.bips[p]); }
		 if (testZone) nz=zk.nz;
		}  
		break;	// cout << "Multi ";
	}
	// cout << "ρ = " << 1/V << "	V = " << V << "	E = " << E << "	ij=(" << i << "," << j  << ")	zone " << eoz[nz]->nom << endl;
	return nz;
}

bool MatHybride::ineqPos(double V, double E, BiPoint Bip){
	double x1=Bip.pt1.x;
	double y1=Bip.pt1.y;
	double x2=Bip.pt2.x;
	double y2=Bip.pt2.y;
	double det=(V-x1)*(y2-y1)-(E-y1)*(x2-x1);
	return (det>0);  
}

void MatHybride::calculPc(int ideb, int ifin, double* p,double* c, const double* ρ, const double* epsilon) {
	for (int i = ideb-1; i < ifin; i++) {
		double V=1/ρ[i];
		double E=epsilon[i];
		int nz = FindZone(V,E);
		eoz[nz]->calculEtatVE(V,E);
		p[i]= eoz[nz]->P;
		c[i]= eoz[nz]->c;
	}	
}

void MatHybride::calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* g, double* S, 
		 const double* ρ, const double* epsilon) {
	for (int i = ideb-1; i <= ifin-1; i++) {
		double V=1/ρ[i];
		double E=epsilon[i];
		int nz = FindZone(V,E);
		// cout << eoz[nz]->nom << endl; 
		eoz[nz]->calculEtatVE(V,E);
		p[i]= eoz[nz]->P;
		T[i]= eoz[nz]->T;
		c[i]= eoz[nz]->c;
		S[i]= eoz[nz]->S;
		g[i]= eoz[nz]->g;
	}	
}

void MatHybride::calculEtatsρT(int N, double* p, double* c, double* epsilon, 
		const double* ρ, const double* T)
{
	cout  << "Non implémenté  " << endl;
	for (int i = 0; i < N; i++) {
	        p[i] = ρ[i] * R * T[i];
        	c[i] = std::sqrt(γ * p[i] / ρ[i]);
        	epsilon[i] = R * T[i] / (γ - 1.) ;
        }	
}

void MatHybride::calculEtatVE(double v,double e){
	V = v;
	E = e;
	int nz = FindZone(V,E);
	eoz[nz]->calculEtatVE(V,E);
	P = eoz[nz]->P;
	T = eoz[nz]->T;
	c = eoz[nz]->c;
       	// à compléter
       	S=0;
       	g=0;
       	H=E+P*V;
       	F=E-T*S;
       	G=F+P*V; 
        ecrireEtat();       
}
