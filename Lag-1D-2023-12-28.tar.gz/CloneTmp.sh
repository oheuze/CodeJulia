 #!/usr/bin/bash
 
 2058  mkdir /tmp/ZZZ
 2059  cp * /tmp/ZZZ
 2063  cp -r lib  /tmp/ZZZ
 2062  cp -r Matériaux /tmp/ZZZ
 2060  cp -r Test-* /tmp/ZZZ
 2061  cp -r Utilitaires /tmp/ZZZ
 2068  rm /tmp/ZZZ/*/*/*o
 2073  rm /tmp/ZZZ/*/*.png
 2074  rm /tmp/ZZZ/*/*.pdf
