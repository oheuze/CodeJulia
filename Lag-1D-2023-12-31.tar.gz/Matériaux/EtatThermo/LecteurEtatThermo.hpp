#ifndef _LecteurEtatThermo_H 
#define _LecteurEtatThermo_H 

#include <string> 
#include <iostream> 
#include <vector> 
#include "EtatThermo.h"
#include "ParserSAX.hpp"
#include "LecteurDonnees.hpp"
#include "EtatThermoHandler.hpp"

using namespace std;

class LecteurEtatThermo 
{ 
	public: 
	string nom;
	vector <EtatThermo> etats; 
	
	LecteurEtatThermo(); 	
	~LecteurEtatThermo(); 

	int LireDonnees(string ficXML); 
	void ecrire(); 
	
} ; 

#endif 

