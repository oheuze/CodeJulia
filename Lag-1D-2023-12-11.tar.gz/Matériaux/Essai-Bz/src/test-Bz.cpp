﻿#include <iostream>
#include <string>
#include <unistd.h>
#include <filesystem>

#include "Mat.h"  
#include "LecteurXY.hpp" 
using namespace std; 

LecteurXY donneesVE;	

int main (int argc, char* args[]) { 
	if (argc<3) {cout <<" Syntaxe : test-Bz <xxx.xml> <pts.xml>" << endl; };
	if (argc<3) 	{ cout << " Argument manquant"<<endl; } 
		else 	{ cout << " Argument " << (char*)args[1] << " " << (char*)args[2] << endl; }; 
	string dataFile   = (string) args[1]; 
	char* xmlPtsFile = (char*) args[2]; 

	chdir("../../..");
	string pwd = std::filesystem::current_path();
	cout << "Matériau  Bz , Fichier de paramètres: "  <<  pwd << "/" << dataFile  << endl ;
	MatBz materiau=MatBz(dataFile);
	materiau.LireDonnees(dataFile);
//	materiau.ecrire();

	//	CHARGEMENT DES POINTS TESTS
	donneesVE.LireDonnees(xmlPtsFile);
	cout << "Matériau : " << donneesVE.nom << endl;
	vector <PointXY> pointsVE = donneesVE.pointsXY;
	cout << xmlPtsFile << endl; 
	cout << pointsVE.size() << " points." << endl; 
	//cout << "Etats complets ( calculEtatVE) :"<< endl; 
	//for (int i=0; i< (int) pointsVE.size(); i++){
	//	materiau.calculEtatVE( pointsVE[i].x , pointsVE[i].y );
	//}	 
	int n = (int) pointsVE.size();
	double p[n],c[n],T[n],𝒢[n],S[n],ρ[n],E[n];
	for (int i=0; i < n; i++){
		ρ[i]=1/pointsVE[i].x;
		E[i]=pointsVE[i].y;
	}	 
	cout << "Etats complets ( calculEtats) :"<< endl;
	materiau.calculEtats(0,n-1,p,c,T,𝒢,S,ρ,E);
	for (int i=0; i < n; i++){
		cout << i+1 << "	ρ = " << ρ[i]<< "	V = " << 1/ρ[i] << "	E = " << E[i] 
			<< "	P = " << p[i] << "	T = " << T[i] << "	S = " << S[i] 
			<< "	c = " << c[i] << "	𝒢 = " << 𝒢[i] << endl;
	}	 
	cout << "Fin"<< endl; 

	return 0; 
} 

