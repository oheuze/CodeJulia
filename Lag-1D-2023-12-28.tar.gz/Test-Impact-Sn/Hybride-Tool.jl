#	OH-20-11-2023
import Pkg; 
Pkg.activate("../Hybride")
Pkg.activate("../MieGru")
using EzXML, Hybride, MieGru
Sn3Ph = Hybride.Init(Hybride.ParametresHybride("Sn-thèse-24x35.xml"))

# accès au contenu du fichier XM
monxml=EzXML.readxml("Sn-thèse-24x35.xml")
racine=monxml.root	# racine = EosBoxes
println(racine["DateHeure"])	#  attribut
EzXML.elements(racine)
Zones=EzXML.elements(racine)[5]
EzXML.attributes(EzXML.elements(Zones)[1])	# liste des attributs
EzXML.elements(Zones)[1]["Nom"]	#  attribut

println(">	AfficheCase(14,3)")
AfficheCase(14,3)
println(">	getZone(132,90000)")
println(getZone(132,90000))
println(">	Hybride.zones[1][\"ρ0\"]")
println(Hybride.zones[1]["ρ0"])

function nomZone(V,E)
	Hybride.Nom[getZone(132,90000)]
end
println(">	nomZone(132,90000)")
println(nomZone(132,90000))

diagVE=Diag()


