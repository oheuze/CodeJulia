#  OH  - 9/12/2023 
#  include("Solution-Bizarrium.jl")
using DataFrames,Plots

#3ℊ𝐆𝐺𝑮
# 𝒢=U+1D4A2	𝒢	\scrG	Mathematical Script Capital G
# U+1D4D6	𝓖	\bscrG	Mathematical Bold Script Capital G

 
if !@isdefined(Materiau)  include("../MateriauJ.jl") end
if !@isdefined(EtatThermo)  include("../Thermo.jl") end
cd("../Matériaux")
bz = Materiau.Bizarrium("Bz.mat")

Materiau.LireDonnees(bz,"Bz.mat")
cd("../Test-Bizarrium")

# Hugoniot du Bizarrium  ( O = Origine, S = choc, I= Inflexion, M = chgt de pole  )
etats4 = ["O","S","I","M"]
ρ=[1, 1.207221, 1.333115, 1.4343 ]*Materiau.getVal(bz,"ρo")
E = [0, 215555., 447801., 670754.]
N=4
p = zeros(Float64, N);
c = zeros(Float64, N);
T = zeros(Float64, N);
S = zeros(Float64, N);
𝒢 = zeros(Float64, N);
Materiau.calculEtats(bz,0,N-1,p,c,T,𝒢,S,ρ,E)
etatsBz4= DataFrame(nom=etats4,ρ=ρ,E=E,P=p,T=T,c=c,S=S,𝒢=𝒢)
println(etatsBz4)

# Cas test  : Pb de Riemann du Bizarrium
etats8 = ["Y0", "Y1", "Y2", "YZ", "ZY", "Z2", "Z1", "Z0"]
ρ=[1.428571, 1.37594788 , 1.05093, 1.0100384, 1.414977 , 1.2571072 , 1.207221, 1.]*Materiau.getVal(bz,"ρo")
E=[ 4.48657821135e6 , 4.23449658149e6, 2.70089006334e6 , 2.53682071541e6, 609511.01 , 305456.197415 , 215555.256 , 0. ]
u=[ 0 , 1.58878322311e+02 , 1.15425929739e+03 , 1.31912830324e+03 , 1.31912830324e+03 , 1.02492830520e+03 , 9.06590065091e+02 , 250 ]

vec𝒢 = [ 18.5034 , 11.6579 , 1.63092 , 2.02806 , 21.6915 , -5.08851 , -2.21596 , 2.85773 ]

N=8
p = zeros(Float64, N);
c = zeros(Float64, N);
T = zeros(Float64, N);
S = zeros(Float64, N);
𝒢 = zeros(Float64, N);
Materiau.calculEtats(bz,0,N,p,c,T,𝒢,S,ρ,E)
etatsBz8= DataFrame(nom=etats8,ρ=ρ,E=E,P=p,T=T,c=c,S=S,𝒢=𝒢,u=u)
println(etatsBz8)

#
#	Résultats JCP			[V/V0 , rho , p , T , e , S , c , u , D ]
 Wyo=[0.7, 14285.7142857, 1.0e11, 4347.61498896, 4.48657821135e6, 2223.60022067, 5651.47161146, 0.0, 9999.0];
 Wy1=[0.726771712598, 13759.4788386, 9.02744810817e10, 4176.48443099, 4.23449658149e6, 2223.60022067, 3218.62667515, 158.878322311, -3059.74835284, 9999.0];
 Wy2=[0.951530533349, 10509.3842494, 4.6192416483e10, 3009.82131883, 2.70089006334e6, 2233.14931883, 4214.00765023, 1154.25929739, 9999.0];
 Wyz=[0.990063177596, 10100.3655386, 3.91351551833e10, 2840.78876598, 2.53682071541e6, 2233.14931883, 4080.74131794, 1319.12830324, 9999.0];
 Wzy=[0.706725240438, 14149.7705584, 3.91351551833e10, 492.847161357, 609511.010352, 56.5044944451, 4326.61332053, 1319.12830324, 3661.8245979];
 Wz2=[0.795477062357, 12571.0727225, 2.93828326982e10, 422.603617534, 305456.197415, 35.8677842099, 2636.8962927, 1024.9283052, 9999.0];
 Wz1=[0.828348504127, 12072.213507, 2.51154533425e10, 402.271608164, 215555.256788, 35.8677842099, 3168.54447133, 906.590065091, 4075.13453642];
 Wzo=[1.0, 10000.0, 0.0, 300.0, 0.0, 0.0, 3267.26185054, 250.0, 9999.0]
# EtatThermo(Nom, P, ρ, T, S, E, 𝒢 , c, u )
Uyo=EtatThermo("Y0",Wyo[3],Wyo[2],Wyo[4],Wyo[6],Wyo[5],-1,Wyo[7],Wyo[8]);
Uy1=EtatThermo("Y1",Wy1[3],Wy1[2],Wy1[4],Wy1[6],Wy1[5],-1,Wy1[7],Wy1[8]);
Uy2=EtatThermo("Y2",Wy2[3],Wy2[2],Wy2[4],Wy2[6],Wy2[5],-1,Wy2[7],Wy2[8]);
Uyz=EtatThermo("YZ",Wyz[3],Wyz[2],Wyz[4],Wyz[6],Wyz[5],-1,Wyz[7],Wyz[8]);
Uzy=EtatThermo("ZY",Wzy[3],Wzy[2],Wzy[4],Wzy[6],Wzy[5],-1,Wzy[7],Wzy[8]);
Uz2=EtatThermo("Z2",Wz2[3],Wz2[2],Wz2[4],Wz2[6],Wz2[5],-1,Wz2[7],Wz2[8]);
Uz1=EtatThermo("Z1",Wz1[3],Wz1[2],Wz1[4],Wz1[6],Wz1[5],-1,Wz1[7],Wz1[8]);
Uzo=EtatThermo("Z0",Wzo[3],Wzo[2],Wzo[4],Wzo[6],Wzo[5],-1,Wzo[7],Wzo[8]);
etatsJCP=[ Uyo, Uy1, Uy2, Uyz, Uzy, Uz2, Uz1, Uzo];
println("Solution JCP 2009 Heuzé-Jaouen-Jourdren ") 
JCP2009=DataFrame(nom=[etatsJCP[i].Nom for i=1:8],ρ=[etatsJCP[i].ρ for i=1:8],E=[etatsJCP[i].E for i=1:8],P=[etatsJCP[i].P for i=1:8],T=[etatsJCP[i].T for i=1:8],c=[etatsJCP[i].c for i=1:8],S=[etatsJCP[i].S for i=1:8],𝒢=[etatsJCP[i].𝒢  for i=1:8],u=[etatsJCP[i].u  for i=1:8])
println(JCP2009)

function EtatBz(ρ,E,Nom)
           #   paramètres
           ρo=10000. ;  Ko=1e+11  ; Cvo=1000.;  To=300. ; εo=0. ;  
           Γo = 1.5; So=0 ;    s=1.5 ; 
           q=-420808950. / 149411540. ; r =727668333. / 149411540.;
           ρo2=ρo*ρo;
           Γoρo2=Γo*ρo*Γo*ρo;
           #
           x = ρ / ρo  - 1;        
           ε = Γo * (1 - ρo /ρ);  #  formula (4b)
           x2=x*x;
           x3=x2*x;
           f0 = (1+(s/3-2)*x+q*x2+r*x3)/(1-s*x);        #  formula (15b)
           f1 = (s/3-2+2*q*x+3*r*x2+s*f0)/(1-s*x);      #  formula (16a)
           f2 = (2*q+6*r*x+2*s*f1)/(1-s*x);             #  formula (16b)
           f3 = (6*r+3*s*f2)/(1-s*x);                   #  formula (16c)
           f4 = 4*s*f3/(1-s*x);                
           xp12=(1+x)*(1+x);
           xp13=xp12*(1+x);
           Eko = εo - Cvo*To*(1+ε) + 0.5*(Ko/ρo)*x2*f0;     #  Formula (15a) 
           Pko = -Cvo*To*Γo*ρo + 0.5*Ko*x*xp12*(2*f0+x*f1);  #  Formula (17a) 
           p = Pko + Γo * ρo * (E - Eko);    		    #  Formula (5b) 
           Pkp = -0.5*Ko*ρo*xp13 *( 2*(1+3*x)*f0 + 2*x*(2+3*x)*f1 + x2*(1+x)*f2 );       #  Formula (17b)
           Pv  = Γo*ρo*Pko+Pkp;
           ρ2c2= Γo*ρo*(p-Pko)-Pkp;
           c = sqrt( ρ2c2 )/ρ;       #        Formula (8) 
           T = (E-Eko)/Cvo;			 #        Formula (5)		
           S = So-Cvo*ε+Cvo*log((E-Eko)/(Cvo*To));	 #        from Formula (4a)
           xp14=xp13*(1+x);
           xp15=xp14*(1+x);
           Pks = 0.5*Ko*ρo2*xp14 * ( 12*(1+2*x)*f0 + 6*(1+6*x+6*x2)*f1 + 6*x*(1+x)*(1+2*x)*f2 + x2*xp12*f3);      #  Formula (17c)
               	      𝒢 = 1/ρ/2*(Pks+Γoρo2*(p-Pko))/ρ2c2;		      #  Formula (11)	
           return EtatThermo(Nom,p,ρ,T,S,E,𝒢,c,0)
end

function SolveY1Y2(V1, V2)
	#  Résoudre choc de détente (calcul de Vy1 et Vy2 verifiant l'égalité des 3 pentes en diagramme P(u) : tangente à l'isentrope en Y1,  tangente à l'isentrope en Y1, droite de Rayleigh entre Y1 et Y2.
	#  il faut préalablement exécuter etatY0=Y0
	etatY1=Isentrope2(bz,"Y1",etatY0,1/V1)
	Γo = Materiau.getVal(bz,"Γo")
	ρ0 = Materiau.getVal(bz,"ρo")
	Ko = Materiau.getVal(bz,"Ko")
	Cv = Materiau.getVal(bz,"Cvo")
	To = Materiau.getVal(bz,"To")
	Eo = 0
	x = 1. / V2 / ρ0  - 1 
        x2=x*x
        x3=x2*x
	s=1.5 ;q=-420808950. / 149411540. ; r =727668333. / 149411540.;
        f0 = (1+(s/3-2)*x+q*x2+r*x3)/(1-s*x);        #  formula (15b)
        f1 = (s/3-2+2*q*x+3*r*x2+s*f0)/(1-s*x);      #  formula (16a)
        f2 = (2*q+6*r*x+2*s*f1)/(1-s*x);             #  formula (16b)
        f3 = (6*r+3*s*f2)/(1-s*x);                   #  formula (16c)
        f4 = 4*s*f3/(1-s*x);                
        xp12=(1+x)*(1+x);
        xp13=xp12*(1+x);
        #	Ek[V2]
	#	Ek'[V2] =-Pk2
	#	Ek''[V2] = -Ppk2
	#	Ek'''[V2] = -Psk2 
	ΔV = V2-V1;
	Γoρ0 = Γo*ρ0;
	A = 2 + Γoρ0*ΔV
	Ek2 = Eo + Ko / 2 / ρ0 *x*x*f0
	Pk2 = Ko *x *(1 + x)^2* (2*f0 + x*f1) /2
	Ppk2= -Ko*(1 + x)^3 *ρ0*(2*(1+3*x)*f0 + 2*x*(2+3*x)*f1 + x^2*(1+x)*f2) /2
	Psk2= Ko*(1 + x)^4 *ρ0^2*(12*(1+2*x)*f0 + 6*(1+6*x+6*x^2)*f1+ 6*x*(1 + x)*(1 + 2*x)*f2+ x^2*(1+x)^2*f3) /2
	Ppvs1 = - (etatY1.c / V1)^2
	Psvs1 = -2*etatY1.𝒢 / V1* Ppvs1
	Phug2 =     (Γoρ0*(2*etatY1.E + etatY1.P*(V1-V2)+ 2*Cv*To*Γo*(1-V2*ρ0)) -2*Γoρ0*Ek2 + 2*Pk2)/A
	dPhugdV2 = -(Γoρ0*A*Phug2 +(2 + V2*Γoρ0 - V1*Γoρ0)*(Γoρ0*(etatY1.P + 2*Cv*To*Γoρ0) -2*Γoρ0*Pk2-2*Ppk2))/A^2
	E1 = etatY1.E
	P1 = etatY1.P
	Pp1 = Ppvs1	# Ppvs[V1, Syo]
	Ps1 = Psvs1	# Psvs[V1, Syo]
	X0 = Pp1;
	X1 = Ps1;
	#  X == X0 + X1 * dV1;
	Y0 = dPhugdV2
	Y1 = (2* Γoρ0*(-Pp1 + P1*Γoρ0))/A^2 ;
	Y2 = -2*(Γoρ0^2*(2*Γoρ0*ρ0*Ek2 -2*((P1 + E1*Γoρ0)*ρ0 + Cv*To*Γoρ0*(Γoρ0 + 2*ρ0 - V1*Γoρ0*ρ0) -ρ0*(A-1)*Pk2) - ΔV*A*ρ0*Ppk2)-A^2*ρ0*Psk2)/(A^3 *ρ0)
	#  Y == Y0 + Y1 dV1 + Y2 dV2 // Simplify;
	Z0 = (Phug2 - P1) / ΔV;
	Z1 = -2*(P1 + 2*(A-2)*P1 + (A-1)*Pp1*ΔV + Cv*To*Γo^2*ρ0*(V2*ρ0-1) + Γoρ0*(Ek2-E1) + -Pk2)/(ΔV^2*A)
	Z2 = 2*(P1*(2 + A*(A-2)) + Cv*To*Γo^2*ρ0*(-2 + (A-2)*(ΔV*ρ0-2) + 2*V1*ρ0*(A-1)) -2*Pk2 + Γoρ0*(2*(A-1)*(Ek2-E1) +Γo*ΔV^2*ρ0*Pk2) + A*ΔV*Ppk2)/( A^2* ΔV^2)
	# Z = Z0 + Z1 dV1 + Z2 dV2
	det = Y2*(Z1 - X1) + Z2*(X1 - Y1)
	dV1 = (Y2*(X0 - Z0) + Z2*(Y0 - X0))/det
	dV2 = (X1*Y0 - X0*Y1 - X1*Z0 + X0*Z1 + Y1*Z0 - Y0*Z1)/det
	println("dV1= ",dV1,"	dV2=",dV2)
	return (V1 + dV1, V2 + dV2)
end

function Solveρc(Etat,ρc)
#	On cherche l'EtatThermo Sol tel que Sol.ρ*Sol.c=ρc
#	à E donné ? à quoi ça sert ?
#	println("Ecart initial = ",Etat.ρ*Etat.c-ρc)
	EtatA=EtatBz(0.99*Etat.ρ,Etat.E,"A")
	EtatB=EtatBz(1.01*Etat.ρ,Etat.E,"B")
	ρcA=EtatA.ρ*EtatA.c
	ρcB=EtatB.ρ*EtatB.c
	ρ=EtatA.ρ+(ρc-EtatA.ρ*EtatA.c)/(EtatB.ρ*EtatB.c-EtatA.ρ*EtatA.c)*(EtatB.ρ-EtatA.ρ)
	Sol=EtatBz(ρ,Etat.E,"Sol") 
	while ( abs(Sol.ρ*Sol.c-ρc)>1e-6 )
		EtatA=Sol
		ρcA=EtatA.ρ*EtatA.c
		ρ=EtatA.ρ+(ρc-EtatA.ρ*EtatA.c)/(EtatB.ρ*EtatB.c-EtatA.ρ*EtatA.c)*(EtatB.ρ-EtatA.ρ)
		EtatB=Sol
		ρcA=EtatB.ρ*EtatB.c
		ρ=EtatA.ρ+(ρc-EtatA.ρ*EtatA.c)/(EtatB.ρ*EtatB.c-EtatA.ρ*EtatA.c)*(EtatB.ρ-EtatA.ρ)
		Sol=EtatBz(ρ,Etat.E,"Sol") 
#		println(" -> 	",Sol.ρ*Sol.c-ρc)	
	end	
	return Sol
end 
        
Y0=EtatDyn(bz,"Y0",ρ[1],E[1], 0.0)
Z0=EtatDyn(bz,"Z0",ρ[8],E[8], 250.0)

#signe=-1
#Y1=Isentrope2(bz,"Y1",Y0,ρ[2])
#signe=1
#Y2=Hugoniot(bz,"Y2",Y1,ρ[3])

global etatY0=Y0
global Vy1
global Vy2
Vy1,Vy2=SolveY1Y2(7.0e-5,9.e-5)
for i in 1:15
	global Vy1,Vy2=SolveY1Y2(Vy1,Vy2)
end
Vy1,Vy2=SolveY1Y2(Vy1,Vy2)
signe=-1
Y1=Isentrope2(bz,"Y1",Y0,1/Vy1)
signe=1
Y2=Hugoniot(bz,"Y2",Y1,1/Vy2)
#	Vy1 = 0.00007267717086648296`
#	Vy2 = 0.00009515304828436244`
#	ρy1 = 13759.478893240572
#	ρy2 = 10509.384918377664
Dy2=2*u[2]-D
Y1.u-Y1.c
Y2.u-Y2.c
Y1.ρ*Y1.c
Y2.ρ*Y2.c
-(Y1.P-Y2.P)/(Y1.u-Y2.u)

signe=-1
YZ=Isentrope2(bz,"YZ",Y2,ρ[4])

signe=1
Z1=Hugoniot(bz,"Z1",Z0,ρ[7])
Dz1=D
Z1.c+Z1.u

signe=1
Z2=Isentrope2(bz,"Z2",Z1,ρ[6])

ZY=Hugoniot(bz,"ZY",Z2,ρ[5])
Dzy=D
Z2.c+Z2.u

#  Pentes
PentesY1Y2= [ Y2.ρ*Y2.c*Y2.ρ*Y2.c , Y1.ρ*Y1.c*Y1.ρ*Y1.c , -(Y1.P-Y2.P)/(1/Y1.ρ-1/Y2.ρ) ]
PentesZOZ1 = [ Z1.ρ*Z1.c*Z1.ρ*Z1.c , -(Z1.P-Z0.P)/(1/Z1.ρ-1/Z0.ρ) ]
PentesZ2ZY = [ Z2.ρ*Z2.c*Z2.ρ*Z2.c , -(Z2.P-ZY.P)/(1/Z2.ρ-1/ZY.ρ) ]

println("Solution calculée :")
etatsCalcules=[Y0,Y1,Y2,YZ,ZY,Z2,Z1,Z0];
calculs=DataFrame(nom=[etatsCalcules[i].Nom for i=1:8],ρ=[etatsCalcules[i].ρ for i=1:8],E=[etatsCalcules[i].E for i=1:8],P=[etatsCalcules[i].P for i=1:8],T=[etatsCalcules[i].T for i=1:8],c=[etatsCalcules[i].c for i=1:8],S=[etatsCalcules[i].S for i=1:8],𝒢=[etatsCalcules[i].𝒢  for i=1:8],u=[etatsCalcules[i].u  for i=1:8])
println(calculs)

xinterface=0.5
temps=8e-5
ρxt=[ ρ[1] , ρ[1] , ρ[2] , ρ[3] , ρ[4] , ρ[4] , ρ[5] , ρ[5] , ρ[6] , ρ[7] , ρ[8], ρ[8] ]
umarche=[ -7000 ,u[1]-Y0.c ,u[2]-Y1.c , u[3]-Y2.c , u[4]-YZ.c , u[4] ,  u[4] , u[6]+Z2.c , u[6]+Z2.c  , u[7]+Z1.c , u[7]+Z1.c , 5000 ]

#plot(umarche,ρxt)
xx=xinterface*ones(Float64, 12)+umarche*temps
figρxtBz=plot(xx,ρxt,label="solution exacte",title="Bizarrium\nt = "*string(temps),xlabel="x",ylabel="ρ")
savefig("solution-Bz.png")

#  Préparation du fichier .dat
#	il faut doubler certains points car on écrit (x[i]+x[i+1])/2 dans le fichier
##################  Isentropes   ############################################

ns=10
ρs1 = zeros(Float64, ns);ps1 = zeros(Float64, ns);es1 = zeros(Float64, ns);
us1 = zeros(Float64, ns);xs1 = zeros(Float64, ns);
signe=-1
for i in 1:ns
	ρs1[i]=((i-1)*Y1.ρ+(ns-i)*Y0.ρ)/(ns-1)
	etatSi=Isentrope2(bz,"Esi",Y0,ρs1[i])
	ps1[i]=etatSi.P;
	us1[i]=etatSi.u;
	es1[i]=etatSi.E;
	xs1[i]=xinterface+(etatSi.u-etatSi.c)*temps
end	
ρs2 = zeros(Float64, ns);ps2 = zeros(Float64, ns);es2 = zeros(Float64, ns);
us2 = zeros(Float64, ns);xs2 = zeros(Float64, ns);
signe=-1
for i in 1:ns
	ρs2[i]=((i-1)*YZ.ρ+(ns-i)*Y2.ρ)/(ns-1)
	etatSi=Isentrope2(bz,"Esi",Y2,ρs2[i])
	ps2[i]=etatSi.P;
	us2[i]=etatSi.u;
	es2[i]=etatSi.E;
	xs2[i]=xinterface+(etatSi.u-etatSi.c)*temps
end	
ρs3 = zeros(Float64, ns);ps3 = zeros(Float64, ns);es3 = zeros(Float64, ns);
us3 = zeros(Float64, ns);xs3 = zeros(Float64, ns);
signe=+1
for i in 1:ns
	ρs3[i]=((i-1)*Z1.ρ+(ns-i)*Z2.ρ)/(ns-1)
	etatSi=Isentrope2(bz,"Esi",Z1,ρs3[i])
	ps3[i]=etatSi.P;
	us3[i]=etatSi.u;
	es3[i]=etatSi.E;
	xs3[i]=xinterface+(etatSi.u+etatSi.c)*temps
end	
##############################################################

nsol=3*ns+19;
xsol=zeros(Float64, nsol+1);
ρsol=zeros(Float64, nsol+1);
usol=zeros(Float64, nsol+1);
psol=zeros(Float64, nsol+1);
esol=zeros(Float64, nsol+1);
tsol=zeros(Float64, nsol+1);
csol=zeros(Float64, nsol+1);
𝒢sol=zeros(Float64, nsol+1);

global isol=0;
isol+=1;xsol[isol]=xx[isol];ρsol[isol]=Y0.ρ;psol[isol]=Y0.P;usol[isol]=Y0.u;esol[isol]=Y0.E;
isol+=1;xsol[isol]=xx[isol];ρsol[isol]=Y0.ρ;psol[isol]=Y0.P;usol[isol]=Y0.u;esol[isol]=Y0.E;	# doublé
for i in 1:ns	#	isentrope 	Y0->Y1
	global isol+=1;xsol[isol]=xs1[i];ρsol[isol]=ρs1[i];psol[isol]=ps1[i];usol[isol]=us1[i];esol[isol]=es1[i];
end	
isol+=1;xsol[isol]=xx[3];ρsol[isol]=Y1.ρ;psol[isol]=Y1.P;usol[isol]=Y1.u;esol[isol]=Y1.E;
isol+=1;xsol[isol]=xx[3];ρsol[isol]=Y1.ρ;psol[isol]=Y1.P;usol[isol]=Y1.u;esol[isol]=Y1.E; 	# doublé
isol+=1;xsol[isol]=xx[3];ρsol[isol]=Y2.ρ;psol[isol]=Y2.P;usol[isol]=Y2.u;esol[isol]=Y2.E;
isol+=1;xsol[isol]=xx[4];ρsol[isol]=Y2.ρ;psol[isol]=Y2.P;usol[isol]=Y2.u;esol[isol]=Y2.E;
for i in 1:ns	#	isentrope 	Y2->YZ
	global isol+=1;xsol[isol]=xs2[i];ρsol[isol]=ρs2[i];psol[isol]=ps2[i];usol[isol]=us2[i];esol[isol]=es2[i];
end	
isol+=1;xsol[isol]=xx[6];ρsol[isol]=YZ.ρ;psol[isol]=YZ.P;usol[isol]=YZ.u;esol[isol]=YZ.E;
isol+=1;xsol[isol]=xx[6];ρsol[isol]=YZ.ρ;psol[isol]=YZ.P;usol[isol]=YZ.u;esol[isol]=YZ.E;	# doublé
i_interface=isol;
isol+=1;xsol[isol]=xx[7];ρsol[isol]=ZY.ρ;psol[isol]=ZY.P;usol[isol]=ZY.u;esol[isol]=ZY.E;
isol+=1;xsol[isol]=xx[7];ρsol[isol]=ZY.ρ;psol[isol]=ZY.P;usol[isol]=ZY.u;esol[isol]=ZY.E;	# doublé
isol+=1;xsol[isol]=xx[8];ρsol[isol]=ZY.ρ;psol[isol]=ZY.P;usol[isol]=ZY.u;esol[isol]=ZY.E;
isol+=1;xsol[isol]=xx[8];ρsol[isol]=ZY.ρ;psol[isol]=ZY.P;usol[isol]=ZY.u;esol[isol]=ZY.E;	# doublé	
isol+=1;xsol[isol]=xx[ 9];ρsol[isol]=Z2.ρ;psol[isol]=Z2.P;usol[isol]=Z2.u;esol[isol]=Z2.E;	
isol+=1;xsol[isol]=xx[ 9];ρsol[isol]=Z2.ρ;psol[isol]=Z2.P;usol[isol]=Z2.u;esol[isol]=Z2.E;	# doublé
for i in 1:ns	#	isentrope 	Z2 -> Z1
	global isol+=1;xsol[isol]=xs3[i];ρsol[isol]=ρs3[i];psol[isol]=ps3[i];usol[isol]=us3[i];esol[isol]=es3[i];
end	
isol+=1;xsol[isol]=xx[10];ρsol[isol]=Z1.ρ;psol[isol]=Z1.P;usol[isol]=Z1.u;esol[isol]=Z1.E;
isol+=1;xsol[isol]=xx[10];ρsol[isol]=Z1.ρ;psol[isol]=Z1.P;usol[isol]=Z1.u;esol[isol]=Z1.E;	# doublé
isol+=1;xsol[isol]=xx[10];ρsol[isol]=Z0.ρ;psol[isol]=Z0.P;usol[isol]=Z0.u;esol[isol]=Z0.E;
isol+=1;xsol[isol]=xx[10];ρsol[isol]=Z0.ρ;psol[isol]=Z0.P;usol[isol]=Z0.u;esol[isol]=Z0.E;	# doublé
isol+=1;xsol[isol]=1;     ρsol[isol]=Z0.ρ;psol[isol]=Z0.P;usol[isol]=Z0.u;esol[isol]=Z0.E;
isol+=1;xsol[isol]=1;     ρsol[isol]=Z0.ρ;psol[isol]=Z0.P;usol[isol]=Z0.u;esol[isol]=Z0.E;

include("../LagLib.jl")

Ecritures("Solution exacte.dat",temps,xsol,ρsol,usol,psol,esol,tsol,csol,𝒢sol,1,nsol)

#  figure (x,ρ)
figxρ=plot(xsol,ρsol,title="cas test Bizarrium\n t="*string(temps),lc=:blue, lw=2,label="Solution exacte",xlabel="x",ylabel="ρ")
savefig("solution-Bz-ρx.png")
#  figure (ρ,E)
figρE = scatter(ρ,E,title="Bizarrium",label="",xlabel="ρ",ylabel="E")
for i in 1:8
	annotate!(ρ[i],E[i],etats8[i])
end
figρE=plot!([ρsol[i] for i in 1:i_interface ]     ,[esol[i] for i in 1:i_interface ],label="Y")
figρE=plot!([ρsol[i] for i in i_interface+1:nsol ],[esol[i] for i in i_interface+1:nsol ],label="Z")
savefig("solution-Bz-ρE.png")
# figure (u,P)
figPu=scatter(u,p,title="cas test Bizarrium\n  P(u)",lc=:blue, lw=2,label="Solution exacte",xlabel="u",ylabel="P")
for i in 1:8
	annotate!(u[i],p[i],"\n"*etats8[i])
end
figPu=plot!([usol[i] for i in 1:i_interface ]     ,[psol[i] for i in 1:i_interface ],label="Y")
figPu=plot!([usol[i] for i in i_interface+1:nsol ],[psol[i] for i in i_interface+1:nsol ],label="Z")

savefig("solution-Bz-Pu.png")

println(" Figures :	figρE	figxρ	figPu	")

