﻿#include <iostream>
#include <string>
#include <unistd.h>
#include <filesystem>

#include "Mat.h"  
#include "LecteurXY.hpp" 
using namespace std; 


LecteurXY donneesVE;	

int main (int argc, char* args[]) { 
	if (argc<3) cout <<" Syntaxe : Hybride <hyb.xml> <pts.xml>" <<endl; 
	if (argc<3) 	{cout << " Argument manquant"<<endl; } 
		else 	{ cout << " Argument " << (char*)args[1] << " " << (char*)args[2] << endl; }; 
	string xmlFile    = (string) args[1]; 
	char* xmlPtsFile = (char*) args[2]; 

	chdir("..");
	string pwd = std::filesystem::current_path();
	cout << "Matériau  Hybride , Fichier de paramètres: "  <<  pwd << "/" << xmlFile  << endl ;
	std::string mat="Sn-3Ph";
	MatHybride materiau=MatHybride(mat);
	materiau.LireDonnees(xmlFile);
//	materiau.ecrire();

	//	CHARGEMENT DES POINTS TESTS
	donneesVE.LireDonnees(xmlPtsFile);
	cout << "Matériau : " << donneesVE.nom << endl;
	vector <PointXY> pointsVE = donneesVE.pointsXY;
	cout << xmlPtsFile << endl; 
	cout << pointsVE.size() << " points." << endl; 
	cout << "Zones :"<< endl; 
	for (int i=0; i< (int) pointsVE.size(); i++){
		materiau.FindZone( pointsVE[i].x , pointsVE[i].y );
	}	 	 
	cout << "Etats complets :"<< endl; 
	for (int i=0; i< (int) pointsVE.size(); i++){
		materiau.calculEtatVE( pointsVE[i].x , pointsVE[i].y );
	}	 
	cout << "Fin"<< endl; 

	return 0; 
} 

