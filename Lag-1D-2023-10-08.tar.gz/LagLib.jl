#  OH-29/09/2023

struct Milieu
	Nom  :: String
	ρ    :: Float64
	u    :: Float64
	e   :: Float64
	xmax :: Float64
	ncells ::Int
	EOSmodel	::String
	EOSsigle	::String
end	

struct Cas
	test  		:: String
	nom  		:: String 
	scheme  	:: String 
	ieee_bits  	:: Int
	maxcycle  	:: Int
	riemann  	:: String 
	iterations  	:: Int 
	nghost 		:: Int 
	silent 		:: Int 
	maxtime 	:: Float64 
	cfl 		:: Float64  
	Dt  		:: Float64  
	xmin   		:: Float64 
	bcDeb 		:: String
	bcFin 		:: String
	milieux 	::Vector{Milieu}	
end	

#######################################################################
# Initialisation
#######################################################################

function Initialisation()
	global test 
	global nom 
	global scheme = "Godunov" 
	global ieee_bits = 64
	global nbcell 
	global maxcycle = 500000
	global riemann = "acoustic" 
	global iterations = 4 
	global nghost=2
	global silent = 0 
	global maxtime = 0 
	global cfl = 0.  
	global Dt = 0  
	global xmin = 0. 
	global ifin
	k=0
	for arg in ARGS 
		k += 1
	        if arg == "--help" || arg == "-h"
			println("")
			println("1D Lagrange hydrocode")
			println("")
			println("Usage:")
			println("")
			println(" -n nom ( pour lancer avec le fichier de données nom.XML )")
			println(" --help")
		end
	        if arg == "-t"			test=ARGS[k+1]	end
	        if arg == "-n"			nom=ARGS[k+1]	end
	end
	ficXML=nom*".xml"
	println("Fichier de données 		: ",pwd(),'/',ficXML)
	global casTest=LireXML(ficXML)
	EcriCas(casTest)
	ExpandCas(casTest)
	#println("Equations d'état : \n\t",tabEoS,"\n",)
	cd("../Matériaux");
	global EoS=Vector{Any}(undef, length(tabEoS))
	for i=1: length(tabEoS)
           commande=Meta.parse("Materiau."*tabEoS[i].Modele*"(\""*tabEoS[i].Parametres*"\")")
           EoSi=eval(commande)
           Materiau.LireDonnees(EoSi,tabEoS[i].Parametres)
           EoS[i]=EoSi
	end

	mapSigle=Dict{String,Int}()
	for i=1:length(tabEoS)
           get!(mapSigle,tabEoS[i].Sigle,i)
	end
	println("Etat initial : ");
	#	Initialisation des milieux et des mailles
	global debMilieu=Vector{Int}(undef, length(cas.milieux))
	global finMilieu=Vector{Int}(undef, length(cas.milieux))
	lasti=nghost
	global milEoS=Vector{Any}(undef, length(cas.milieux))
	global EtatInitial=Vector{EtatThermo}(undef, length(cas.milieux))
	for i = 1:length(cas.milieux)
           ieos = get(mapSigle,cas.milieux[i].EOSsigle,1)
           milEoS[i]=EoS[ieos]
           debMilieu[i]=lasti+1
           finMilieu[i]=debMilieu[i]+cas.milieux[i].ncells-1
           for j=debMilieu[i]:finMilieu[i]
           	ρmat[j]=cas.milieux[i].ρ
           	umat[j]=cas.milieux[i].u
           	emat[j]=cas.milieux[i].e
           end	
           lasti=finMilieu[i]
           EtatInitial[i]=Etat(milEoS[i],cas.milieux[i].Nom,cas.milieux[i].ρ,cas.milieux[i].e)
           AffEtat(EtatInitial[i])
	end
	ifin=nbcell+nghost
	for i=1:debMilieu[1]-1
           	ρmat[i]=cas.milieux[1].ρ
           	umat[i]=cas.milieux[1].u
           	emat[i]=cas.milieux[1].e
        end	
        for i=ifin+1:ifin+nghost
           	ρmat[i]=cas.milieux[length(cas.milieux)].ρ
           	umat[i]=cas.milieux[length(cas.milieux)].u
           	emat[i]=cas.milieux[length(cas.milieux)].e
        end
	cd(dirCas)
	#	Initialisation de l'équations d'état des mailles
	#	Attention : tous les indices d'appels à Materiau(C++) doivent être décalés de 1
	Materiau.calculEtats(milEoS[1],0,nghost-1, pmat, cmat, tmat, gmat, Smat, ρmat, emat)
	for i=1: length(cas.milieux)
		Materiau.calculEtats(milEoS[i],debMilieu[i]-1,finMilieu[i]-1, pmat, cmat, tmat, gmat, Smat, ρmat, emat) 
	end
	Materiau.calculEtats(milEoS[length(cas.milieux)],ifin,ifin+nghost-1, pmat, cmat, tmat, gmat, Smat, ρmat, emat)
	println("Pré-processing : exécution de ",ficPre)
	include(dirCas*"/"*ficPre)
	
	#Couleur=Dict(1=>colorant"navajowhite",2=>colorant"gray",3=>colorant"yellow")
        #      if EOS[i]==modele[j] couleur[i]=Couleur[j];end
        global t=0
        global cycle=0
	println("Fin d'initialisation.")
end

######################
# Memory allocations
######################

function MemoryAllocation()
	if ieee_bits == 32
		floatType =Float32
	else
		floatType=Float64
	end
	global x=Vector{floatType}(undef, nbcell+2*nghost)
	global X=Vector{floatType}(undef, nbcell+2*nghost)
	global ρmat=Vector{floatType}(undef, nbcell+2*nghost)
	global umat=Vector{floatType}(undef, nbcell+2*nghost)
	global emat=Vector{floatType}(undef, nbcell+2*nghost)
	global Emat=Vector{floatType}(undef, nbcell+2*nghost)
	global pmat=Vector{floatType}(undef, nbcell+2*nghost)
	global tmat=Vector{floatType}(undef, nbcell+2*nghost)
	global cmat=Vector{floatType}(undef, nbcell+2*nghost)
	global gmat=Vector{floatType}(undef, nbcell+2*nghost)
	global Smat=Vector{floatType}(undef, nbcell+2*nghost)
	global ustar=zeros(nbcell+2*nghost)
	global pstar=zeros(nbcell+2*nghost)
end	


#######################################################################
# Boundary conditions: wall, outflow... for left and right boundaries
#######################################################################

function boundaryConditions!(bcDeb, bcFin, ρmat, umat, pmat, cmat, gmat, ideb, ifin, nghost)
# 	bc deb
	ρmat[ideb-1] = ρmat[ideb];pmat[ideb-1] = pmat[ideb];cmat[ideb-1] = cmat[ideb];gmat[ideb-1]=gmat[ideb]
	if bcDeb == bcMur	umat[ideb-1] = -umat[ideb];	end	
	if bcDeb == bcLibre 	umat[ideb-1] = umat[ideb];	end
# 	bc fin
	ρmat[ifin+1] = ρmat[ifin]; pmat[ifin+1] = pmat[ifin];cmat[ifin+1] = cmat[ifin];gmat[ifin+1]=gmat[ifin]
	if bcFin == bcMur	umat[ifin+1] = -umat[ifin]; 	end
	if bcFin == bcLibre	umat[ifin+1] = umat[ifin];	end
end

########################################################
# Time step computation (loop on cells, CFL condition)
########################################################

function dtCFL(cfl, Dt, dta, x, cmat, ideb, ifin)
	dt = 1.e99   
	for i in ideb:ifin
		dt = min(dt, (x[i+1]-x[i])/cmat[i])
	end
	if dta == 0  # First cycle 
		if Dt != 0
			return Dt
		else
			return cfl*dt
		end
	else
		return min(cfl*dt, 1.05*dta)   # CFL condition and maximum increase per cycle of the time step
	end
end

####################
# Numerical fluxes
####################


function NumericalFluxes!(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	if riemann == "strong-shock_Dukowicz" || riemann == "weak-shock_Dukowicz"
		RiemannDukowicz(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

       	elseif riemann  == "exact_Godunov" || riemann == "two-shock_Godunov" || riemann == "two-rarefaction_Godunov"
		RiemannGodunov(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann  == "Despres"    # 1-state acoustic solver (Després)
		RiemannDespres(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann == "acoustic"    # 2-state acoustic solver (Godunov)
		RiemannAcoustic(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann == "one-iteration_acoustic"
		RiemannItAcoustic(riemann, 1, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann == "two-iteration_acoustic"
		RiemannItAcoustic(riemann, 2, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)

	elseif riemann == "three-term_acoustic"
		Riemann3TermsAcoustic(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)
	else
		println("The choice of Riemann solver is not recognized\n")
		exit()
	end
end

#########################################
# Cell update: flux balance + EOS calls
#########################################

function cellUpdate!(test, dt, x, X, ustar, pstar, ρmat, umat, emat, Emat, pmat, tmat, cmat, gmat, Smat, ideb, ifin) 

	Threads.@threads for i in ideb:ifin+1
		X[i] = x[i] + dt*ustar[i]
	end

	Threads.@threads for i in ideb:ifin
		dm = ρmat[i]*(x[i+1]-x[i])
		ρmat[i] = dm/(X[i+1]-X[i])
		umat[i] = umat[i] + dt/dm*(pstar[i]-pstar[i+1])
		Emat[i] = Emat[i] + dt/dm*(pstar[i]*ustar[i]-pstar[i+1]*ustar[i+1])
		emat[i] = Emat[i] - 0.5*umat[i]^2
	end
	
	#	Attention : tous les indices d'appels à Materiau(C++) doivent être décalés de 1
	for i=1: length(cas.milieux)
		Materiau.calculEtats(milEoS[i],debMilieu[i]-1,finMilieu[i]-1, pmat, cmat, tmat, gmat, Smat, ρmat, emat) 
	end		

	Threads.@threads for i in ideb:ifin+1
		x[i] = X[i]
	end
end

#########################################
# Output File
#########################################
function EcriEntrees(OutputFile)
	println("Fichier d'entrées : ",OutputFile)
	f = open(OutputFile, "w")
	print(f,"# Entrées	","	\n")
	print(f," test       =  \"", test,"\"	\n")
	print(f," nom	     =  \"", nom,"\"	\n")
	print(f," scheme     =  \"", scheme,"\"	\n")
	print(f," ieee_bits  =  ", ieee_bits,"	\n")
	print(f," nbcell     =  ", nbcell,"	\n")
	print(f," maxcycle   =  ", maxcycle,"	\n")
	print(f," riemann    =  \"", riemann,"\"	\n")
	print(f," iterations =  ", iterations,"	\n")
	print(f," nghost     =  ", nghost,"	\n")
	print(f," silent     =  ", silent,"	\n")
	print(f," maxtime    =  ", maxtime,"	\n")
	print(f," cfl        =  ", cfl,"	\n")
	print(f," Dt         =  ", Dt,"		\n")
	print(f," xmin       =  ", xmin,"	\n")
	print(f," bcDeb      =  \"", bcDeb,"\"	\n")
	print(f," bcFin      =  \"", bcFin,"\"	\n\n")
	print(f," nomdeb      =  \"", nomdeb,"\"	\n")
	print(f," ρdeb      =  ", ρdeb,"	\n")
	print(f," udeb      =  ", udeb,"	\n")
	print(f," edeb      =  ", edeb,"	\n")
	print(f," xseuil      =  ", xseuil,"	\n\n")
	print(f," nomfin      =  \"", nomfin,"\"	\n")
	print(f," ρfin      =  ", ρfin,"	\n")
	print(f," ufin      =  ",ufin,"	\n")
	print(f," efin      =  ",efin,"	\n")
	print(f," xmax      =  ", xmax,"	\n")
	close(f)
end	

function EcriCas(cas::Cas)
	println("Cas : ",cas.nom)
	println("	test : ",cas.test,"	scheme : ",cas.scheme,"	ieee_bits = ",cas.ieee_bits)
	println("	maxcycle = ",cas.maxcycle,"	maxtime  = ",cas.maxtime) 
	println("	riemann  : ",cas.riemann,"	iterations = ",cas.iterations) 
	println("	nghost   = ",cas.nghost,"	silent   = ",cas.silent) 
	println("	cfl 	 = ",cas.cfl,"	Dt  	 = ",cas.Dt,"	xmin   	 = ",cas.xmin) 
	println(" 	bcDeb    :  ",cas.bcDeb," 	bcFin    :  ",cas.bcFin)
	nbcell=0
	for i=1:length(cas.milieux)
		milieu = cas.milieux[i]
		nbcell=nbcell+milieu.ncells
		println("Milieu	",milieu.Nom,
		"	: ρ=",milieu.ρ,"	u= ",milieu.u,"	e= ",milieu.e,
		"	ncells= ",milieu.ncells,
		"	xmax= ",milieu.xmax,
		"	EOSmodel = ",milieu.EOSmodel,
		"	EOSsigle = ",milieu.EOSsigle)
	end	
end	

function ExpandCas(cas::Cas)
	global nom=cas.nom
	global test=cas.test
	global scheme=cas.scheme 
	global ieee_bits=cas.ieee_bits
	global maxcycle=cas.maxcycle
	global riemann=cas.riemann 
	global iterations=cas.iterations 
	global nghost=cas.nghost 
	global silent=cas.silent 
	global maxtime=cas.maxtime 
	global cfl=cas.cfl  
	global Dt=cas.Dt   
	global xmin=cas.xmin 
	global bcDeb=cas.bcDeb
	global bcFin=cas.bcFin
	global jmin=nghost+1
	global nbcell=0
	for i=1:length(cas.milieux)
		nbcell=nbcell+cas.milieux[i].ncells
	end
	println("Total nbcell = ",nbcell);
	
	MemoryAllocation()
	
	for j=1:jmin
		x[j]=xmin
	end

	for i=1:length(cas.milieux)
		milieu = cas.milieux[i]
		Δx=(milieu.xmax-xmin)/(milieu.ncells)
		jmax=jmin+milieu.ncells
		for j=jmin:jmax
			x[j]=xmin+(j-jmin)*Δx
			ρmat[j]=milieu.ρ
			umat[j]=milieu.u
			emat[j]=milieu.e
			Emat[j]=milieu.e+milieu.u^2/2
		end
		xmin=milieu.xmax
		jmin=jmax
	end 		
end	

function Ecritures(OutputFile,time::Float64,x,ρ,u,p,e,t,c,g,ideb::Int,ifin::Int)
	f = open(OutputFile, "w")
	print(f,"#  t = ",time," # # \n")
	for i in ideb:ifin
		print(f, 0.5*(x[i]+x[i+1]), " ", ρ[i], " ", u[i], " ", p[i], " ", 
		e[i], " ", t[i], " ", c[i], " ", g[i], "\n")
	end
	close(f)
	println("file "*OutputFile*" closed")
end


function AffMaille(nmin,nmax)
	for i=nmin:nmax
		println(i,"    x = ",x[i],"    rho = ",ρmat[i],"   u = ", umat[i],"   e = ",emat[i],"   p = ", pmat[i],"  c  = ",cmat[i])
	end
end

function focus()
	iMin=ifin	
	iMax=ideb
	for i=ideb+5:ifin-5
          if (abs(umat[i]-umat[i-1])<0.001)&&(abs(pmat[i]-pmat[i-1])<100)
          
          else
           if(iMin>i) 
               iMin=i-3;iMax=i+3
           else
              iMax=i+3
           end
          end
	end
	AffMaille(1,5)
	AffMaille(iMin,iMax)
	AffMaille(ifin-4,ifin+1)
	for i=1:5
		println(i,"       u* = ", ustar[i],"    p* = ", pstar[i])
	end
        for i=iMin:iMax
        	println(i,"       u* = ", ustar[i],"    p* = ", pstar[i])
        end
end              

function Iteration()
        boundaryConditions!(bcDeb,bcFin, ρmat, umat, pmat, cmat, gmat, ideb, ifin, nghost)
	dt = dtCFL(cfl, Dt, dta, x, cmat, ideb, ifin) 
	NumericalFluxes!(riemann, iterations, ustar, pstar, ρmat, umat, pmat, cmat, gmat, ideb, ifin)
	cellUpdate!(test, dt, x, X, ustar, pstar, ρmat, umat, emat, Emat, pmat, tmat, cmat, gmat, Smat, ideb, ifin)
	global dta = dt
	global cycle += 1
	global t += dt 
	if silent != 1
		println("Cycle = ", cycle, ", dt = ", dt, ", t = ", t)
        end
end     

function Run()   
	##################
	# Main time loop
	##################
	t1 = time()
	while t < maxtime && cycle < maxcycle
		Iteration()
	end
	t2 = time()
	println(" ")
	println("Time: ", t2 - t1, " seconds")
	println("Grind time: ", (t2 - t1) / (cycle*nbcell)*1.e+6, " microseconds/cell/cycle")
	println(" ")
	#####################
	# Final output file
	#####################	
	Ecritures(nom*".dat",t,x,ρmat,umat,pmat,emat,tmat,cmat,gmat,ideb,ifin)
	println(" ")
	println("PostProcessing : exécution de ",ficPost)
	include(dirCas*"/"*ficPost)

end








