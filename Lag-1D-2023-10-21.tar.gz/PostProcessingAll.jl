#  OH  21/10/2023
using CSV,DataFrames,Plots
test=basename(pwd())
println("PostProcessing du cas de calcul : "*test)
dirfiles=readdir()
global figρx=plot()
for i=1:length(dirfiles)
         global filename=dirfiles[i]
         if (findfirst(".dat",filename)!=nothing)
               global dataname=SubString(filename,1,findfirst(".dat",filename)[1]-1)          
               println(filename," :  ",dataname)
               df = DataFrame(CSV.File(filename;header=1, delim=" "))
               rename!(df,[:x,:ρ,:u,:p,:e,:t,:c,:g])
	       if (findfirst("Solution exacte",filename)!=nothing)
			global figρx = plot!(df.x,df.ρ,xlabel="x",ylabel="ρ (kg/m3)",lc=:black,lw=3,title=test,label=dataname)
		else	               						
			global figρx = scatter!(df.x,df.ρ,xlabel="x",ylabel="ρ (kg/m3)",title=test,label=dataname)
	       end			
         end
end   
savefig(test*"-ρx.png")
savefig(test*"-ρx.pdf")
figρx
