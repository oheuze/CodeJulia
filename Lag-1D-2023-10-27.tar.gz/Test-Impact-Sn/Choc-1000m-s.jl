using Plots
println("Propriétés d'un impact Sn-Sn à 1000 m/s")
println("Sn=milMat[1]")
Sn=milMat[1]
println("pole=Etat(Sn,\"Pôle\",Materiau.getVal(Sn,\"ρ0\"),0.0)")
pole=Etat(Sn,"Pôle",Materiau.getVal(Sn,"ρ0"),0.0)
ρvals=[ Materiau.getVal(Sn,"ρ0")  7400 7600 7800 8000 8200 8400 8600 ]
pH    =Vector{Float64}(undef, length(ρvals))
uHproj=Vector{Float64}(undef, length(ρvals))
uHcibl=Vector{Float64}(undef, length(ρvals))

for i in 1:length(ρvals)
	Phi,Ehi,uhi,Dhi=Hugoniot(Sn,pole,0.0,ρvals[i])
	pH[i]=Phi
	uHproj[i]=cas.milieux[1].u-uhi
	uHcibl[i]=uhi
	println("P = ",pH[i],"   ρ= ",ρvals[i],"  uProj=  ",uHproj[i],"  uCibl= ",uHcibl[i],"   ")
end
uh=(uHproj[end]+uHcibl[end])/2
pentePu=(pH[end]-pH[end-1])/(uHcibl[end]-uHcibl[end-1]);
Phx=pH[end]+(uh-uHcibl[end])*pentePu	
pentePρ=(pH[end]-pH[end-1])/(ρvals[end]-ρvals[end-1]);
ρha=ρvals[end]+(Phx-pH[end])/pentePρ
println("Phx = ",Phx,"  uh=  ",uh,"   ","  ρh=  ",ρha,"   ")
Pha,Eh,uha,Dh=Hugoniot(Sn,pole,0.0,ρha)
pentePu=(pH[end]-Pha)/(uHcibl[end]-uha);
Ph=Pha+(uh-uha)*pentePu
pentePρ=(pH[end]-Pha)/(ρvals[end]-ρha);
ρh=ρvals[end]+(Ph-pH[end])/pentePρ
Ph,Eh,uh,Dh=Hugoniot(Sn,pole,0.0,ρh)
println("───────────┬─────────────────┬────────────────────┬")
println("           │      pôle       │    Hugoniot        │ ")
println("───────────┼─────────────────┼────────────────────┼")
println("     P     │ ", round(pole.P),"             │    ",Ph,"     │ ")
println("     E     │ ", pole.E,"             │    ",Eh,"     │ ")
println("     u     │ ", 0.000,"             │    ",uh,"     │ ")
println("     ρ     │ ", pole.ρ,"          │    ",ρh,"     │ ")
println("     D     │                 │    ",Dh," m/s    │ ")
println("───────────┴─────────────────┴────────────────────┴")	
plot(uHcibl,pH,xlabel="u (m/s)",ylabel="P (Pa)",label="Cible")
plot!(uHproj,pH,label="Projectile")
