﻿#include <iostream>
#include <string>
#include <unistd.h>
#include <filesystem>

#include "../../lib/Mat.h"  
#include "../LecteurXY/LecteurXY.hpp"
#include "../EtatThermo/EtatThermo.h" 
using namespace std; 
namespace fs = std::filesystem;

LecteurXY donneesVE;	

int main (int argc, char* args[]) { 
	if (argc<3) 	{cout <<" Syntaxe :  test-GP <gp-xxx.xml> <pts.xml>" <<endl;} 
	if (argc<3) 	{cout << " Argument manquant"<<endl; } 
		else 	{ cout << " Argument " << (char*)args[1] << " " << (char*)args[2] << endl; }; 
	string xmlFile    = (string) args[1]; 
	char* xmlPtsFile = (char*) args[2]; 

	chdir("..");
	string mat_path = fs::current_path();
	cout << "Matériau  GP , Fichier de paramètres: "  <<  mat_path << "/" << xmlFile  << endl ;
	MatGP materiau=MatGP(xmlFile);
	materiau.LireDonnees(xmlFile);
//	materiau.ecrire();

	//	CHARGEMENT DES POINTS TESTS
	donneesVE.LireDonnees(xmlPtsFile);
	cout << "Matériau : " << donneesVE.nom << endl;
	vector <PointXY> pointsVE = donneesVE.pointsXY;
	cout << xmlPtsFile << endl; 
	int nbPts=(int) pointsVE.size();
	cout << nbPts << " points." << endl; 
	double ρ[nbPts],E[nbPts];
	double p[nbPts], c[nbPts], T[nbPts], 𝒢[nbPts], S[nbPts];
	for (int i=0; i< nbPts; i++){
		materiau.calculEtatVE( pointsVE[i].x , pointsVE[i].y );
		ρ[i] = 1/pointsVE[i].x;
		E[i] = pointsVE[i].y;
	}	 
	cout << " ===================================================================" << endl; 
	vector<EtatThermo> etats;
	materiau.calculEtats(1,nbPts,p,c,T,𝒢,S,ρ,E);
	for (int i=0; i < nbPts; i++){
		cout << i+1 << "	ρ = " << ρ[i]<< "	V = " << 1/ρ[i] << "	E = " << E[i] 
			<< "	P = " << p[i] << "	T = " << T[i] << "	S = " << S[i] 
			<< "	c = " << c[i] << "	𝒢 = " << 𝒢[i] << endl;
		EtatThermo etat=EtatThermo(ρ[i],E[i],p[i],T[i],S[i],c[i],𝒢[i]);
		etats.push_back(etat);
	}	 
	cout << EtatsToTag(etats);
	cout << "Fin"<< endl; 

	return 0; 
} 

