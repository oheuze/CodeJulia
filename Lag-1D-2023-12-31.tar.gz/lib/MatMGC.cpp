//	OH	26-10-2023

#include "Mat.h"
#include "LecteurMAT.hpp"
#include "LecteurMap.hpp"

//
// MatMGC
//

MatMGC::MatMGC(const std::string material)
{
	string pwd = std::filesystem::current_path();
	cout << "Matériau  MGC , Fichier de paramètres: "  <<  pwd << "/" << material  << endl ;
	materiau=material;	
}
	
void MatMGC::LireDonnees(std::string nomfic){
	LireDonneesStandard(nomfic);
}
	
void MatMGC::InitParam(){	
	cout << "	Initialisation MatMGC (" << parametres.size() << " paramètres). " << endl;
	nom	=	toString("Nom");
	modele	=	toString("Modèle");
	materiau=	toString("Matériau");
	EOS	=	toString("EOS");
	PhasesRef=	toString("PhasesRef");
	zone	=	toInt("zone");
	Num	=	toInt("Num");
	ρ0	=	toDouble("ρ0");
	Ko 	=	toDouble("Ko");
	No	=	toDouble("No");
	Γo	=	toDouble("Γo");
	Cvr	=	toDouble("Cvr");
	θo	=	toDouble("θo");  
	To	=	toDouble("To");
	Po	=	toDouble("Po");
	ΔV	=	toDouble("ΔV"); 
	dPdT	=	toDouble("dPdT");
	Tmin	=	toDouble("Tmin"); 
	Tmax	=	toDouble("Tmax"); 
	Pmin	=	toDouble("Pmin");
	Pmax	=	toDouble("Pmax");
	Eo	=	toDouble("Eo");
	Sr	=	toDouble("Sr");
	ur	=	toDouble("ur");
	void* EoS_Model = openLib(parametres["EOS"]);
	create_t*  create_EoSModel = createur(EoS_Model);
	//destroy_t* destroy_EoSModel=destroy(EoS_Model);
	eos=create_EoSModel(parametres); 
	if(details) ecrire();
}
	
void MatMGC::ecrire(){	
	cout << "Nom : "  << nom ; 
	cout << "	Modèle : "  << modele ; 
	cout << "	Matériau : "  << materiau << endl;
	cout << "	EOS : "  <<	EOS;
	cout << "	PhasesRef : " <<	PhasesRef;
	cout << "	zone = " <<  zone;
	cout << "	Num = " <<  Num  <<endl;
	cout << "	ρ0 = " << ρ0;
	cout << "	Ko = " << Ko;
	cout << "	No = " << No << endl;
	cout << "	Γo = " << Γo;
	cout << "	Cvr = " << Cvr;
	cout << "	θo = " << θo << endl;
	cout << "	To = " << To;
	cout << "	Po = " << Po;
	cout << "	ΔV = " << ΔV;  
	cout << "	dPdT = " << dPdT  << endl;
	cout << "	Tmin = " << Tmin; 
	cout << "	Tmax = " << Tmax; 
	cout << "	Pmin = " << Pmin;
	cout << "	Pmax = " << Pmax << endl;
	cout << "	Eo = " << Eo ;
	cout << "	Sr = " << Sr;
	cout << "	ur = " << ur << endl;
}

void MatMGC::calculPc(int ideb, int ifin, double* p, double* c, const double* ρ, const double* epsilon){
	double v[ifin+1]= {0};
	// boucle à supprimer sauf le calcul de v
	for (int i = ideb; i <= ifin; i++) {
		double x, ε, εP, εS, Es, Ps, PsP, θ, Γ, ΓSurVp, dPdVe, dPdEv;
		//Potentiel Inversible  -> ε, εP
		x=1-ρ0/ρ[i];
		εS=exp((No+1)*x);
		ε= ((εS-1)/(No+1)-x)/(No+1);
		εP= (εS-1)/(No+1);
		//	Potentiel  -> Es,Ps
		Es = Ko*ε/ρ0+Eo;
		Ps = Ko*εP;
		PsP= -Ko*ρ0*εS;
		//  Température de Debye et  Γ*ρ=cste=Γo*ρ0
		θ= θo*exp(Γo*x);
		Γ = Γo*ρ0/ρ[i];		//  Γ = -θ'/θ
		ΓSurVp = 0;
		p[i]=Ps+Γ*ρ[i]*(epsilon[i]-Es);
		dPdVe=PsP+ΓSurVp*(epsilon[i]-Es)+Γ*ρ[i]*Ps;
		dPdEv=Γ*ρ[i];
		double c2=-(dPdVe-dPdEv*p[i])/ρ[i]/ρ[i];
		c[i] = sqrt(c2);
		//v[i]=1/ρ[i];
		//  === ce qui est au-dessus est inutile
		double V=1/ρ[i];
		double E=epsilon[i];
		eos->calculEtatVE(V,E);
		p[i]=eos->P;
		c[i]=eos->c;
	}	
	//eos->calculVE(ideb,ifin,p,T,c,g,S,v,epsilon);
}

void MatMGC::calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* 𝒢, double* S,
	const double* ρ, const double* epsilon){
	
	for (int i = ideb; i <= ifin; i++) {
		eos->calculEtatVE(V=1.0/ρ[i],epsilon[i]);
		p[i]=eos->P;
		c[i]=eos->c;
		T[i]=eos->T;
		S[i]=eos->S;
		𝒢[i]=eos->𝒢;
	}	
	//eos->calculρE(ideb,ifin,p,T,c,𝒢,S,ρ,epsilon);
}

void MatMGC::calculEtatsρT(int N, double* p, double* c, double* epsilon, 
		const double* ρ, const double* T)
{
    for (int i = 0; i < N; i++) {

		//Potentiel Inversible  -> ε, εP
		double x=1-ρ0/ρ[i];
		double εS=exp((No+1)*x);
		double ε= ((εS-1)/(No+1)-x)/(No+1);
		double εP= (εS-1)/(No+1);
		//	Potentiel  -> Es,Ps
		double Es = Ko*ε/ρ0+Eo;
		double Ps = Ko*εP;
		double PsP= -Ko*ρ0*εS;
		//  Température de Debye et  Γ*ρ=cste=Γo*ρ0
		double θ= θo*exp(Γo*x);
		double Γ = Γo*ρ0/ρ[i];		//  Γ = -θ'/θ
		double ΓSurVp = 0;
		
		// à revoir à partir d'ici
		p[i]=Ps+Γ*ρ[i]*(Cvr * T[i]-Es);
		epsilon[i] = Es + Cvr * T[i];
		double u = (epsilon[i]-Es)/(Cvr*θ)+ur;
		// fonction ψ  : ψ=log <=>  Cv= cste
		double ψ = log(u);
		double ψP=1/u;
		double S=Sr+Cvr*ψ;
		double dPdVe=PsP+ΓSurVp*(epsilon[i]-Es)+Γ*ρ[i]*Ps;
		double dPdEv=Γ*ρ[i];
		double c2=-(dPdVe-dPdEv*p[i])/ρ[i]/ρ[i];
		c[i]=sqrt(c2);
	}
}

void MatMGC::calculEtatVE(double v,double e){
	V = v;
	E = e;
	//Potentiel Inversible  -> ε, εP
	double x=1-ρ0*V;
	double εS=exp((No+1)*x);
	double ε= ((εS-1)/(No+1)-x)/(No+1);
	double εP= (εS-1)/(No+1);
	//	Potentiel  -> Es,Ps
	double Es = Ko*ε/ρ0+Eo;
	double Ps = Ko*εP;
	double PsP= -Ko*ρ0*εS;
	//  Température de Debye et  Γ*ρ=cste=Γo*ρ0
	double θ= θo*exp(Γo*x);
	Γ = Γo*ρ0*V;		//  Γ = -θ'/θ
	double ΓSurVp = 0;
	P=Ps+Γ/V*(E-Es);
	double dPdVe=PsP+ΓSurVp*(E-Es)+Γ/V*Ps;
	double dPdEv=Γ/V;
	double c2=-(dPdVe-dPdEv*P)*V*V;
	c=sqrt(c2);
	double u = (E-Es)/(Cvr*θ)+ur;
	// fonction ψ  : ψ=log <=>  Cv= cste
	double ψ = log(u);
	double ψP=1/u;
	T=θ/ψP;
	S=Sr+Cvr*ψ;
       	H=E+P*V;
       	F=E-T*S;
       	G=F+P*V;
       	// à compléter
       	𝒢=0; 
        γ=0;
        ecrireEtat();         
}	
