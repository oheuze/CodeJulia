#  OH-20/11/2022

####################
# Riemann Solvers
####################

function RiemannDukowicz(riemann, iterations, ustar, pstar, rho, umat, pmat, cmat, gmat, ideb, ifin)
#
#    Dukowicz's formulae BUT with "as" and "As" assigned to the EOS-provided sound speed and *half* fundamental derivative
#    John K. Dukovicz, "A General, Non-Iterative Riemann Solver for Godunov's Method", Journal of Computational Physics 61, 119-137 (1985)
#    Dukovicz's formula (24) involves *expensive* EOS calls per cell per cycle with Rankine-Hugoniot *infinite strength* shock computations
#    Here, the two-shock approximation is retained but in the *weak shock limit* with sound speed & fundamental derivative computed from the EOS
#    For a perfect gas, Dukowicz's formula (24) is very close to the fundamental derivative, different from *half* the fundamental derivative here
#    LEfT AS EXERCISE: extension/modification of the Dukowicz's formulae for NEGATIVE values of fundamental derivatives (e.g. Bizarrium EOS)
#
  		Threads.@threads for i in ideb:ifin+1

			WL = umat[i-1]
			PL = pmat[i-1]
			AL = gmat[i-1]*0.5    # Half the fundamental derivative -> our choice to satisfy the WEAK SHOCK limit
			SSL = cmat[i-1]
			RHOL = rho[i-1]

			WR = umat[i]
			PR = pmat[i]
			AR = gmat[i]*0.5
			SSR = cmat[i]
			RHOR = rho[i]
			
			if riemann == "weak-shock_Dukowicz"
                                            #  Dukowicz's STRONG SHOCK limit coefficient available analyticaly in the case of a perfect gas EOS
				AL = 2*AL   #  See also Juan Cheng and Chi-Wang Shu, Journal of Computational Physics 227, 1567-1596 (2007)
				AR = 2*AR   #  A factor 2 (two) has to be applied to the coefficients...
			end

			WMIN = WR - 0.5*SSR/AR
			WMAX = WL + 0.5*SSL/AL

			PLMIN = PL - 0.25*RHOL*SSL^2/AL
			PRMIN = PR - 0.25*RHOR*SSR^2/AR

			BL = RHOL*AL
			BR = RHOR*AR

			A = (BR-BL)*(PRMIN-PLMIN)
			B = BR*WMIN^2-BL*WMAX^2
			C = BR*WMIN-BL*WMAX
			D = BR*BL*(WMIN-WMAX)^2

#                     Case A: W12-WMIN > 0 and W12-WMAX < 0

			DD = sqrt(max(0, D-A))
			W12 = (B+PRMIN-PLMIN)/(C-abs(DD)*sign(WMAX-WMIN))
			if (W12-WMIN >= 0. && W12-WMAX <= 0.) @goto finish end

#                     Case B: W12-WMIN < 0 and W12-WMAX > 0

			DD = sqrt(max(0, D+A))
			W12 = (B-PRMIN+PLMIN)/(C-abs(DD)*sign(WMAX-WMIN))
			if (W12-WMIN <=0. && W12-WMAX >=0.) @goto finish end
			A = (BL+BR)*(PLMIN-PRMIN)
			B = BL*WMAX+BR*WMIN
			C = 1/(BL+BR)

#                     Case C: W12-WMIN > 0 and W12-WMAX > 0

			DD = sqrt(max(0, A-D))
			W12 = (B+DD)*C
			if (W12-WMIN >= 0. && W12-WMAX >=0.) @goto finish end

#                     Case D: W12-WMIN < 0 and W12-WMAX < 0

			DD = sqrt(max(0, -A-D))
			W12 = (B-DD)*C

			@label finish

			P12 = 0.5*(PLMIN+PRMIN+BR*abs(W12-WMIN)*(W12-WMIN)-BL*abs(W12-WMAX)*(W12-WMAX))

			ustar[i] = W12 
			pstar[i] = P12
			if silent == 2 println("Dukowicz's formulae: ", i, ", ", W12, ", ", P12) end
        	end
			
end

function RiemannAcoustic(riemann, iterations, ustar, pstar, rho, umat, pmat, cmat, gmat, ideb, ifin)
#
  		Threads.@threads for i in ideb:ifin+1
	 		rc_l = rho[i-1]*cmat[i-1]
			rc_r = rho[i]*cmat[i]
			ustar[i] = ( rc_l*umat[i-1] + rc_r*umat[i] + (pmat[i-1] - pmat[i]) ) / (rc_l + rc_r)
			pstar[i] = ( rc_r*pmat[i-1] + rc_l*pmat[i] + rc_l*rc_r*(umat[i-1] - umat[i]) ) / (rc_l + rc_r)

#			println("Acoustic ", i, " ustar = ", ustar[i], " pstar = " , pstar[i])
        	end		
end

function RiemannItAcoustic(riemann, iterations, ustar, pstar, rho, umat, pmat, cmat, gmat, ideb, ifin)
#
# Weakly nonlinear acoustic solver w/ fixed-point iterations on fundamental derivative terms
	Threads.@threads for i in ideb:ifin+1
		rc_l = rho[i-1]*cmat[i-1]
		rc_r = rho[i]*cmat[i]
		ustar[i] = ( rc_l*umat[i-1] + rc_r*umat[i] + (pmat[i-1] - pmat[i]) ) / (rc_l + rc_r)
		pstar[i] = ( rc_r*pmat[i-1] + rc_l*pmat[i] + rc_l*rc_r*(umat[i-1] - umat[i]) ) / (rc_l + rc_r)

		if silent == 2
			println(i, " ", ustar[i], " ", pstar[i])
		end

		for ii in 1:iterations
#			rc_l = rho[i-1]*(cmat[i-1]-0.5*gmat[i-1]*(ustar[i]-umat[i-1]))
#			rc_r = rho[i]*(cmat[i]+0.5*gmat[i]*(ustar[i]-umat[i]))
#			rc_l = rc_l + 1.00*(rho[i-1]*(cmat[i-1]-0.5*max(0, gmat[i-1])*(ustar[i]-umat[i-1]))-rc_l)
#			rc_r = rc_r + 1.00*(rho[i]*(cmat[i]+0.5*max(0, gmat[i])*(ustar[i]-umat[i]))-rc_r)
			rc_l = rc_l + 1.00*(rho[i-1]*(cmat[i-1]-0.5*gmat[i-1]*(ustar[i]-umat[i-1]))-rc_l)
			rc_r = rc_r + 1.00*(rho[i]*(cmat[i]+0.5*gmat[i]*(ustar[i]-umat[i]))-rc_r)

			ustar[i] = ( rc_l*umat[i-1] + rc_r*umat[i] + (pmat[i-1] - pmat[i]) ) / (rc_l + rc_r)
			pstar[i] = ( rc_r*pmat[i-1] + rc_l*pmat[i] + rc_l*rc_r*(umat[i-1] - umat[i]) ) / (rc_l + rc_r)

			if silent == 2
				println(i, " ", ustar[i], " ", pstar[i])
			end
		end
	end
end

function Riemann3TermsAcoustic(riemann, iterations, ustar, pstar, rho, umat, pmat, cmat, gmat, ideb, ifin)
#
# Weakly nonlinear acoustic solver w/ fixed-point iterations on fundamental derivative term and higher-order one

	Threads.@threads for i in ideb:ifin+1
		rc_l = rho[i-1]*cmat[i-1]
		rc_r = rho[i]*cmat[i]
		ustar[i] = ( rc_l*umat[i-1] + rc_r*umat[i] + (pmat[i-1] - pmat[i]) ) / (rc_l + rc_r)
		pstar[i] = ( rc_r*pmat[i-1] + rc_l*pmat[i] + rc_l*rc_r*(umat[i-1] - umat[i]) ) / (rc_l + rc_r)

		if silent == 2
			println(i, " ", ustar[i], " ", pstar[i])
		end

		gamma_l = 2*gmat[i-1] -1
		gamma_r = 2*gmat[i] -1

		for ii in 1:iterations
			rc_l = rho[i-1]*(cmat[i-1]-0.5*gmat[i-1]*(ustar[i]-umat[i-1])+(gamma_l+1)*(gamma_l+2)/			(12*cmat[i-1])*(ustar[i]-umat[i-1])^2)
				rc_r = rho[i]*(cmat[i]+0.5*gmat[i]*(ustar[i]-umat[i])+(gamma_r+1)*(gamma_r+2)/(12*cmat[i])
		                        *(ustar[i]-umat[i])^2)

			ustar[i] = ( rc_l*umat[i-1] + rc_r*umat[i] + (pmat[i-1] - pmat[i]) ) / (rc_l + rc_r)
			pstar[i] = ( rc_r*pmat[i-1] + rc_l*pmat[i] + rc_l*rc_r*(umat[i-1] - umat[i]) ) / (rc_l + rc_r)

			if silent == 2
				println(i, " Iteration ", ii, " ", ustar[i], " ", pstar[i])
			end
		end
	end		
end

function RiemannGodunov(riemann, iterations, ustar, pstar, rho, umat, pmat, cmat, gmat, ideb, ifin)
#
#
  		Threads.@threads for i in ideb:ifin+1
# Left and right Stiffened Gas coefficients computed from the EOS-provided fundamental derivative and sound velocity

		gamma_l = 2*gmat[i-1] -1
		gamma_r = 2*gmat[i] -1

		pzero_l = 1/gamma_l*rho[i-1]*cmat[i-1]^2 - pmat[i-1]
		pzero_r = 1/gamma_r*rho[i]*cmat[i]^2 - pmat[i]

		# Newton's iterative procedure from Godounov et coll. pp. 114-117 (Mir, 1979)

		gp1s2_l = (gamma_l+1)/2
		gp1s2_r = (gamma_r+1)/2

		gm1s2_l = (gamma_l-1)/2
		gm1s2_r = (gamma_r-1)/2

		gp1s2g_l = (gamma_l+1)/(2*gamma_l)
		gp1s2g_r = (gamma_r+1)/(2*gamma_r)

		gm1s2g_l = (gamma_l-1)/(2*gamma_l)
		gm1s2g_r = (gamma_r-1)/(2*gamma_r)

 		rc_l = rho[i-1]*cmat[i-1]
		rc_r = rho[i]*cmat[i]

		r_l = rho[i-1]; r_r = rho[i]
		p_l = pmat[i-1]; p_r = pmat[i]
		u_l = umat[i-1]; u_r = umat[i]
		c_l = cmat[i-1]; c_r = cmat[i]

		# Initial guess using the *acoustic* formulae

		ustar[i] = ( rc_l*umat[i-1] + rc_r*umat[i] + (pmat[i-1] - pmat[i]) ) / (rc_l + rc_r)
		pstar[i] = ( rc_r*pmat[i-1] + rc_l*pmat[i] + rc_l*rc_r*(umat[i-1] - umat[i]) ) / (rc_l + rc_r)

		if silent == 2
			println(i, " Acoust 1 ", ustar[i], " ", pstar[i])
		end

		for ii in 2:iterations
				
			pi_l = (pstar[i]+pzero_l)/(p_l+pzero_l)
			pi_r = (pstar[i]+pzero_r)/(p_r+pzero_r)

			if riemann == "two-shock_Godunov" #  Shock formulae only for *cheaper* approximate Riemann solver
				a_l = sqrt(r_l*(gp1s2_l*(pstar[i]+pzero_l) + gm1s2_l*(p_l+pzero_l)))
				a_r = sqrt(r_r*(gp1s2_r*(pstar[i]+pzero_r) + gm1s2_r*(p_r+pzero_r)))
				f_l = (pstar[i]-p_l)/(rc_l*sqrt(gp1s2g_l*pi_l+gm1s2g_l))
				f_r = (pstar[i]-p_r)/(rc_r*sqrt(gp1s2g_r*pi_r+gm1s2g_r))
				fp_l = ((gamma_l+1)*pi_l+(3*gamma_l-1))/(4*gamma_l*rc_l*sqrt((gp1s2g_l*pi_l+gm1s2g_l)^3))
				fp_r = ((gamma_r+1)*pi_r+(3*gamma_r-1))/(4*gamma_r*rc_r*sqrt((gp1s2g_r*pi_r+gm1s2g_r)^3))
			end

			if riemann == "two-rarefaction_Godunov" #  Rarefaction formulae only

				if abs(pstar[i]-p_l) < 1.e-13*p_l  # Acoustic formulae to prevent NaN between cells at equilibrium
					a_l = rc_l
					f_l = (pstar[i]-p_l)/rc_l
					fp_l = 1/rc_l
				else
					a_l = gm1s2g_l*rc_l*(1-pi_l)/(1-pi_l^gm1s2g_l)
					f_l = 2/(gamma_l-1)*c_l*(pi_l^gm1s2g_l - 1)
					fp_l = 1/(gamma_l*(p_l+pzero_l))*c_l*pi_l^gm1s2g_l
				end

				if abs(pstar[i]-p_r) < 1.e-13*p_r  # Acoustic formulae to prevent NaN between cells at equilibrium

					a_r = rc_r
					f_r = (pstar[i]-p_r)/rc_r
					fp_r = 1/rc_r
				else
					a_r = gm1s2g_r*rc_r*(1-pi_r)/(1-pi_r^gm1s2g_r)
					f_r = 2/(gamma_r-1)*c_r*(pi_r^gm1s2g_r - 1)
					fp_r = 1/(gamma_r*(p_r+pzero_r))*c_r*pi_r^gm1s2g_r
				end
			end

			if riemann == "exact_Godunov" # Standard formulae for the EXACT Riemann solver

				if pstar[i] >= (1-1.e-14)*p_l  # Shock formulae To prevent NaN between cells at equilibrium

					a_l = sqrt(r_l*(gp1s2_l*(pstar[i]+pzero_l) + gm1s2_l*(p_l+pzero_l)))
					f_l = (pstar[i]-p_l)/(rc_l*sqrt(gp1s2g_l*pi_l+gm1s2g_l))
					fp_l = ((gamma_l+1)*pi_l+(3*gamma_l-1))/(4*gamma_l*rc_l*sqrt((gp1s2g_l*pi_l+gm1s2g_l)^3))
				else
					a_l = gm1s2g_l*rc_l*(1-pi_l)/(1-pi_l^gm1s2g_l)
					f_l = 2/(gamma_l-1)*c_l*(pi_l^gm1s2g_l - 1)
					fp_l = 1/(gamma_l*(p_l+pzero_l))*c_l*pi_l^gm1s2g_l
				end

				if pstar[i] >= (1-1.e-14)*p_r

					a_r = sqrt(r_r*(gp1s2_r*(pstar[i]+pzero_r) + gm1s2_r*(p_r+pzero_r)))
					f_r = (pstar[i]-p_r)/(rc_r*sqrt(gp1s2g_r*pi_r+gm1s2g_r))
					fp_r = ((gamma_r+1)*pi_r+(3*gamma_r-1))/(4*gamma_r*rc_r*sqrt((gp1s2g_r*pi_r+gm1s2g_r)^3))
				else
					a_r = gm1s2g_r*rc_r*(1-pi_r)/(1-pi_r^gm1s2g_r)
					f_r = 2/(gamma_r-1)*c_r*(pi_r^gm1s2g_r - 1)
					fp_r = 1/(gamma_r*(p_r+pzero_r))*c_r*pi_r^gm1s2g_r
				end
			end
			pstar[i] = pstar[i] - (f_l+f_r-(u_l-u_r))/(fp_l+fp_r)
			ustar[i] = (a_l*u_l+a_r*u_r+p_l-p_r)/(a_l+a_r)
			if silent == 2
				println(i, " Newton ", ii, " ", ustar[i], " ", pstar[i])
			end
		end
	end	
end

function RiemannDespres(riemann, iterations, ustar, pstar, rho, umat, pmat, cmat, gmat, ideb, ifin)
#
#
	Threads.@threads for i in ideb:ifin+1
		rc = sqrt(max(rho[i-1]*cmat[i-1]^2, rho[i]*cmat[i]^2)/max(1/rho[i-1], 1/rho[i]))
 		rc_l = rc
		rc_r = rc
		ustar[i] = ( rc_l*umat[i-1] + rc_r*umat[i] + (pmat[i-1] - pmat[i]) ) / (rc_l + rc_r)
		pstar[i] = ( rc_r*pmat[i-1] + rc_l*pmat[i] + rc_l*rc_r*(umat[i-1] - umat[i]) ) / (rc_l + rc_r)
       	end
end	

