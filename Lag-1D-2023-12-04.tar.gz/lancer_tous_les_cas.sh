#!/bin/bash

date > /tmp/date

cd Test-Sod
./lanceur.sh
echo fin du test Sod

cd ..
cd Test-Bizarrium
./lanceur.sh
echo fin du test Bizarrium

cd ..
cd Test-Impact-Sn
./lanceur-MG.sh
./lanceur-3Ph.sh
echo fin du test Impact-Sn

cd ..
cd Test-impact-Bi-Sn
./lanceur.sh
echo fin du test impact-Bi-Sn

#cd ..
#cd Test-Leblanc
#./lanceur.sh
#echo fin du test Leblanc

cd ..
echo "Heure de début :"
more /tmp/date
echo "Heure de fin :"
date

echo fin de tous les tests !
