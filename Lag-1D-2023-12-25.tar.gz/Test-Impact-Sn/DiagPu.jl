#  OH 31/05/2023
test=basename(pwd())
println("PostProcessing du cas de calcul : "*test)
using CSV,DataFrames,Plots

nom="acoustic"
dfHyb = DataFrame(CSV.File(nom*".dat";header=1, delim=" "))
rename!(dfHyb,[:x,:ρ,:u,:p,:e,:t,:c,:𝒢])
figPu = plot(dfHyb.u,dfHyb.p/1e9,xlabel="u (m/s)",ylabel="p (GPa)",title=test,label="P(u) 3-phases")
nom="MG-acoustic"
rename!(dfMG,[:x,:ρ,:u,:p,:e,:t,:c,:𝒢])
dfMG = DataFrame(CSV.File(nom*".dat";header=1, delim=" "))
figPu = plot!(dfMG.u,dfMG.p/1e9,xlabel="u (m/s)",ylabel="p (GPa)",title=test,label="P(u) 1-phase")
savefig(test*"-Pu.png")
