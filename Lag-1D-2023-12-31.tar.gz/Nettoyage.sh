#!/usr/bin/bash
rm -r Matériaux/Valid-*/CMakeFiles
rm Matériaux/Valid-*/CMakeCache.txt
rm Matériaux/Valid-*/cmake_install.cmake
rm Matériaux/Valid-*/Makefile
rm Matériaux/Valid-*/valid
rm Test-Sod/*.dat	
rm Test-Sod/*.pdf	
rm Test-Sod/*.png
rm Test-Impact-Sn/*.dat	
rm Test-Impact-Sn/*.pdf
rm Test-Impact-Sn/*.png
rm Test-Bizarrium/*.dat	
rm Test-Bizarrium/*.pdf	
rm Test-Bizarrium/*.png
