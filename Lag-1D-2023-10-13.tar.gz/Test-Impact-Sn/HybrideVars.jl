nV=Hybride.nV
nE=Hybride.nE
geom  =Hybride.geom
grille=Hybride.grille

