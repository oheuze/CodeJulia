#  21/10/2023
using Printf

struct EtatThermo
	Nom :: String
	P :: Float64
	ρ :: Float64
	T :: Float64
	S :: Float64
	E :: Float64
	g :: Float64
	c :: Float64
end

function Etat(Mat,nom::String,ρ::Float64,E::Float64)::EtatThermo
    local P = zeros(Float64, 3)
    local c = zeros(Float64, 3)
    local T = zeros(Float64, 3)
    local g = zeros(Float64, 3)
    local S = zeros(Float64, 3)
    local r= ones(Float64, 3).* ρ
    local e= ones(Float64, 3).* E
    Materiau.calculEtats(Mat,1,2,P,c,T,g,S,r,e)
    return EtatThermo(nom,P[2],ρ,T[2],S[2],E,g[2],c[2])
end

function AffEtat(etat::EtatThermo)
	@printf(" %20s  ρ = %8g E= %12g P= %12g T= %8g  S=  %12g  c=  %8g  g=  %6g \n",etat.Nom,etat.ρ,etat.E,etat.P,etat.T,etat.S,etat.c,etat.g)
end

function AffEtats(etats::Vector{EtatThermo})
        println("           │       P               ρ         E        T          c          S          g     ")
        println(" ──────────┼─────────────────────────────────────────────────────────────────────────────────")
	for i in 1:length(etats)
		@printf("%10s │ %12g %12g %8g %8g %14g %8g %8g \n",
	            etats[i].Nom,etats[i].P,etats[i].ρ,etats[i].E,etats[i].T,etats[i].c,etats[i].S,etats[i].g)
	end
        println(" ──────────┼─────────────────────────────────────────────────────────────────────────────────")
end

function Hugoniot(Mat,Pole,uPole,ρ)
	#	pour une EE Mie-Grüneisen
	E1=0.0
	etat1=Etat(Mat,"etatE1",ρ,E1)
	E2=1000.0
	etat2=Etat(Mat,"etatE2",ρ,E2)
	Γρ = (etat2.P-etat1.P)/(E2-E1)
	Ph=(etat1.P+Γρ*(Pole.E+Pole.P*(1/Pole.ρ-1/ρ)/2))/(1. - Γρ*(1/Pole.ρ-1/ρ)/2)
	Eh=Pole.E+(Pole.P+Ph)*(1/Pole.ρ-1/ρ)/2
	u=uPole+sqrt((Ph-Pole.P)*(1/Pole.ρ-1/ρ))
	D=1/Pole.ρ*sqrt((Ph-Pole.P)/(1/Pole.ρ-1/ρ))
	return Ph,Eh,u,D
end

function IsentropeGP(Mat,Pole,uPole,ρ)
	#	pour un gaz parfait γ=1.4
	γ=1.4
	Ps=Pole.P*(ρ/Pole.ρ)^γ
	Es = Ps/ρ/(γ-1)
	etatS=Etat(Mat,"Is",ρ,Es)
	u=uPole-(etatS.c-Pole.c)/(Pole.g-1)
	return Ps,Es,u
end

function Isentrope(Mat,Pole,uPole,ρ)
	#  cas ~général  dérivée fondamentale ~constante
	global Es=Pole.E
	for i=1:6	
	    is=Etat(Mat,"Is1",ρ,Es)
	    dS=is.S-Pole.S
	    Es=Es-is.T*dS
	end
	etatS=Etat(Mat,"Is",ρ,Es)  
	u=uPole-(etatS.c-Pole.c)/(etatS.g-1)
	return etatS.P,Es,u
end  

function AffHug(Mat,Pole,u0,ρmax)
	x=zeros(10)
	y=zeros(10)
	for i=1:10
		local ρ=Pole.ρ+i*(ρmax-Pole.ρ)/10
		(Ph,Eh,uh,Dh)=Hugoniot(Mat,Pole,u0,ρ)
		y[i]=Ph
		x[i]=uh
	end
	#figPu=plot(x,y,xlabel="u (m/s)",ylabel="P (Pa)")
	return p
end

