#!/bin/bash

cat <<EOF > modifs.jl
riemann="acoustic";nom="MG-acoustic"
EOF
more modifs.jl
julia MG.jl

cat <<EOF > modifs.jl
riemann="three-term_acoustic";nom="MG-three-term_acoustic"
EOF
more modifs.jl
julia MG.jl

cat <<EOF > modifs.jl
riemann="one-iteration_acoustic";nom="MG-one-iteration_acoustic"
EOF
more modifs.jl
julia MG.jl

cat <<EOF > modifs.jl
riemann="two-iteration_acoustic";nom="MG-two-iteration_acoustic"
EOF
more modifs.jl
julia MG.jl

julia ../PostProcessingAll.jl






