using DataFrames,Plots,Printf
#  OH - 29/10/2023
#  Calcul des états exacts du test de Sod
#	nom="Sod"
#	include("../Init-Lag.jl")
#	include("Solution-Sod.jl")
gp=milMat[1]
γ=Materiau.getVal(gp,"γ")
etat1=Etat(milMat[1],cas.milieux[1].Nom,cas.milieux[1].ρ,cas.milieux[1].e)
etat4=Etat(milMat[2],cas.milieux[2].Nom,cas.milieux[2].ρ,cas.milieux[2].e)

ρ2a=0.4;
ρ2b=0.5;
ρ3a=0.2;
ρ3b=0.3;
(Pda,Eda,uda)   =isentrope(gp,etat1,0.0,ρ2a);
(Pdb,Edb,udb)   =isentrope(gp,etat1,0.0,ρ2b);
(Pha,Eha,uha,Dha)= hugoniot(gp,etat4,0.0,ρ3a);
(Phb,Ehb,uhb,Dhb)= hugoniot(gp,etat4,0.0,ρ3b);
Dd=(Pdb-Pda)/(udb-uda);
Dh=(Phb-Pha)/(uhb-uha);
ux=(Pda-Dd*uda-(Pha-Dh*uha))/(Dh-Dd)
Px=(Dh*(Pda-Dd*uda)-Dd*(Pha-Dh*uha))/(Dh-Dd)
ρ2x=ρ2a+(ρ2b-ρ2a)/(udb-uda)*(ux-uda);
ρ3x=ρ3a+(ρ3b-ρ3a)/(uhb-uha)*(ux-uha);
E2x=Eda+(Edb-Eda)/(udb-uda)*(ux-uda);
E3x=Eha+(Ehb-Eha)/(uhb-uha)*(ux-uha);
etat2=Etat(milMat[1],"Etat 2",ρ2x,E2x);
etat3=Etat(milMat[2],"Etat 3",ρ3x,E3x);
Dd=-ρ2x*etat2.c;
Dh= ρ3x*etat3.c
(Pdx,Edx,udx)   =isentrope(gp,etat1,0.0,ρ2x);
(Phx,Ehx,uhx,Dhx)= hugoniot(gp,etat4,0.0,ρ3x);
ux=(Pdx-Dd*udx-(Phx-Dh*uhx))/(Dh-Dd)
Px=(Dh*(Pdx-Dd*udx)-Dd*(Phx-Dh*uhx))/(Dh-Dd)

# recherche du point s'intersection entre la détente et le choc
#for i=1:3
	ρ2a=0.99*ρ2x;
	ρ2b=1.01*ρ2x;
	ρ3a=0.99*ρ3x;
	ρ3b=1.01*ρ3x;
	(Pda,Eda,uda)   =isentrope(gp,etat1,0.0,ρ2a);
	(Pdb,Edb,udb)   =isentrope(gp,etat1,0.0,ρ2b);
	(Pha,Eha,uha,Dha)= hugoniot(gp,etat4,0.0,ρ3a);
	(Phb,Ehb,uhb,Dhb)= hugoniot(gp,etat4,0.0,ρ3b);
	Dd=(Pdb-Pda)/(udb-uda);
	Dh=(Phb-Pha)/(uhb-uha);
	ux=(Pda-Dd*uda-(Pha-Dh*uha))/(Dh-Dd);
	Px=(Dh*(Pda-Dd*uda)-Dd*(Pha-Dh*uha))/(Dh-Dd);
	ρ2x=ρ2a+(ρ2b-ρ2a)/(udb-uda)*(ux-uda);
	ρ3x=ρ3a+(ρ3b-ρ3a)/(uhb-uha)*(ux-uha);
	E2x=Eda+(Edb-Eda)/(udb-uda)*(ux-uda);
	E3x=Eha+(Ehb-Eha)/(uhb-uha)*(ux-uha);
	etat2=Etat(milMat[1],"Etat 2",ρ2x,E2x)
	etat3=Etat(milMat[2],"Etat 3",ρ3x,E3x)
	Dd=-ρ2x*etat2.c;
	Dh= ρ3x*etat3.c;
	(Pdx,Edx,udx)   =isentrope(gp,etat1,0.0,ρ2x);
	(Phx,Ehx,uhx,Dhx)= hugoniot(gp,etat4,0.0,ρ3x);
	ux=(Pdx-Dd*udx-(Phx-Dh*uhx))/(Dh-Dd)
	Px=(Dh*(Pdx-Dd*udx)-Dd*(Phx-Dh*uhx))/(Dh-Dd)
#end	
println("P* = ",Px,"	u*=",ux)

(Pd,Ed,ud)   =isentrope(gp,etat1,0.0,ρ2x)
(Ph,Eh,uh,Dh)= hugoniot(gp,etat4,0.0,ρ3x)
etat2=Etat(milMat[1],"etat2 (détente)",ρ2x,Ed)
etat3=Etat(milMat[2],"etat3 (Choc)",ρ3x,Eh)
AffEtat(etat1)
AffEtat(etat2)
AffEtat(etat3)
AffEtat(etat4)
#figPu = plot(df.u,df.p,xlabel="u (m/s)",ylabel="p (GPa)",title=nom,label="P(u)")
#figPu=scatter([cas.milieux[2].u,ux],[etat4.P,Px],label="Choc")
#figPu=scatter!([cas.milieux[1].u,ux],[etat1.P,Px],label="Détente")
#figρe = plot(df.ρ,df.e,xlabel="ρ (kg/m3)",ylabel="e (J/kg)",title=nom,label="e(ρ)")
#figρe=scatter([etat1.ρ,etat2.ρ,etat3.ρ,etat4.ρ],[etat1.E,etat2.E,etat3.E,etat4.E],label="Solution exacte")

N=10
rh=zeros(Float64, N);ph=zeros(Float64, N);rs=zeros(Float64, N);ps=zeros(Float64, N);
us=zeros(Float64, N);uh=zeros(Float64, N);vh=zeros(Float64, N);vs=zeros(Float64, N);
eh=zeros(Float64, N);es=zeros(Float64, N);ch=zeros(Float64, N);cs=zeros(Float64, N);
xs=zeros(Float64, N);

println("\n			Isentrope de détente issue de l'état 1")
println("	       ρ	     P	           E	           u	");
for i=1:N	
	rs[i]=((N-i)*etat1.ρ+(i-1)*etat2.ρ)/(N-1)
        (ps[i],es[i],us[i] )  =isentrope(gp,etat1,0.0,rs[i])
        etatS=Etat(milMat[1],"Etat S",rs[i],es[i])
        cs[i]=etatS.c;
        @printf("	%6f	%6f	%6f	%6f	\n",rs[i],ps[i],es[i],us[i])
end 

println("\n			Choc issu de l'état 4")
println("	       ρ	     P	           E	           u	            D");
for i=1:N
	local Dh
	rh[i]=((N-i)*etat4.ρ+(i-1)*etat3.ρ)/(N-1)
	(ph[i],eh[i],uh[i],Dh)   =hugoniot(gp,etat4,0.0,rh[i])
        etatH=Etat(milMat[2],"Etat H",rh[i],eh[i])
        ch[i]=etatH.c;
        #println(rh[i],"        ",ph[i],"         ",eh[i],"        ",uh[i],"	",Dh)
        @printf("	%6f	%6f	%6f	%6f	%6f	\n",rh[i],ph[i],eh[i],uh[i],Dh)
end
#   Diagramme (P,u)
scatter([0,ux,ux,0],[etat1.P,etat2.P,etat3.P,etat4.P],label="etats",title="P(u)",xlabel="u",ylabel="P")
plot!(us,ps,label="Isentrope")
figPu=plot!(uh,ph,label="Hugoniot")
savefig("Solution-Pu.png")

#	Diagramme (ρ,E)
scatter([etat1.ρ,etat2.ρ,etat3.ρ,etat4.ρ],[etat1.E,etat2.E,etat3.E,etat4.E], 	label="etats",title="(ρ,E)",xlabel="ρ",ylabel="E")
plot!(rs,es,label="Isentrope")
figρE=plot!(rh,eh,label="Hugoniot")
savefig("Solution-ρE.png")

#	Diagramme (x,ρ)
temps=0.2
uxt=0.5+ux*temps		
Dht=0.5+Dh*temps	
for i=1:N
                  xs[i]=0.5+((γ+1)/2*us[i]-etat1.c)*temps
end	
scatter([0.5-etat1.c*temps,xs[10],uxt,uxt,Dht,Dht],[etat1.ρ,etat2.ρ,etat2.ρ,etat3.ρ,etat3.ρ,etat4.ρ],title="t = "*string(temps),label=" ") 
plot!([0,0.5-etat1.c*temps],[etat1.ρ,etat1.ρ],label="etat 1")
plot!(xs,rs,label="détente")
plot!([xs[10],uxt],[etat2.ρ,etat2.ρ],label="  ")
plot!([uxt,uxt],[etat2.ρ,etat3.ρ],label="u*")	
plot!([uxt,Dht],[etat3.ρ,etat3.ρ],label="etat 3")	
plot!([Dht,Dht],[etat3.ρ,etat4.ρ],label="Choc")	
figρx=plot!([Dht,1],[etat4.ρ,etat4.ρ],label="etat 4")	
savefig("Solution-ρx.png")

println("Figures disponibles :  figPu , figρE , figρx , figxρ .")
#  Préparation du fichier .dat
nsol=2*N+14;
xsol=zeros(Float64, nsol+1);
ρsol=zeros(Float64, nsol+1);
usol=zeros(Float64, nsol+1);
psol=zeros(Float64, nsol+1);
esol=zeros(Float64, nsol+1);
tsol=zeros(Float64, nsol+1);
csol=zeros(Float64, nsol+1);
gsol=zeros(Float64, nsol+1);

xsol[1]=0;			ρsol[1]=etat1.ρ;psol[1]=etat1.P;usol[1]=0;esol[1]=etat1.E;
xsol[2]=0;			ρsol[2]=etat1.ρ;psol[2]=etat1.P;usol[2]=0;esol[2]=etat1.E;
xsol[3]=0.5-etat1.c*temps;	ρsol[3]=etat1.ρ;psol[3]=etat1.P;usol[3]=0;esol[3]=etat1.E;
xsol[4]=0.5-etat1.c*temps;	ρsol[4]=etat1.ρ;psol[3]=etat1.P;usol[3]=0;esol[3]=etat1.E;
for i=1:N
	xsol[4+i]=xs[i];
	ρsol[4+i]=rs[i];
	psol[4+i]=ps[i];
	usol[4+i]=us[i];
	esol[4+i]=es[i];
	csol[4+i]=cs[i];
end 
xsol[N+ 5]=xs[10];	ρsol[N+ 5]=etat2.ρ;psol[N+ 5]=etat2.P;usol[N+ 5]=ux;esol[N+ 5]=etat2.E;
xsol[N+ 6]=uxt;		ρsol[N+ 6]=etat2.ρ;psol[N+ 6]=etat2.P;usol[N+ 6]=ux;esol[N+ 6]=etat2.E;
xsol[N+ 7]=uxt;		ρsol[N+ 7]=etat2.ρ;psol[N+ 7]=etat2.P;usol[N+ 7]=ux;esol[N+ 7]=etat2.E;
xsol[N+ 8]=uxt;		ρsol[N+ 8]=etat3.ρ;psol[N+ 8]=etat3.P;usol[N+ 8]=ux;esol[N+ 8]=etat3.E;
xsol[N+ 9]=uxt;		ρsol[N+ 9]=etat3.ρ;psol[N+ 9]=etat3.P;usol[N+ 9]=ux;esol[N+ 9]=etat3.E;
xsol[N+10]=Dht;		ρsol[N+10]=etat3.ρ;psol[N+10]=etat3.P;usol[N+10]=ux;esol[N+10]=etat3.E;
xsol[N+11]=Dht;		ρsol[N+11]=etat3.ρ;psol[N+11]=etat3.P;usol[N+11]=ux;esol[N+11]=etat3.E;
for i=1:N
	xsol[2*N+12-i]=Dht;
	ρsol[2*N+12-i]=rh[i];
	psol[2*N+12-i]=ph[i];
	usol[2*N+12-i]=uh[i];
	esol[2*N+12-i]=eh[i];
	csol[2*N+12-i]=ch[i];
end 
xsol[2*N+12]=Dht;	ρsol[2*N+12]=etat4.ρ;psol[2*N+12]=etat3.P;usol[2*N+12]=ux;esol[2*N+12]=etat3.E;
xsol[2*N+13]=Dht;	ρsol[2*N+13]=etat4.ρ;psol[2*N+13]=etat3.P;usol[2*N+13]=ux;esol[2*N+13]=etat3.E;
xsol[2*N+14]=1;		ρsol[2*N+14]=etat4.ρ;psol[2*N+14]=etat3.P;usol[2*N+14]=ux;esol[2*N+14]=etat3.E;
xsol[2*N+15]=1;		ρsol[2*N+15]=etat4.ρ;psol[2*N+15]=etat3.P;usol[2*N+15]=ux;esol[2*N+15]=etat3.E;
figxρ=plot(xsol,ρsol,title="cas test de Sod\n t="*string(temps),lc=:black, lw=2,label="Solution exacte",xlabel="x",ylabel="ρ")
Ecritures("Solution exacte.dat",temps,xsol,ρsol,usol,psol,esol,tsol,csol,gsol,1,nsol)

AffEtats([etat1,etat2,etat3,etat4])


