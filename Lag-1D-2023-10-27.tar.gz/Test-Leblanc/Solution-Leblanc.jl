using DataFrames,Plots
#  OH - 21/10/2023
#  Calcul des états exacts du test de Leblanc
#	nom="Leblanc"
#	include("../Init-Lag.jl")
#	include("Solution-Leblanc.jl")
gp=milMat[1]
etat1=Etat(milMat[1],cas.milieux[1].Nom,cas.milieux[1].ρ,cas.milieux[1].e)
etat4=Etat(milMat[2],cas.milieux[2].Nom,cas.milieux[2].ρ,cas.milieux[2].e)

ρ2a=0.05
ρ2b=0.055
ρ3a=0.03
ρ3b=0.04
(Pda,Eda,uda)   =Isentrope(gp,etat1,0.0,ρ2a)
(Pdb,Edb,udb)   =Isentrope(gp,etat1,0.0,ρ2b)
(Pha,Eha,uha,Dha)= Hugoniot(gp,etat4,0.0,ρ3a)
(Phb,Ehb,uhb,Dhb)= Hugoniot(gp,etat4,0.0,ρ3b)
Dd=(Pdb-Pda)/(udb-uda)
Dh=(Phb-Pha)/(uhb-uha)
ux=(Pda-Dd*uda-(Pha-Dh*uha))/(Dh-Dd)
Px=(Dh*(Pda-Dd*uda)-Dd*(Pha-Dh*uha))/(Dh-Dd)
ρ2x=ρ2a+(ρ2b-ρ2a)/(udb-uda)*(ux-uda)
ρ3x=ρ3a+(ρ3b-ρ3a)/(uhb-uha)*(ux-uha)
E2x=Eda+(Edb-Eda)/(udb-uda)*(ux-uda)
E3x=Eha+(Ehb-Eha)/(uhb-uha)*(ux-uha)
etat2=Etat(milMat[1],"Etat 2",ρ2x,E2x)
etat3=Etat(milMat[2],"Etat 3",ρ3x,E3x)
Dd=-ρ2x*etat2.c
Dh= ρ3x*etat3.c
(Pdx,Edx,udx)   =Isentrope(gp,etat1,0.0,ρ2x)
(Phx,Ehx,uhx,Dhx)= Hugoniot(gp,etat4,0.0,ρ3x)
ux=(Pdx-Dd*udx-(Phx-Dh*uhx))/(Dh-Dd)
Px=(Dh*(Pdx-Dd*udx)-Dd*(Phx-Dh*uhx))/(Dh-Dd)

# recherche du point s'intersection entre la détente et le choc
#for i=1:3
	ρ2a=0.99*ρ2x;
	ρ2b=1.01*ρ2x;
	ρ3a=0.99*ρ3x;
	ρ3b=1.01*ρ3x;
	(Pda,Eda,uda)   =Isentrope(gp,etat1,0.0,ρ2a);
	(Pdb,Edb,udb)   =Isentrope(gp,etat1,0.0,ρ2b);
	(Pha,Eha,uha,Dha)= Hugoniot(gp,etat4,0.0,ρ3a);
	(Phb,Ehb,uhb,Dhb)= Hugoniot(gp,etat4,0.0,ρ3b);
	Dd=(Pdb-Pda)/(udb-uda);
	Dh=(Phb-Pha)/(uhb-uha);
	ux=(Pda-Dd*uda-(Pha-Dh*uha))/(Dh-Dd);
	Px=(Dh*(Pda-Dd*uda)-Dd*(Pha-Dh*uha))/(Dh-Dd);
	ρ2x=ρ2a+(ρ2b-ρ2a)/(udb-uda)*(ux-uda);
	ρ3x=ρ3a+(ρ3b-ρ3a)/(uhb-uha)*(ux-uha);
	E2x=Eda+(Edb-Eda)/(udb-uda)*(ux-uda);
	E3x=Eha+(Ehb-Eha)/(uhb-uha)*(ux-uha);
	etat2=Etat(milMat[1],"Etat 2",ρ2x,E2x)
	etat3=Etat(milMat[2],"Etat 3",ρ3x,E3x)
	Dd=-ρ2x*etat2.c;
	Dh= ρ3x*etat3.c;
	(Pdx,Edx,udx)   =Isentrope(gp,etat1,0.0,ρ2x);
	(Phx,Ehx,uhx,Dhx)= Hugoniot(gp,etat4,0.0,ρ3x);
	ux=(Pdx-Dd*udx-(Phx-Dh*uhx))/(Dh-Dd)
	Px=(Dh*(Pdx-Dd*udx)-Dd*(Phx-Dh*uhx))/(Dh-Dd)
#end	
println("P* = ",Px,"	u*=",ux)

(Pd,Ed,ud)   =Isentrope(gp,etat1,0.0,ρ2x)
(Ph,Eh,uh,Dh)= Hugoniot(gp,etat4,0.0,ρ3x)
etat2=Etat(milMat[1],"etat2 (détente)",ρ2x,Ed)
etat3=Etat(milMat[2],"etat3 (Choc)",ρ3x,Eh)
AffEtat(etat1)
AffEtat(etat2)
AffEtat(etat3)
AffEtat(etat4)
#figPu = plot(df.u,df.p,xlabel="u (m/s)",ylabel="p (GPa)",title=nom,label="P(u)")
#figPu=scatter([cas.milieux[2].u,ux],[etat4.P,Px],label="Choc")
#figPu=scatter!([cas.milieux[1].u,ux],[etat1.P,Px],label="Détente")
#figρe = plot(df.ρ,df.e,xlabel="ρ (kg/m3)",ylabel="e (J/kg)",title=nom,label="e(ρ)")
#figρe=scatter([etat1.ρ,etat2.ρ,etat3.ρ,etat4.ρ],[etat1.E,etat2.E,etat3.E,etat4.E],label="Solution exacte")

N=10
rh=zeros(Float64, N);ph=zeros(Float64, N);rs=zeros(Float64, N);ps=zeros(Float64, N);
us=zeros(Float64, N);uh=zeros(Float64, N);vh=zeros(Float64, N);vs=zeros(Float64, N);
eh=zeros(Float64, N);es=zeros(Float64, N);ch=zeros(Float64, N);cs=zeros(Float64, N);

for i=1:N	
	ρ=((i*etat1.ρ)+(N-i)*etat2.ρ)/N
        (ps[i],es[i],us[i] )  =Isentrope(gp,etat1,0.0,ρ)
        println(ρ,"	",ps[i]," 	",es[i],"	",us[i])
        rs[i]=ρ
end 

for i=1:N
	local Dh
	ρ=((i*etat3.ρ)+(N-i)*etat4.ρ)/N
	(ph[i],eh[i],uh[i],Dh)   =Hugoniot(gp,etat4,0.0,ρ)
        println(ρ,"        ",ph[i],"         ",eh[i],"        ",uh[i],"	",Dh)
end


