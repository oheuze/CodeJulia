#ifndef _LecteurMap_H 
#define _LecteurMap_H 

#include <string> 
#include <iostream> 
#include <vector> 
#include "LecteurDonnees.hpp"
#include "ParserSAX.hpp"
#include "MapHandler.hpp"

using namespace std;

class LecteurMap 
{ 
	public: 
	string nom; 
	map <string,string> parametres;
	
	LecteurMap(); 	
	~LecteurMap(); 

	int LireDonnees(string ficXML); 
	void ecrire(); 
	
} ; 

#endif 

