module Hybride
# OH 10/12/2022

import EzXML, MieGru
using EzXML , Plots, Colors, DataFrames, MieGru
export Init,Lecture,Montage,Diag,AfficheCase,getZone,Phases,Vunit,Eunit,Punit,grille,geom,typeCaseInt

Segment=Vector{Float64}
codeVide=1
codeMono=2
codeMixte=3
codeMulti=4
codePhase=1
codeMel=2
codePtTriple=3
strVide="Vide"
strMono="Mono"
strMixte="Mixte"
strMulti="Multi"
chrVide ="."
chrMono ="o" 
chrMixte="+"           
chrMulti="x"

mutable struct BoxMono
	zone::Int
end

mutable struct BoxMixte           
	zones::Vector{Int8}
	segment::Segment
end    

mutable struct ZoneGeom
	zone::Int
	segments::Vector{Segment}
end

mutable struct BoxMulti
	zoneGeom::Vector{ZoneGeom}
end

struct ParametresHybride
	ficXML :: String
end

function Init(parametres::ParametresHybride)
	LectureXML(parametres.ficXML)
	global Vunit=parse(Float64,vunit);
	global Punit=parse(Float64,punit);
	global Eunit=parse(Float64,eunit);
	Montage()
	Diag()
	Phs=[];
	for i=1:nPh
		tagi=zones[i]
		push!(Phs,MieGru.TagToParams(tagi))
	end
	return Phs
end

function getCases(chaine)	# chaine="{{1,2},  ...,{5,4}}"
	x=[]
	while length(chaine) >0
       	fin=SubString(chaine,1,findfirst("}",chaine)[1])
               strIJ=SubString(fin,findlast("{",fin)[1]);
               chaine=SubString(chaine,findfirst("}",chaine)[1]+2)
               i,j=ExtractIJ(strIJ)
               push!(x,[ i j ])
       end
       x
       # ->  x= [ [1,2],...,[5,4] ]
end

function ExtractIJ(chaine)	# chaine= "{1,2}"
	fin=SubString(chaine,1,findfirst("}",chaine)[1]-1)
	milieu=SubString(fin,findlast("{",fin)[1]+1)
	i=parse(Int,split(milieu,",")[1])
	j=parse(Int,split(milieu,",")[2])
	return  i,j
	#  ->  1,2
end
	
function extractSegment(chaine)
	pts=split(chaine,";")
	pt1=split(pts[1],",")
	pt2=split(pts[2],",")
        x1=parse(Float64,SubString(pt1[1],findfirst("(",pt1[1])[1]+1))
        y1=parse(Float64,SubString(pt1[2],1,findfirst(")",pt1[2])[1]-1))
        x2=parse(Float64,SubString(pt2[1],findfirst("(",pt2[1])[1]+1))
        y2=parse(Float64,SubString(pt2[2],1,findfirst(")",pt2[2])[1]-1))
        return [x1 y1;x2 y2]
end

function StrToZones(chaine)
	if typeof(findfirst("{",chaine))==Nothing println("Erreur : " ,chaine) end
	milieu=SubString(chaine,findfirst("{",chaine)[1]+1,findfirst("}",chaine)[1]-1)
	zs=split(milieu,",")
	z1=parse(Int,zs[1])
	z2=parse(Int,zs[2])
       return [z1 z2]
end
       
function cutSegs(segs)
	x=[]
	while typeof(findfirst("]",segs))!=Nothing
		pos=findfirst("]",segs)[1]+1
		seg1=SubString(segs,1,pos)
		segs=SubString(segs*" ",pos);
		push!(x,extractSegment(seg1));
	end
	return x
end

function Case(i,j)
	vmin=Vmin+(i-1)*(Vmax-Vmin)/nV
	vmax=Vmin+i*(Vmax-Vmin)/nV
	emin=Emin+(j-1)*(Emax-Emin)/nE
	emax=Emin+j*(Emax-Emin)/nE
	return [vmax,vmin,vmin,vmax],[emax,emax,emin,emin]	
end			

function Contour(i,j)
	vmin=Vmin+(i-1)*(Vmax-Vmin)/nV
	vmax=Vmin+i*(Vmax-Vmin)/nV
	emin=Emin+(j-1)*(Emax-Emin)/nE
	emax=Emin+j*(Emax-Emin)/nE
	listX=[vmin,vmax,vmax,vmin,vmin]
	listY=[emin,emin,emax,emax,emin]
	return [listX,listY]
end			

function AffMixte(i,j) 
	zS,zI=grille[i,j]
	seg=geom[i,j]
	v1,v2,e1,e2=seg
	shapeS= [ (v1,e1),(v2,e2) ]
	shapeS= [ (v2,e2),(v1,e1) ]
	shapeI= [ (v1,e1),(v2,e2) ]
	listV,listE=Contour(i,j)
	#plot!(listV,listE,fill=true,fillcolor=couleur[zI],linecolor=couleur[zI],label="")
	for k=1:4
		vk,ek = listV[k],listE[k]
		if InEq(vk,ek,v1,e1,v2,e2)>0
			push!(shapeS, ( vk,ek ))
               else
			push!(shapeI, ( vk,ek ))
               end
	end 
	plot!(EnvConvXY(shapeS),fill=true,fillcolor=couleur[zS],linecolor=couleur[zS],label="")
	plot!(EnvConvXY(shapeI),fill=true,fillcolor=couleur[zI],linecolor=couleur[zI],label="")
	plot!()
end

function getZone(V,E)
	zone=0
	i =trunc(Int32,1.0+(V-Vmin)/(Vmax-Vmin)*nV)
	j =trunc(Int32,1.0+(E-Emin)/(Emax-Emin)*nE)
	if (i<1)||(i>nV) println("V	Hors zone : V= ",V,"	E= ",E) end
	if (j<1)||(j>nE) println("E	Hors zone : V= ",V,"	E= ",E) end
	#println([V,E]," -> case ",i," , ",j,"    , ",grille[i,j])
	if typeCaseInt[i,j]==codeMono
		zone=grille[i,j]
        	#println("Zone ",zone,"   :  ",Nom[zone])
	end
    	if typeCaseInt[i,j]==codeMixte
	        x1,x2,y1,y2=geom[i,j]
	        zS,zI=grille[i,j]
	        if InEq(V,E,x1,y1,x2,y2)>0
        		zone=zS
			#println("Zone ",zS,"   :  ",Nom[zS])
		else
			zone=zI
			#println("Zone ",zI,"   :  ",Nom[zI])                    	
		end	
	end
	if typeCaseInt[i,j]==codeMulti
		for k=1:length(geom[i,j])
            		segsZk=geom[i,j][k]
            		ok=true
            		for p=1:length(segsZk)
				x1,x2,y1,y2=segsZk[p]
				ok=ok&&InEq(V,E,x1,y1,x2,y2)>0
			end
			if ok
				zone=grille[i,j][k]
               		#println("Zone ",zone,"   :  ",Nom[zone])
            		end		
		end	
	end
	#scatter!([V],[E],label="")
	return zone
end
       
function AffMulti(i,j)
	listV,listE=Contour(i,j)
	# k=zone,  p=segment, q= coin
	for k=1:length(geom[i,j])
		segsZk=geom[i,j][k]
		z=grille[i,j][k]
		shape=[]
		coin=[true true true true]
		for p=1:length(segsZk)
			v1,v2,e1,e2=segsZk[p]
			push!(shape,(v1,e1))
			push!(shape,(v2,e2))
			for q=1:4
				vq,eq = listV[q],listE[q]
				coin[q]=coin[q]&&InEq(vq,eq,v1,e1,v2,e2)>0
			end
		end
		for q=1:4
			if coin[q]
				vq,eq = listV[q],listE[q]
				push!(shape, ( vq,eq ))
			end	
		end 
		plot!(EnvConvXY(shape),fill=true,fillcolor=couleur[z],linecolor=couleur[z],label="")
	end  
	plot!()                   
end
      
function AffMultiZ(i,j,k)
	listV,listE=Contour(i,j)
	# k=zone,  p=segment, q= coin
	segsZk=geom[i,j][k]
	z=grille[i,j][k]
	shape=[]
	coin=[true true true true]
	for p=1:length(segsZk)
		v1,v2,e1,e2=segsZk[p]
		push!(shape,(v1,e1))
		push!(shape,(v2,e2))
		for q=1:4
			vq,eq = listV[q],listE[q]
			coin[q]=coin[q]&&InEq(vq,eq,v1,e1,v2,e2)>0
		end
	end
	for q=1:4
		if coin[q]
			vq,eq = listV[q],listE[q]
			push!(shape, ( vq,eq ))
		end	
	end  
	println(EnvConvXY(shape))
	plot!(EnvConvXY(shape),linecolor=:red,label="")
	scatter!(EnvConvXY(shape),linecolor=:red,label="")
	plot!()                   
end      
      
function AffMultiPts(i,j)
	geo=geom[i,j]
	for k=1:length(geo)
		segsZk=geo[k]
		z=grille[i,j][k]
		listV=Float64[];listE=Float64[]
		for p=1:length(segsZk)
			v1,v2,e1,e2=segsZk[p]
			push!(listV,v1);push!(listV,v2)
			push!(listE,e1);push!(listE,e2)
			scatter!(listV,listE,label="")
		end  
	end	
	plot!()                   
end
  
function AfficheCase(p,q)
	vstep=(Vmax-Vmin)/nV
	estep=(Emax-Emin)/nE
	vmin=Vmin+(p-1)*vstep
	vmax=Vmin+p*vstep
	emin=Emin+(q-1)*estep
	emax=Emin+q*estep
	println(geom[p,q])
	titre="case "*string(p)*"-"*string(q)*" : "*string(grille[p,q])
	plot([vmin-vstep,vmin-vstep,vmax+vstep,vmax+vstep],[emin-estep,emax+estep,emin-estep,emax+estep], label="",title=titre,xlims=(vmin-vstep,vmax+vstep),ylims=(emin-estep,emax+estep))
	for i=p-1:p+1
		for j=q-1:q+1
        		if typeCaseInt[i,j]==codeVide
               			plot!(Case(i,j),fillcolor=:lightblue,linecolor=:lightblue,label="")
            		end     
            		if typeCaseInt[i,j]==codeMono
               			coul=couleur[grille[i,j]]
               			plot!(Case(i,j), fill=true,fillcolor =coul, linecolor =coul,label="")
            		end
            		if typeCaseInt[i,j]==codeMixte
               			AffMixte(i,j)
            		end
            		if typeCaseInt[i,j]==codeMulti
               			AffMulti(i,j)	
            		end
        	end
	end
    	#println(grille[p,q])
    	#println(geom[p,q])
	plot!([vmin,vmax,vmax,vmin,vmin],[emin,emin,emax,emax,emin],linecolor=:blue,label="")
	plot!()
end

function StrToInt(chaine)
	milieu=SubString(chaine,findfirst("{",chaine)[1]+1,findfirst("}",chaine)[1]-1);
	zs=split(milieu,",");
	zz=Int[];
	for i=1:length(zs) 
		push!(zz,parse(Int,zs[i]))
	end  
	return zz
end
       
function InEq(x,y,x1,y1,x2,y2)
       ( y2 - y1)* x - (x2 - x1)* y + x2* y1 - x1* y2
end

function EnvConvXY(Points)	# Point= [ (xi,yi) for i=1:20 ]
	# enveloppe convexe , algorithme de Graham
	points=sort(DataFrame(pts=Points)).pts
        pente=[-10.0^10]
	for i=2:length(points)
       	push!(pente,(points[i][2]-points[1][2])/max(points[i][1]-points[1][1],0.000001))
 	end
 	df1=DataFrame(pts=points,pnt=pente) 	
	sorted=sort(df1,[:pnt]).pts
	#println("List ",sorted)
	envConv=[]
	push!(envConv,sorted[1])
	push!(envConv,sorted[2])
	for i=3:length(points)
 		while (length(envConv)>2)&&ProdVect(envConv[length(envConv)-1],envConv[length(envConv)],sorted[i])<0
 			pop!(envConv)
 		end
 		push!(envConv,sorted[i])
 	end
	push!(envConv,envConv[1])
	#println("E ",envConv)
 	listX=[]
	listY=[]
	for i=1:length(envConv) 
        	push!(listX,envConv[i][1])
        	push!(listY,envConv[i][2])
        end
 	return listX,listY
end

function ProdVect(A, B, C)
       return (B[1] - A[1]) * (C[2] - A[2]) - (C[1] - A[1]) * (B[2] - A[2])
end       

function convertInttoString(TCint)
	#  conversion de typeCase en String
	dictCodeStr=Dict(codeVide=>chrVide,codeMono=>chrMono,codeMixte=>chrMixte,codeMulti=chrMulti)
	tc=""
	for j=1:nE
		for i=1:nV
                	#println(i," , ",j," : ",typeCaseInt[i,j])
                 	#if TCint[i,nE+1-j]==codeVide        ycase=chrVide end
                 	#if TCint[i,nE+1-j]==codeMono        ycase=chrMono end
                 	#if TCint[i,nE+1-j]==codeMixte       ycase=chrMixte end           
                 	#if TCint[i,nE+1-j]==codeMulti       ycase=chrMulti end
                 	tc=tc*dictCodeStr[TCint[i,nE+1-j]]
                 end
                 tc=tc*"\n"
	end
	return tc
end

function convertStringToInt(DiagStr::String)
	#  conversion de String en typeCaseInt 
	dictChrCode=Dict(chrVide=>codeVide,chrMono=>codeMono,chrMixte=>codeMixte,chrMulti=>codeMulti)
	global typeCaseInt = Array{Int}(undef,nV,nE)
	for j=1:nE
		strj=SubString(DiagStr,1+(j-1)*(nV+1),j*(nV+1))
		for i=1:nV
                	strij=SubString(strj,i,i)
                	#println(i," , ",j," : ",typeCase[i,j])
                 	#if strij==chrVide  typeCaseInt[i,nE+1-j]=codeVide; end
                 	#if strij==chrMono  typeCaseInt[i,nE+1-j]=codeMono; end
                 	#if strij==chrMixte typeCaseInt[i,nE+1-j]=codeMixte;end           
                 	#if strij==chrMulti typeCaseInt[i,nE+1-j]=codeMulti;end
                 	typeCaseInt[i,nE+1-j]=dictChrCode[strij]
                 end
	end
	#println("TypeCaseInt= ",typeCaseInt)
	return typeCaseInt
end

function LectureXML(FicXML)
	monxml=EzXML.readxml(FicXML)
	racine=monxml.root
	# noeuds=Materiau,GeomUnits,Cadre,Equations,Zones,Geometrie
	noeuds=EzXML.elements(racine)
	#for i=1:4
        #      println(noeuds[i])
        #      for j=1:length(EzXML.attributes(noeuds[i]))
        #              println("\t",EzXML.attributes(noeuds[i])[j])
        #      end
	#end    
	global vunit="1"
	global punit="1"
	global eunit="1"
	for i=1:length(noeuds) 
	       if haskey(noeuds[i],"nom")	global mat=noeuds[i]["nom"];end
	       if haskey(noeuds[i],"P")		global punit=noeuds[i]["P"];end
	       if haskey(noeuds[i],"V")		global vunit=noeuds[i]["V"];end
	       if haskey(noeuds[i],"E")		global eunit=noeuds[i]["E"];end
	       if haskey(noeuds[i],"Vmin") 	global Vmin=parse(Float64,noeuds[i]["Vmin"]);end
	       if haskey(noeuds[i],"Vmax")	global Vmax=parse(Float64,noeuds[i]["Vmax"]);end
	       if haskey(noeuds[i],"Emin")	global Emin=parse(Float64,noeuds[i]["Emin"]);end
	       if haskey(noeuds[i],"Emax")	global Emax=parse(Float64,noeuds[i]["Emax"]);end
	       if haskey(noeuds[i],"nV")	
	       		global NV=noeuds[i]["nV"]
	           	global nV=parse(Int64,noeuds[i]["nV"])
	       end
	       if haskey(noeuds[i],"nE") 
	           global NE=noeuds[i]["nE"]
	           global nE=parse(Int64,noeuds[i]["nE"])
	       end
	       if haskey(noeuds[i],"Vscale")  global Vscale=noeuds[i]["Vscale"];end
	       if haskey(noeuds[i],"Escale")  global Escale=noeuds[i]["Escale"];end
	       if  EzXML.nodename(noeuds[i])=="Equations"	global eos=EzXML.elements(noeuds[i]);end
	       if  EzXML.nodename(noeuds[i])=="Zones"		global zones=EzXML.elements(noeuds[i]);end
	       if  EzXML.nodename(noeuds[i])=="Geometrie"	global mailles=EzXML.elements(noeuds[i]);end
	end
	#global cadre = Shape([(Vmax,Emax), (Vmin,Emax), (Vmin,Emin), (Vmax,Emin)])
	plot([Vmax,Vmin,Vmin,Vmax],[Emax,Emax,Emin,Emin],fill=true, 
		fillcolor = :white,title=mat*"-"*NV*"x"*NE,label="",xlabel="V",ylabel="E")
	println("Matériau : ",mat)
	println("Unités   : P:",punit," , V:",vunit," , E:",eunit)
	println("Cadre    : Vmin=",Vmin," , Vmax=",Vmax," , Emin=",Emin," , Emax=",Emax)
	println("nV=",nV,"  nE=",nE)
	println("Echelles : Vscale= ",Vscale," , Escale= ",Escale)
	
	global codeEOS = Array{Int, 1}(undef,length(zones));
	global Nom = Array{String, 1}(undef,length(zones));
	global Phases= Array{Any, 1}(undef,length(zones));
	global couleur = Array{Any, 1}(undef,length(zones));
	global typeMaille = Array{String, 1}(undef,length(mailles));
	global Vides=[]
	global nPh
	dictModele=Dict()
	for i=1:length(eos)
	        push!(dictModele,eos[i]["modele"]=>i)
	end
	Couleur=Dict(1=>colorant"navajowhite",2=>colorant"gray",3=>colorant"yellow")
	for i=1:length(zones)
        	Nom[i]=zones[i]["Nom"]
        	codeEOS[i]=dictModele[zones[i]["EOS"]]
        	couleur[i]=Couleur[codeEOS[i]]
		if codeEOS[i]==codePhase 
               		Phases[i]=parse(Int,zones[i]["Num"]) 
               		nPh=i;
           	else 
               		Phases[i]=StrToInt(zones[i]["Phases"]) 
           	end
	end
	global diagStr=""
	for i=1:length(mailles)
        	typeMaille[i]=mailles[i].name
        	if mailles[i].name=="CasesVE" 
        		diagStr=mailles[i]["DiagStr"]
        		println(replace(diagStr," "=>"\n"))
		end
	end
	println(nPh," phases : ",@view Nom[1:nPh])
	println(length(zones)," zones : ",Nom)
end

function Montage()
# Construction de grille et geom
	global typeCaseInt=convertStringToInt(diagStr)
	global grille = Array{Any}(undef,nV,nE)
	global geom   = Array{Any}(undef,nV,nE)
	for i=1:nV for j=1:nE grille[i,j]="" end end
	#	cases Vides
	for i=1:nV
		for j=1:nE
			if typeCaseInt[i,j]==codeVide 
				grille[i,j]="." 
				geom[i,j]="."
			end
		end
	end		
	# repartition dans grille, geom
	for k=1:length(mailles)
		#	cases Mono
		if  typeMaille[k]==strMono
			zone=parse(Int,mailles[k]["zone"])
			casesMonoI=getCases(mailles[k]["cases"])
			for q=1:length(casesMonoI)
				i=casesMonoI[q][1]
				j=casesMonoI[q][2]
				grille[i,j]=zone
				geom[casesMonoI[q][1],casesMonoI[q][2]]="-"
			end
		end
		#	cases Mixte		
		if  typeMaille[k]==strMixte
			Cases=EzXML.elements(mailles[k])
			for q=1:length(Cases)
				case=getCases(Cases[q]["case"])[1]
				seg=extractSegment(Cases[q]["segment"])
				zones=StrToZones(mailles[k]["zones"])
				i=case[1]
				j=case[2]
				grille[i,j]=zones
				geom[i,j]=seg
				#println("Mixte (",case[1]," , ",case[2],") : ",zones,seg)
			end	
		end	
		#	cases Multi
		if  typeMaille[k]==strMulti
			case=getCases(mailles[k]["Case"])[1]
			zonesGeom=EzXML.elements(mailles[k])
			listSegs=[]
			zonesMulti=Int[]
			for q=1:length(zonesGeom)
				#println(zonesGeom[q])
				push!(zonesMulti,parse(Int,zonesGeom[q]["zone"]))
				segments=zonesGeom[q]["segments"]
				push!(listSegs,cutSegs(segments))
			end
			#println("Multi ",zonesMulti,listSegs)
			i=case[1]
			j=case[2]
			grille[i,j]=zonesMulti
			geom[i,j]=listSegs
		end
	end
end

function Diag()
	titre=mat*"  "*string(nV)*"x"*string(nE)
	plot(xlims=(Vmin,Vmax),title=titre,xlabel=string(10^6)*" V (kg/m^3)",ylabel="E (J/kg)")
	for i=1:nV
		for j=1:nE
			#println(i," , ",j," ->",typeCase[i,j]," , ",geom[i,j]," , ",grille[i,j])
			#	cases Vide
			if  typeCaseInt[i,j]==codeVide
				plot!(Case(i,j),fill=true, fillcolor=:lightblue,label="")
			end
			#	cases Mono
			if  typeCaseInt[i,j]==codeMono
				zone=grille[i,j]
				plot!(Case(i,j),fill=true,fillcolor=couleur[zone],linecolor=couleur[zone],label="")
			end
			#	cases Mixte		
			if  typeCaseInt[i,j]==codeMixte
				AffMixte(i,j)
			end
			#	cases Multi
			if  typeCaseInt[i,j]==codeMulti
				AffMulti(i,j)		
			end	
		end
	end
	#  affichage des noms de phase
	for n=1:nPh
		ntot=0;vtot=0;etot=0;
		for i=1:nV
			for j=1:nE
				if grille[i,j]==n 
					ntot=ntot+1
					vtot=vtot+Vmin+(i-0.5)*(Vmax-Vmin)/nV
					etot=etot+Emin+(j-0.5)*(Emax-Emin)/nE
				end
			end
		end
		scatter!(ann=[(vtot/ntot,etot/ntot,Nom[n])])
	end
	println("Affichage terminé")
	help()
	plot!()
end 

function help()
	println("taper :")
	println(" Hybride.AfficheCase(i,j) 	pour afficher la case (i,j).")
	println(" Hybride.getZone(V,E) 		pour déterminer la zone d'un point (V*1e-6,E) donné.")
	println(" Hybride.Diag() 		pour afficher le diagramme (V,E).")
	println(" Hybride.help() 		cette aide.")
end
function EOS!(ρ, e, P, T, c, G, ideb, ifin, Phs)
#	input : ρ, e, ideb, ifin, parametres
#	output : p, c, G (dérivée fondamentale)
	
	Threads.@threads for i in ideb:ifin
		zone=getZone(1/ρ[i]/Vunit,e[i]/Eunit)
		#if (zone!=1) println("Zone ",zone,"    i=",i,"   ρ= ",ρ[i],"   V= ",1/ρ[i],"   E= ",e[i])  end
		if (zone==0) zone=1 end
		if codeEOS[zone]==codePhase	
			etat=MieGru.Etat("Phase",ρ[i] , e[i],Phs[zone])
	        	P[i] = etat.P  
	        	T[i] = etat.T
	        	c[i] = etat.c  
			G[i] = 1.2        #  à calculer
	        end
		if codeEOS[zone]==codeMel
			pha,phb=Phases[zone]
			#println("Mélange ",Phs[pha].Nom," - ",Phs[phb].Nom)
			Va,Ea,Vb,Eb,λ=MieGru.SolveMelNewton(1/ρ[i],e[i],Phs[pha],Phs[phb],5)
			etata=MieGru.Etat("Phase",1/Va,Ea,Phs[pha])
			etatb=MieGru.Etat("Phase",1/Vb,Eb,Phs[phb])
			P[i] = etata.P
			T[i] = etata.T
			c[i] = etata.c  
			G[i] = 1.2        #  à calculer		
	        end
		if codeEOS[zone]==codePtTriple
			#println("Pt Triple")
			Pt=parse(Float64,zones[zone]["Pt"])
			Tt=parse(Float64,zones[zone]["Tt"])
			P[i] = Pt 
			T[i] = Tt                      
			c[i] = 1000  
			G[i] = 1.2        #  à calculer		
	        end
	end	        
end

end # module
