#ifndef _ETh_   
#define _ETh_

#include <string> 
#include <iostream> 
#include <sstream> 
#include <vector> 

using namespace std; 

class EtatThermo 
{ 

protected: 

public: 
	double ρ,E,P,T,S,c,𝒢;
	int zone=0;
	string nomZone="";
	
	EtatThermo(); 
	~EtatThermo(); 
	EtatThermo(double ρ,double E,double P,double T,double S,double c,double 𝒢);
	void ecrire();
	void setZone(int n,string nom);
}; 

string EtatsToTag(vector<EtatThermo> &Etats);
bool Egaux(EtatThermo EtatA,EtatThermo EtatB);

#endif
