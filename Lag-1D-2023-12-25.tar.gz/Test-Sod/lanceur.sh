#!/bin/bash

cat <<EOF > modifs.jl
riemann="acoustic";nom=riemann
include("Solution-Sod.jl")
EOF
julia Sod.jl

cat <<EOF > modifs.jl
riemann="three-term_acoustic";nom=riemann
EOF
julia Sod.jl

cat <<EOF > modifs.jl
riemann="exact_Godunov";nom=riemann
EOF
julia Sod.jl

cat <<EOF > modifs.jl
riemann="two-shock_Godunov";nom=riemann
EOF
julia Sod.jl

cat <<EOF > modifs.jl
riemann="weak-shock_Dukowicz";nom=riemann
EOF
julia Sod.jl


cat <<EOF > modifs.jl
riemann="one-iteration_acoustic";nom=riemann
EOF
julia Sod.jl


cat <<EOF > modifs.jl
riemann="two-iteration_acoustic";nom=riemann
EOF
julia Sod.jl

cat <<EOF > modifs.jl
riemann="strong-shock_Dukowicz";nom=riemann
EOF
julia Sod.jl

cat <<EOF > modifs.jl
riemann="two-rarefaction_Godunov";nom=riemann
EOF
julia Sod.jl

cat <<EOF > modifs.jl
riemann="acoustic";nom=riemann
EOF

julia ../PostProcessingAll.jl






