f=open(homedir()*"/.julia/logs/repl_history.jl")
lignes=readlines(f);
for i in length(lignes)-100:length(lignes)
	if ( findfirst("#",lignes[i])!=1:1 ) println(lignes[i]) end
end
close(f)


