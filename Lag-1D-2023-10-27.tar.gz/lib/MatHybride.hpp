//	OH-24-10-2023
#ifndef _Mat_Hybride_H
#define _Mat_Hybride_H

#include "Mat.h"
#include "PointXY.h"
#include "BiPoint.h"
#include "Box.h"
#include "ZoneGeom.h"
#include "ZoneParam.h"

class MatHybride : public Mat
{    
	protected:

	public:

	vector <ZoneParam> zonesP;  
	int nV,nE; 
	double Vmin,Vmax,Emin,Emax,Punit,Vunit,Eunit; 
	std::string Vscale,Escale; 
	vector < vector <Box>  > grille;
	vector <EoS*> eoz;

	MatHybride(const std::string material);
	void LireDonnees(std::string nomfic) override;
	int FindZone(double V,double E);
	bool ineqPos(double V, double E, BiPoint Bip);
	virtual void InitParam() override;
	virtual void calculPc(int ideb, int ifin, double* p, double* c, const double* ρ, const double* epsilon) override;
	virtual void calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* g, double* S, 
			const double* ρ, const double* epsilon) override;
	virtual void calculEtatsρT(int N, double* p, double* c, double* epsilon, 
			const double* ρ, const double* T) override;
	virtual void calculEtatVE(double v,double e) override;		
	virtual void ecrire() override;
};

#endif // _Mat_H
