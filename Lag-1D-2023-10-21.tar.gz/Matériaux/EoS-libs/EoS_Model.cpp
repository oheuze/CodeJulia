﻿#include "EoS.hpp"
#include <cmath>
#include <iostream>

//	OH	21-10-2023

class EoS_Model : public EoS {	

protected :
	
public:	
	// paramètres EoS_Model	
	double Vo,Ao,Bo,To,Eo,Gamma0,Cv;
	int n;
		
	// grandeurs EoS_Model	
	double theta,gamma;
	
	EoS_Model(map <string,string> Parametres){		
		parametres= Parametres;  
		cout << "	Initialisation EoS_Model  ("<< parametres.size() << " paramètres ) : ";
		zone = toInt("zone");
		EOS  = toString("EOS");
		nom  = toString("Nom");
		Vo = toDouble("Vo");
		n  = toInt("n");
		Gamma0 = toDouble("Gamma0");
		Cv = toDouble("Cv");
		Ao = toDouble("Ao");
		Bo = toDouble("Bo");
		To = toDouble("To");
		Eo = toDouble("Eo");
		ecrire();
	}

	void calculVE(int N, double* p,double* T,double* c, const double* v, const double* e) {
		for (int i = 0; i < N; i++) {
			p[i]= 0;
			T[i]= 0;
			S= 0;
			c[i]=0;	
    		}
    	}


	void calculρE(int N, double* p,double* T,double* c, const double* ρ, const double* e) {
		for (int i = 0; i < N; i++) {
			p[i]= 0;
			T[i]= 0;
			S= 0;
			c[i]=0;	
    		}
    	}
    	
	void calculEtatVE(double v,double e){
		V=v;
		E=e;
		gamma=Gamma0*V/Vo;
		P=Ao+Bo*pow(V/Vo,n)+gamma/V*E;
		T=To+(E-Eo)/Cv;
		c2=(gamma+1)*P*V;
		c=sqrt(c2);
	}

	void calculEtatVT(double v,double t){
		V=v;
		T=t;
		E = Eo + Cv*(T-To) ;
		P=Ao+Bo*pow(V/Vo,n)+gamma/V*E;
		c2=(gamma+1)*P*V;
		c=sqrt(c2);
	}

	void ecrire()
	{ 
		cout <<"EOS ="<< EOS << endl << "	";
		cout <<"Nom ="<< nom << " ,	";
		cout <<"Vo ="<< Vo << " ,	";
		cout <<"n  ="<< n << endl << "	";
		cout <<"Gamma0 ="<< Gamma0 << " ,	";
		cout <<"Cv ="<< Cv << " ,	";
		cout <<"Eo ="<< Eo << " ,	";
		cout <<"To ="<< To <<  endl;
	 } 
};

// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_Model(Parametres);	}
extern "C" void destroy(EoS* p) {	delete p;	}
