nom="Bi-Sn"
test=nom
include("../Lag-1D.jl")

