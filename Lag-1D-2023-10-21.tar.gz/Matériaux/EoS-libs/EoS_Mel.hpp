﻿#include "EoS.hpp"
#include <cmath>
#include <iostream>
#include <vector>

//	OH	21-10-2023

class EoS_Mel : public EoS 
{
protected:

public:
	int phA,phB;
	string nomPhA,nomPhB;
	double Va,Vb,Ea,Eb,x;
	
	EoS_Mel(map <string,string> Parametres);
	~EoS_Mel();
	
	void calculVE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S,
		const double* v, const double* e);
	void calculρE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S,
		const double* ρ, const double* e);
	void calculEtatVE(double v,double e);
	void calculEtatVT(double v,double t);
	void ecrire();
	void SolveNewton(double V,double E,int NiterMax);
	void SolveNewtonIter(double V,double E);
 };
 
// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_Mel(Parametres);	}
extern "C" void destroy(EoS* p) {	delete p;	}
