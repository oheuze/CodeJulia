#include "LecteurEtatThermo.hpp" 
#include "EtatThermo.h" 
	
LecteurEtatThermo::LecteurEtatThermo(){ 
	//cout <<" Appel de LecteurEtatThermo "<< endl;
} 

LecteurEtatThermo::~LecteurEtatThermo(){} 

void LecteurEtatThermo::ecrire(){ 
	//	cout <<" { ( "<< pt1.x <<" , "<< pt1.y <<" ) , ( "<< pt2.x <<" , " << pt2.y <<" ) } "; 
} 

int LecteurEtatThermo::LireDonnees(string ficXML) { 
	cout << "Fichier EtatThermo : " << ficXML << endl; 

	ParserSAX* parser =new ParserSAX();
	parser->detailed=false;
	EtatThermoHandler* handler = new EtatThermoHandler();
	parser->InitHandler(handler);
	parser->parse(ficXML);
	nom	= handler->nom;
	etats= handler->etatsThermo;

	return 0; 
} 
