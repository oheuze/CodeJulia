#ifndef _EoS_Mel_H
#define _EoS_Mel_H 
#include "EoS_Mel.hpp"

// OH-21-10-2023

EoS_Mel::EoS_Mel(map <string,string> Parametres){	
	parametres= Parametres; 
	//ecrire();
}

EoS_Mel::~EoS_Mel(){}
	
void EoS_Mel::calculVE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S, 
		 const double* v, const double* e) {
	for (int i = ideb; i <= ifin; i++) {
		// Calculer w et x 
		SolveNewton(v[i],e[i],5);
		p[i]= eosA->P;
		T[i]= eosA->T;
		c[i]= eosA->c;
		g[i]= 0;
		S[i]= 0;		
	}
}

void EoS_Mel::calculρE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S, 
		 const double* ρ, const double* e) {
	for (int i = ideb; i <= ifin; i++) {
		SolveNewton(1/ρ[i],e[i],5);
		p[i]= eosA->P;
		T[i]= eosA->T;
		c[i]= eosA->c;
		g[i]= 0;
		S[i]= 0;		
	}
}

void EoS_Mel::calculEtatVE(double v,double e){
	//cout << "*	V=" << v << " , E=" << e << endl;
	//cout << "*	mélange " << eosA->nom << "-" << eosB->nom << endl;
	//eosA->ecrire();
	//eosB->ecrire();
	SolveNewton(v,e,5);
	P= eosA->P;
	T= eosA->T;
	c= eosA->c;
	// double w=0;	//	à calculer
	g=0;
	S=0;
}

void EoS_Mel::calculEtatVT(double v,double t){
	V=v;
	T=t;
	//double w=0;//	résoudre T=at*(w*w-1)/4+(tp-tm)*w/2+(tp+tm)/2 en w;
	//double V1 = 0;
	//double E1 = 0;
	//double V2 = 0;
	//double E2 = 0;
	//double x= 0.5;
	P = 0;
	E = 0; 
	c2=1e6;
	c=sqrt(c2);
	S=0;
}
	
void EoS_Mel::ecrire(){ 
	EOS=parametres["EOS"];
	nom=parametres["Nom"];
	cout <<"EOS = "<< EOS << "	";
	cout <<"Nom = "<< nom <<   endl;
	eosA->ecrire();
	eosB->ecrire();
 } 

void EoS_Mel::SolveNewtonIter(double V,double E){
	double Pa,Pb,Ta,Tb,Sa,Sb,Ga,Gb;
	double DV,DS,DE,dG,dT,dP,dV,dE;
	double Pva,Pea,Tva,Tea,Pvb,Peb,Tvb,Teb;
	double Ja,Jb,Jab,Jba,Tba,Pba,dPa,dTa,dPb,dTb,DGa,DGb;
	double Wab,Wba,Zab,Zba,dPx,dTx,dGx,DGva,DGvb,DGea,DGeb,J,JGv,JGe,det;
	double dVa,dEa,dVb,dEb,dx;
	eosA->calculEtatVE(Va,Ea);
	eosB->calculEtatVE(Vb,Eb);
	Pa=eosA->P;	Pb=eosB->P;
	Ta=eosA->T;	Tb=eosB->T;
	Sa=eosA->S;	Sb=eosB->S;
	Ga=Ea+Pa*Va-Ta*Sa;Gb=Eb+Pb*Vb-Tb*Sb;
	DV=Vb-Va;
	DS=Sb-Sa;
	DE=Eb-Ea;
	dG=Gb-Ga;
	dT=Tb-Ta;
	dP=Pb-Pa;
	dV=V-(1-x)*Va-x*Vb;
	dE=E-(1-x)*Ea-x*Eb;
	//  dérivées
	Pva=eosA->Pv;
	Pea=eosA->Pe;
	Tva=eosA->Tv;
	Tea=eosA->Te;
	Pvb=eosB->Pv;
	Peb=eosB->Pe;
	Tvb=eosB->Tv;
	Teb=eosB->Te;
	//cout << "	Pva = " << Pva << "	Pea = " << Pea	 << "	-Pvb = " << -Pvb << "	-Peb = " << -Peb  << endl;
	//cout << "	Tva = " << Tva << "	Tea = " << Tea	 << "	-Tvb = " << -Tvb << "	-Teb = " << -Teb << endl;
	//	matA = [Pva            Pea            -Pvb          -Peb          	0
	//              Tva            Tea            -Tvb          -Teb          	0
	//             -Sa*Tva+Pva*Va -Sa*Tea+Pea*Va Sb*Tvb-Pvb*Vb Sb*Teb-Peb*Vb 	0
	//              1-x            0              x             0             	Vb-Va
	//              0              1-x            0             x             	Eb-Ea	]
        //Inversion de la matrice A 5x5  *)	
	Ja = Pva*Tea - Pea*Tva ; 
	Jb = Pvb*Teb - Peb*Tvb;
	Jab = Pva*Teb - Pea*Tvb ; Jba = Pvb*Tea - Peb*Tva;
	Tba = Tva*Teb - Tea*Tvb ; Pba = Pva*Peb - Pea*Pvb ;
	dPa = Pea*DE + Pva*DV; dTa = Tea*DE + Tva*DV;
	dPb = Peb*DE + Pvb*DV; dTb = Teb*DE + Tvb*DV;
	DGa = DV*dPa - DS*dTa; DGb = DV*dPb - DS*dTb;
	Wab = dTb*Pea - Tea*dPb; Wba = dTa*Peb - Teb*dPa;
	Zab = Tva*dPb - Pva*dTb; Zba = Tvb*dPa - Pvb*dTa;
	dPx = (Ja - Jab )*Va + (Jb - Jba )*Vb - DS*Tba;
	dTx = (Jba - Ja)*Sa + (Jab - Jb)*Sb - Pba*DV;
	dGx = Jba + Jab - Ja - Jb;
	DGva = DV*Pva - DS*Tva; DGea = DV*Pea - DS*Tea;
	DGvb = DV*Pvb - DS*Tvb; DGeb = DV*Peb - DS*Teb;
	J = (1 - x)*Jb + x*Ja;
	JGv = Jb*DGva*(1 - x) + DGvb*Ja*x; 
	JGe = Jb*DGea*(1 - x) + DGeb*Ja*x;
	det = Jb*DGa*(1 - x) + Ja*DGb*x;
	//  Solution
	//               invA = [Z11 Z12 Z13 Z14 Z15;
	//                       Z21 Z22 Z23 Z24 Z25;
	//                       Z31 Z32 Z33 Z34 Z35;
	//                       Z41 Z42 Z43 Z44 Z45;
	//                       Z51 Z52 Z53 Z54 Z55]/det
        double delta[6],invA[6][6],Delta[6];
	invA[1][1] =  (1 - x)*Jb*DV*Vb + x*(Tea*DGb - Wab*Va) ;
	invA[1][2] = -(1 - x)*Jb*DV*Sb + x*(Wab*Sa - Pea*DGb) ;
	invA[1][3] = -(1 - x)*Jb*DV + x*Wab  ;
	invA[1][4] =  Jb*DGea*DE ;
	invA[1][5] = -Jb*DGea*DV;
	invA[2][1] = (1 - x)*DE*Jb*Vb - x*(Tva*DGb + Zab*Va) ;
	invA[2][2] = -(1 - x)*DE*Sb*Jb + x*(Sa*Zab + Pva*DGb) ;
	invA[2][3] = -(1 - x)*Jb*DE  + x*Zab ;
	invA[2][4] = -Jb*DGva*DE ;
	invA[2][5] =  Jb*DGva*DV;
	invA[3][1] = -(1 - x)*(DGa*Teb + Wba*Vb)+ x*Ja*DV*Va  ;
	invA[3][2] =  (1 - x)*(Wba*Sb + DGa*Peb) - x*Ja*DV*Sa  ;
	invA[3][3] =  (1 - x)*Wba - x*Ja*DV  ;
	invA[3][4] =  Ja*DGeb*DE ;
	invA[3][5] = -Ja*DGeb*DV;
	invA[4][1] =  (1 - x)*(Tvb*DGa - Zba*Vb) +   x*DE*Ja*Va  ;
	invA[4][2] =  (1 - x)*( Sb*Zba - Pvb*DGa) -  x*DE*Sa*Ja ;
	invA[4][3] =  (1 - x)*Zba - x*Ja*DE  ;
	invA[4][4] = -Ja*DGvb*DE ;
	invA[4][5] =  Ja*DGvb*DV;
	invA[5][1] = -(1 - x)*Jb*Vb - x*Ja*Va + (1 - x)*x*dPx ;
	invA[5][2] =  (1 - x)*Jb*Sb +  x*Ja*Sa + (1 - x)*x*dTx ;
	invA[5][3] =  J + (1 - x)*x*dGx ;
	invA[5][4] =  JGv;
	invA[5][5] =  JGe;       
	//	Delta = [dP dT dG dV dE]
	Delta[1] = dP;
	Delta[2] = dT;
	Delta[3] = dG;
	Delta[4] = dV;
	Delta[5] = dE;
	//cout << "det = " << det << endl;
	//	produit  delta = invA*Delta
	for(int i=1;i<=5;i++){
		delta[i]=0;
		for(int j=1;j<=5;j++){
			delta[i]+=invA[i][j]*Delta[j]/det;
		}
	}
	dVa=delta[1] ;
	dEa=delta[2] ;
	dVb=delta[3] ;
	dEb=delta[4] ;
	dx=delta[5];
	Va+=dVa ;
	Ea+=dEa ;
	Vb+=dVb ;
	Eb+=dEb ;
	x+=dx;
	//cout << "	Va=" << Va << "	Ea = " << Ea << "	Vb = " << Vb << "	Eb = " << Eb << "	x = " << x << endl; 
	//return [VA EA VB EB x]
}

void EoS_Mel::SolveNewton(double V,double E,int NiterMax){
	Va=0.98*V;
	Ea=E;
	Vb=1.02*V;
	Eb=E;
	x=0.5;
	for (int i=1;i<=NiterMax;i++){
		SolveNewtonIter(V,E);
	}
//	return Va,Ea,Vb,Eb,x;
}

#endif
