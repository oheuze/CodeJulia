import Pkg
Pkg.status()
Pkg.add("CSV")
Pkg.add("CxxWrap")
Pkg.add("DataFrames")
Pkg.add("EzXML")
Pkg.add("Plots")
Pkg.add("Dates")
