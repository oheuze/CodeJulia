#  24/10/2023
using Printf

include("Thermo.jl")

struct EtatDyn
	Nom :: String
	P :: Float64
	ρ :: Float64
	T :: Float64
	S :: Float64
	E :: Float64
	g :: Float64
	c :: Float64
	u :: Float64
end

function Etat2(Mat,nom::String,ρ::Float64,E::Float64)::EtatThermo
    Materiau.calculEtatVE(Mat,1/ρ,e)
    return EtatThermo(nom,Mat.P,Mat.ρ,Mat.T,Mat.S,Mat.E,Mat.g,Mat.c)
end


function EDyn(Mat,nom::String,ρ::Float64,E::Float64,u::Float64)::EtatDyn
    local P = zeros(Float64, 3)
    local c = zeros(Float64, 3)
    local T = zeros(Float64, 3)
    local g = zeros(Float64, 3)
    local S = zeros(Float64, 3)
    local r= ones(Float64, 3).* ρ
    local e= ones(Float64, 3).* E
    Materiau.calculEtats(Mat,1,2,P,c,T,g,S,r,e)
    return EtatDyn(nom,P[2],ρ,T[2],S[2],E,g[2],c[2],u)
end

function EDyn2(Mat,nom::String,ρ::Float64,e::Float64,u::Float64)::EtatDyn
    Materiau.calculEtatVE(Mat,1/ρ,e)
    return EtatDyn(nom,Mat.P,Mat.ρ,Mat.T,Mat.S,Mat.E,Mat.g,Mat.c,u)
end

function RiemannAcoust(EtatG::EtatDyn,EtatD::EtatDyn)
	ρcG = EtatG.ρ*EtatG.c
	ρcD = EtatD.ρ*EtatD.c
	ustar = ( ρcG*EtatG.u + ρcD*EtatD.u + (EtatG.P - EtatD.P) ) / (ρcG + ρcD)
	pstar = ( ρcD*EtatG.P + ρcG*EtatD.P + ρcG*ρcD*(EtatG.u - EtatD.u) ) / (ρcG + ρcD)
	println("Acoustic  u* = ", ustar, " p* = " , pstar)   
	return ustar,pstar     		
end

function AffEtatsDyn(etats::Vector{EtatDyn})
        println("           │       P               ρ         E        T          c          S          g          u    ")
        println(" ──────────┼───────────────────────────────────────────────────────────────────────────────────────────")
	for i in 1:length(etats)
		@printf("%10s │ %12g %12g %8g %8g %14g %8g %8g  %8g \n",
	            etats[i].Nom,etats[i].P,etats[i].ρ,etats[i].E,etats[i].T,etats[i].c,etats[i].S,etats[i].g,etats[i].u)
	end
        println(" ──────────┼─────────────────────────────────────────────────────────────────────────────────")
end

function HugoniotDyn(Mat,Pole,ρ)
               #        pour une EE Mie-Grüneisen
               E1=0.0
               etat1=EDyn(Mat,"etatE1",ρ,E1,0.)
               E2=1000.0
               etat2=EDyn(Mat,"etatE2",ρ,E2,0.)
               Γρ = (etat2.P-etat1.P)/(E2-E1)
               Ph=(etat1.P+Γρ*(Pole.E+Pole.P*(1/Pole.ρ-1/ρ)/2))/(1. - Γρ*(1/Pole.ρ-1/ρ)/2)
               Eh=Pole.E+(Pole.P+Ph)*(1/Pole.ρ-1/ρ)/2
               u=Pole.u+sqrt((Ph-Pole.P)*(1/Pole.ρ-1/ρ))
               D=1/Pole.ρ*sqrt((Ph-Pole.P)/(1/Pole.ρ-1/ρ))
               etatH=EDyn(Mat,"EtatH",ρ,Eh,u)
               return etatH,D
end

function IsentropeDyn(Mat,Pole,ρ)
               #  cas ~général  dérivée fondamentale ~constante
               global Es=Pole.E
               for i=1:6        
                   is=EDyn(Mat,"Is1",ρ,Es,Pole.u)
                   dS=is.S-Pole.S
                   Es=Es-is.T*dS
               end
               etatS=EDyn(Mat,"Is",ρ,Es,Pole.u)  
               u=Pole.u-(etatS.c-Pole.c)/(etatS.g-1)
               etatS=EDyn(Mat,"EtatS",ρ,Es,u)  
               return etatS
end




