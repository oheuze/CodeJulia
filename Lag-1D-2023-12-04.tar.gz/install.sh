#!/usr/bin/bash

echo compilation du code
make clone_cxx_wrap_lib
make build_cxx_wrap_lib
make config_cmake
make compile
echo compilation des EoS
cd Matériaux/EoS-libs
make
make
make
make
make
make
make
make
cd ..
echo compilation des cas-tests en C++ des EoS 
#  GP
cd Essai-GP/build
cmake ..
make
cd src
./valid gp75.mat  gp-Points-VE.xml >mat-`date '+%Y-%m-%d'`.txt
./valid gp75.xml  gp-Points-VE.xml >xml-`date '+%Y-%m-%d'`.txt
cd ../../..
#  MGC
cd Essai-MGC/build
cmake ..
make
cd src
./valid Sn-β.mat  Sn-Points-VE.xml >mat-`date '+%Y-%m-%d'`.txt
cd ../../..
#  Bz
cd Essai-Bz/build
cmake ..
make
cd src
./valid Bz.mat  Bz-Points-VE.xml   >mat-`date '+%Y-%m-%d'`.txt
./valid Bizarrium.xml  Bz-Points-VE.xml   >xml-`date '+%Y-%m-%d'`.txt
cd ../../..
#  Hybride
cd Essai-Hybride/build
cmake ..
make
cd src
./valid Sn-thèse-24x35.xml  Sn-Points-VE.xml     >xml-`date '+%Y-%m-%d'`.txt
# xmgrace Sn-points.txt
# gnuplot gnuplot.txt
cd ../../../..
julia JuliaPkgAdd.jl
echo Lancement de tous les cas-tests hydro avec Julia
./lancer_tous_les_cas.sh
