#using Plots
include("../MateriauJ.jl")
include("../Thermo.jl")
cd("../Matériaux")
Sn = Materiau.MGC("Sn-β.xml")
Materiau.LireDonnees(Sn,"Sn-β.xml")
cd("../Test-Impact-Sn")
println("Propriétés d'un impact Sn-Sn à 1000 m/s")
println("pole=Etat(Sn,\"Pôle\",Materiau.getVal(Sn,\"ρ0\"),0.0)")
ρ0=Materiau.getVal(Sn,"ρ0")
pole=Etat(Sn,"Pôle",ρ0,0.0)
ρvals=Vector{Float64}(undef, 50)
pH    =Vector{Float64}(undef, length(ρvals))
uHproj=Vector{Float64}(undef, length(ρvals))
uHcibl=Vector{Float64}(undef, length(ρvals))
Vproj=1000
ρ=ρ0
etatH2=pole;
println("Recherche du croisement des polaires de choc (encadrement de la solution):")
while (etatH2.u < Vproj-etatH2.u)
	global etatH1=etatH2;
        global ρ+=200;  
        global etatH2=Hugoniot(Sn,"etatH2",pole,ρ);
        println("P = ",etatH2.P,"   ρ= ",etatH2.ρ,"  uProj=  ",Vproj-etatH2.u,"  uCibl= ",etatH2.u,"   ")
end
uh=Vproj/2
println("Convergence vers l'intersection :")
while (abs(etatH2.u-uh)>1e-5)
	pentePu=(etatH2.P-etatH1.P)/(etatH2.u-etatH1.u)
	pentePρ=(etatH2.P-etatH1.P)/(etatH2.ρ-etatH1.ρ)
	Ph=etatH2.P+(uh-etatH2.u)*pentePu
	ρh=etatH2.ρ+(Ph-etatH2.P)/pentePρ
	global etatH1=etatH2
	global etatH2=Hugoniot(Sn,"etatH",pole,ρh)
	AffEtat(etatH2)
end
etatH=etatH2
#D=1/pole.ρ*sqrt((etatH.P-pole.P)/(1/pole.ρ-1/etatH.ρ))
AffEtats([pole,etatH])
println("D=",D,"   m/s")
#plot(uHcibl,pH,xlabel="u (m/s)",ylabel="P (Pa)",label="Cible")
#plot!(uHproj,pH,label="Projectile")
