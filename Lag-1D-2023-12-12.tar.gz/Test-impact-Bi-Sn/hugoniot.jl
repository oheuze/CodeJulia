#  3/12/2022
import DataFrames
using Plots
println("Calcul de l'état de choc : résolution du problème de Riemann")
gauche=casTest.milieux[1]
droit =casTest.milieux[2]
poleG=MieGru.Etat("poleG",gauche.ρ,gauche.e,Snβ)
poleD=MieGru.Etat("poleD", droit.ρ, droit.e,Snβ)
function Riemann(PoleG,uG,MatG,PoleD,uD,MatD)
	ρmaxG=1.25*PoleG.ρ
	dv=(1/PoleG.ρ-1/ρmaxG)/20
	Pgz=[];ugz=[];
	for i=0:20
           V=1/PoleG.ρ-i*dv
           Py,Ey,uy,Dy=hugoniot(1/V,PoleG,MatG)
           push!(Pgz,Py/1e9)
           push!(ugz,uG-uy)
	end
	ρmaxD=1.25*PoleD.ρ
	dv=(1/PoleD.ρ-1/ρmaxD)/20
	Pdz=[];udz=[];
	for i=0:20
           V=1/PoleD.ρ-i*dv
           Py,Ey,uy,Dy=hugoniot(1/V,PoleD,MatD)
           push!(Pdz,Py/1e9)
           push!(udz,uy-uD)
	end
	plot(ugz,Pgz,xlabel="u (m/s)",ylabel="P (GPa)",
		title="P(u) Impact "*MatG.Nom*"-"*MatD.Nom,label="Projectile")
	plot!(udz,Pdz,label="Cible")
	savefig("Pu.pdf")
	iz=0
	for i=1:20
    		if ugz[i]<udz[i] && iz==0  iz=i end
	end
	Vd=1/PoleD.ρ-(iz-1)*dv
	Vg=1/PoleG.ρ-(iz+1)*dv
	ρ1=1/Vd;ρ2=1/Vg;
	# à revoir pour des matériaux différents
	ρcD=poleD.ρ*poleD.c
	ρcG=poleG.ρ*poleG.c
	ust=(poleD.P-poleG.P+ρcD*droit.u+ρcG*gauche.u)/(ρcD+ρcG)
	Pst=(ρcG*poleD.P+ρcD*poleG.P+ρcD*ρcG*(gauche.u-droit.u))/(ρcD+ρcG)
	for i=1:5
	       P1,E1,u1,D1=hugoniot(ρ1,PoleG,MatG)
	       P2,E2,u2,D2=hugoniot(ρ2,PoleD,MatD)
	       global ρst=ρ1+(ρ2-ρ1)/(u2-u1)*(ust-u1)
	       if abs(ρst-ρ1)>abs(ρst-ρ2) ρ1=ρst else ρ2=ρst end
	end
	hug=hugoniot(ρst,PoleG,MatG)
	println("	P* = ",hug[1])
	println("	u* = ",hug[3])
	println("	ρ* = ",ρh)
	println("	E* = ",hug[2])
	println("	D = ",hug[4])
	EtatChoc=MieGru.Etat("Etat choc",ρh,hug[2],MatG)
	Etats=[poleG,EtatChoc,EtatChoc,poleD]
	#dfR=DataFrame(Etats)
	#println(dfR)
	return Etats
end	
etatsChoc=Riemann(poleG,gauche.u,Snβ,poleD,droit.u,Snβ)

       


