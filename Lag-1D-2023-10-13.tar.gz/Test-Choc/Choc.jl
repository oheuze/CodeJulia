nom="Choc"
test=nom
include("../Lag-1D.jl")

