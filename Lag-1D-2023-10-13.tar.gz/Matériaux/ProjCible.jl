using Plots
nom="acoustic"
include("Init-Lag.jl")
gauche=EtatInitial[1];
droit=EtatInitial[2];
proj=milEoS[1];
cible=milEoS[2];
ρmax=8600;
u0=0;
x=zeros(10);
y=zeros(10);
x=zeros(10);
y=zeros(10);
for i=1:10
               local ρ=gauche.ρ+i*(ρmax-gauche.ρ)/10
               (Ph,Eh,uh,Dh)=Hugoniot(proj,gauche,u0,ρ)
               y[i]=Ph
               x[i]=uh
end
Pg=gauche.P
ug=cas.milieux[1].u
Pd=droit.P
ud=cas.milieux[2].u
ρcg=gauche.ρ*gauche.c
ρcd= droit.ρ*droit.c
ustar=(-Pg+ρcg*ug+Pd+ρcd*ud)/(ρcg+ρcd)
Pstar=(ρcd*Pg-ρcg*Pd+ρcg*ρcd*(ug+ud))/(ρcg+ρcd)
uxd=0;uxg=0;
global Pxg,Exg,uxg,Dxg,Pxd,Exd,uxd,Dxd;
(Pxg,Exg,uxg,Dxg)=Hugoniot(proj,gauche,0,1.1*gauche.ρ)
(Pxd,Exd,uxd,Dxd)=Hugoniot(cible,droit,0,1.1*droit.ρ)
dρg=gauche.ρ*uxg/(ug-ustar)/20
dρd=droit.ρ*uxd/(ustar-ud)/20
global ρg=gauche.ρ+dρg
global ρd=droit.ρ+dρd
global ρg0=ρg;global ρd0=ρd;global uxg0=uxg;global uxd0=uxd;
while (ug-uxd>uxg)
	global uxg0=uxg;global ρg0=ρg;
	global uxd0=uxd;global ρd0=ρd;
	global ρg=ρg+dρg
	global ρd=ρd+dρd
	global Pxg,Exg,uxg,Dxg,Pxd,Exd,uxd,Dxd;
	(Pxg,Exg,uxg,Dxg)=Hugoniot(proj,gauche,0,ρg)
	(Pxd,Exd,uxd,Dxd)=Hugoniot(cible,droit,0,ρd)
end
while (abs(uxg-ustar)>1e-5)
	dρdug=(ρg-ρg0)/(uxg-uxg0)
	dρdud=(ρd-ρd0)/(uxd-uxd0)
	global ρg,ρd;
	global uxg0=uxg;global ρg0=ρg;
	global uxd0=uxd;global ρd0=ρd;
	ρg=ρg0+dρdug*(ustar-uxg0)
	ρd=ρd0+dρdud*(ustar-uxd0)
	global Pxg,Exg,uxg,Dxg,Pxd,Exd,uxd,Dxd;
	(Pxg,Exg,uxg,Dxg)=Hugoniot(proj,gauche,0,ρg)
	(Pxd,Exd,uxd,Dxd)=Hugoniot(cible,droit,0,ρd)
end
println("ρg=",ρg,"	ug=",uxg,"	Pg=",Pxg)
println("ρd=",ρd,"	ud=",uxd,"	Pd=",Pxd)	





