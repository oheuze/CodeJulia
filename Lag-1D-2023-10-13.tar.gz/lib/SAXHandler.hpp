#ifndef _SAXHandler_ 
#define _SAXHandler_ 

#include <iostream> 
#include <map>
#include <math.h>
using namespace std;

class SAXHandler {

protected:

public:
	//map <string,string> parametres;
	//string caracteres;
	string argument;
	
	SAXHandler() { }
	virtual ~SAXHandler() {}
	
	virtual void StartDocument(){}
	virtual void StartElement(string Element, map<string,string> Attributs){}
	virtual void EndElement(string Element){}
	virtual void Characters(string CaracStr){}
	virtual void EndDocument(){}
};

#endif
