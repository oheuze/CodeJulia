riemann="two-iteration_acoustic";nom="MG-"*riemann
