riemann="acoustic";nom=riemann
include("Solution-Bizarrium.jl")
