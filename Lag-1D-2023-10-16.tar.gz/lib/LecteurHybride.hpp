#ifndef _LecteurHybride_H 
#define _LecteurHybride_H 

#include "LecteurDonnees.hpp"
#include "ParserSAX.hpp"
#include "HybHandler.hpp"
#include <string> 
#include <iostream> 

using namespace std; 

class LecteurHybride  : public LecteurDonnees
{ 
	public: 
	vector <ZoneParam> zonesP; 
	string element,atts,chaine,argument,biZone,listCases,strBox; 
	BiPoint bip,bipc;
	vector <BiPoint> bips; 
	map <string,string> attributs;
	int nZ,nz1,nz2;
	ofstream ficPts;
	
	int nV,nE; 
	double Vmin,Vmax,Emin,Emax,Punit,Vunit,Eunit; 
	std::string nom,Vscale,Escale; 
	Box boxIJ;
	vector < vector <Box>  > grille;
	vector <EoS*> eoz;

	LecteurHybride(); 	
	~LecteurHybride(); 

	int LireDonnees(std::string ficXML); 
	void ecrire(); 
	
} ; 

#endif 

