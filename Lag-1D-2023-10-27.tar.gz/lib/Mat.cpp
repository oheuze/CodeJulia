#include "Mat.h"
//
// Mat
//

Mat::Mat(const std::string material)
{
	//cout << "Fichier de Données : "  << material << endl;
}
	
void Mat::LireDonnees(std::string nomfic){
	LireDonneesStandard(nomfic);
}

void Mat::InitParam(){
	cout << "InitParam "  << endl ;
}

void Mat::ecrire(){
	cout << "ecrire "  << endl ;
}

void Mat::calculPc(int ideb, int ifin, double* p,double* c, 
		const double* ρ, const double* epsilon)
{
	for (int i = ideb; i <=ifin; i++) {
	        p[i] = (γ - 1.) * ρ[i] * epsilon[i];
        	c[i] = std::sqrt(γ * p[i] / ρ[i]);
        }	
}

void Mat::calculEtats(int ideb, int ifin, double* p,double* c,double* T, double* g, double* S, 
		const double* ρ, const double* epsilon)
{
	double v[ifin+1];
	for (int i = ideb; i <= ifin; i++) {
        	v[i]=1/ρ[i];
        }	
	//eos->calculVE(ideb,ifin,p,T,c,g,S,v,epsilon);
}
	
void Mat::calculEtatsρT(int N, double* p, double* c, double* epsilon, 
		const double* ρ, const double* T)
{
	for (int i = 0; i < N; i++) {
	        p[i] = ρ[i] * R * T[i];
        	c[i] = std::sqrt(γ * p[i] / ρ[i]);
        	epsilon[i] = R * T[i] /  (γ - 1.);
        }	
}
	
void Mat::calculEtatVE(double v,double e){
	cout << "Mat.cpp 	V= " << V << "	,	" << E << endl;
	V = v;
	E = e;
	P = (γ-1)* E/V;
        c = sqrt(γ * P * V);
       	T= 300.0;
       	// à compléter
       	S=0;
       	g=0;
       	H=E+P*V;
       	F=E-T*S;
       	G=F+P*V;        
}	

