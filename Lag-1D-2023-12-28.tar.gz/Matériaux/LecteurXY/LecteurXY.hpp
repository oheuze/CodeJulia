#ifndef _LecteurXY_H 
#define _LecteurXY_H 

#include <string> 
#include <iostream> 
#include <vector> 
#include "PointXY.h"
#include "ParserSAX.hpp"
#include "LecteurDonnees.hpp"
#include "XYHandler.hpp"

using namespace std;

class LecteurXY 
{ 
	public: 
	string nom;
	vector <PointXY> pointsXY; 
	
	LecteurXY(); 	
	~LecteurXY(); 

	int LireDonnees(string ficXML); 
	void ecrire(); 
	
} ; 

#endif 

