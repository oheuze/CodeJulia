﻿#include "EoS.hpp"
#include <cmath>
#include <iostream>

class EoS_Mel : public EoS 
{
protected:

public:
	double ax1,xm1,xp1,cx1,ay1,ym1,yp1,cy1;
	double ax2,xm2,xp2,cx2,ay2,ym2,yp2,cy2;
	double ap,pm,pp,at,tm,tp;
	
	EoS_Mel(map <string,string> Parametres){		
		parametres= Parametres;  
		cout << "	Initialisation EoS_Mel  ("<< parametres.size() << " paramètres ) : ";
		zone = toInt("zone");
		EOS  = toString("EOS");
		nom  = toString("Nom");
		ax1 = toDouble("ax1");
		xm1 = toDouble("xm1");
		xp1 = toDouble("xp1");
		cx1 = toDouble("cx1");
		ay1 = toDouble("ay1");
		ym1 = toDouble("ym1");
		yp1 = toDouble("yp1");
		cy1 = toDouble("cy1");
		ax2 = toDouble("ax2");
		xm2 = toDouble("xm2");
		xp2 = toDouble("xp2");
		cx2 = toDouble("cx2");
		ay2 = toDouble("ay2");
		ym2 = toDouble("ym2");
		yp2 = toDouble("yp2");
		cy2 = toDouble("cy2");
		ap = toDouble("ap");
		pm = toDouble("pm");
		pp = toDouble("pp");
		at = toDouble("at");
		tm = toDouble("tm");
		tp = toDouble("tp");
		ecrire();
	}

	void calculVE(int N, double* p,double* T,double* c, const double* v, const double* e) {
		for (int i = 0; i < N; i++) {
			p[i]= 0;
			T[i]= 0;
			S= 0;
			c[i]=0;	
    		}
    	}

	void calculEtatVE(double v,double e){
		V=v;
		E=e;
		//cout << "V=" << V << " , E=" << E << endl;
		double w=0;//	à calculer
		// double x=0.5;
		// V1 = cx1 + ax1*(w*w-1)/4+(xp1-xm1)*w/2+(xp1+xm1)/2;
		// E1 = cy1 + ay1*(w*w-1)/4+(yp1-ym1)*w/2+(yp1+ym1)/2;
		// V2 = cx2 + ax2*(w*w-1)/4+(xp2-xm2)*w/2+(xp2+xm2)/2;
		// E2 = cy2 + ay2*(w*w-2)/4+(yp2-ym2)*w/2+(yp2+ym2)/2;
		// Calculer w et x 
		P=ap*(w*w-1)/4+(pp-pm)*w/2+(pp+pm)/2;
		T=at*(w*w-1)/4+(tp-tm)*w/2+(tp+tm)/2;
		c2=Gamma*P*V;
		c=sqrt(c2);
		S=So;
	}

	void calculEtatVT(double v,double t){
		V=v;
		T=t;
		double w=0;//	résoudre T=at*(w*w-1)/4+(tp-tm)*w/2+(tp+tm)/2 en w;
		double V1 = cx1 + ax1*(w*w-1)/4+(xp1-xm1)*w/2+(xp1+xm1)/2;
		double E1 = cy1 + ay1*(w*w-1)/4+(yp1-ym1)*w/2+(yp1+ym1)/2;
		double V2 = cx2 + ax2*(w*w-1)/4+(xp2-xm2)*w/2+(xp2+xm2)/2;
		double E2 = cy2 + ay2*(w*w-2)/4+(yp2-ym2)*w/2+(yp2+ym2)/2;
		double x= (V-V1)/(V2-V1);
		P = ap*(w*w-1)/4+(pp-pm)*w/2+(pp+pm)/2;
		E = E1 + x * (E2-E1) ; 
		c2=Gamma*P*V;
		c=sqrt(c2);
		S=So;
	}
	
	void ecrire()
	{ 
		cout <<"EOS ="<< EOS << "	";
		cout <<"Nom ="<< nom <<   endl << "	";
		cout <<"ax1 ="<< ax1 << ",	";
		cout <<"xm1 ="<< xm1 << ",	";
		cout <<"xp1 ="<< xp1 << ",	";
		cout <<"cx1 ="<< cx1 << endl << "	";
		cout <<"ay1 ="<< ay1 << ",	";
		cout <<"ym1 ="<< ym1 << ",	";
		cout <<"yp1 ="<< yp1 << ",	";
		cout <<"cy1 ="<< cy1 << endl << "	";
		cout <<"ax2 ="<< ax2 << ",	";
		cout <<"xm2 ="<< xm2 << ",	";
		cout <<"xp2 ="<< xp2 << ",	";
		cout <<"cx2 ="<< cx2 << endl << "	";
		cout <<"ay2 ="<< ay2 << ",	";
		cout <<"ym2 ="<< ym2 << ",	";
		cout <<"yp2 ="<< yp2 << ",	";
		cout <<"cy2 ="<< cy2 << endl << "	";
		cout <<"ap ="<< ap << ",	";
		cout <<"pm ="<< pm << ",	";
		cout <<"pp ="<< pp  << endl << "	";
		cout <<"at ="<< at << ",	";
		cout <<"tm ="<< tm << ",	";
		cout <<"tp ="<< tp  << endl;
	 } 
 
 };
 
// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_Mel(Parametres);	}
extern "C" void destroy(EoS* p) {	delete p;	}
