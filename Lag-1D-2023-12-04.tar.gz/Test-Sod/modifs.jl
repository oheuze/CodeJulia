riemann="acoustic";nom=riemann
