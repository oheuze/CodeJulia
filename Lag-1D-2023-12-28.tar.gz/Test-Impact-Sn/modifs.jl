riemann="two-iteration_acoustic";nom=riemann
