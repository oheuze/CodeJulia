//	OH-11-12-2023
#ifndef _Mat_H
#define _Mat_H

#include <cmath>
#include <iostream>
#include <string>
#include <map>
#include <dlfcn.h>
#include "LecteurDonnees.hpp"
#include "EoS.hpp"
#include "PointXY.h"
#include "BiPoint.h"
#include "Box.h"
#include "ZoneGeom.h"
#include "ZoneParam.h"

typedef LecteurDonnees* create_l();
typedef void destroy_l(LecteurDonnees*);

using namespace std;

class Mat
{
    
protected:

public:
    Mat(){};
    Mat(const std::string material);
    virtual ~Mat() = default;

    map <string,string> parametres;
    double V,E,P,T,G,H,S,F,c,𝒢,Γ,Γρ;
    string nom,modele,materiau,EOS;
    double R=8.3143;
    double γ = 1.4 ;
    bool details=false;

	void foncA() 
	{
		parametres["Nom"]="mon nom";
		parametres["Prénom"]="mon prénom";
		parametres["Age"]="mon age";
		cout << "A " << parametres.size() << endl;
	};
		
	virtual void LireDonnees(std::string nomfic);
	virtual void InitParam() ;
	virtual void ecrire() ;		
	virtual void calculPc(int ideb, int ifin, double* p,double* c, const double* rho, const double* epsilon) ;
	virtual void calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* 𝒢, double* S, 
		 const double* rho, const double* epsilon) ;
	virtual void calculEtatsRhoT(int N, double* p, double* c, double* epsilon, 
			const double* rho, const double* T) ;	
	virtual void calculEtatVE(double v,double e) ;	
	virtual void ecrireEtat(){
		cout <<	"Etat thermo : " << endl;
		cout <<	"	V = " <<  V <<  "	E  = "<< E << "	ρ = " << 1/V << "	P = " << P << "	T = " << T << endl;
		cout <<	"	S = " <<  S <<  "	G = " << G << "	c = " <<  c <<  "	𝒢 = "<< 𝒢 << "	γ = " << γ << "	Γ = " << Γ << endl;
	}
	
	void detailler(){
		details=!details;
		if (details){
			cout << "détails affichés"<< endl;
		}
		else
		{
			cout << "détails cachés"<< endl;
		}
	}	
		
	void setParam(std::string& motclef,std::string& valeur)
	{
		cout << "setParam : "  << motclef << " -> " << valeur << endl;
		parametres[motclef]=valeur;
		cout << "---> " << parametres.size() << " paramètres. " << endl;
	
		map<string,string>::iterator it;
		for(it=parametres.begin(); it!=parametres.end(); ++it)
		{
			cout << it->first  << " = " << it->second << endl;
		}
	} ;
	
	double getVal(std::string& motclef)
	{
		if ( parametres.count(motclef)==0)  { cout << "#" << motclef << "# n'existe pas. " << endl; } 
		string valStr = parametres.find(motclef)->second;
		double val = atof(valStr.c_str());
		return val;
	} ;

	void AffParamMap(){
		cout << "Paramètres récupérés : " << endl;
		map<string,string>::iterator it;
		for(it=parametres.begin(); it!=parametres.end(); ++it){
			string nom=it->first;
			string valeur=it->second;
			parametres[nom]=valeur;
			cout << "	" << nom << " -> " << valeur << endl;
		}
		cout << "	->	" << parametres.size() << " paramètres " << endl;
		cout << "Fin"<< endl; 
	}	

	int toInt(string motclef){
		string valStr; 
		if ( parametres.count(motclef)==0)  { cout << "Le mot clef <" << motclef << "> n'existe pas. " << endl; } 
		try {
			valStr = parametres.at(motclef);
		}
		catch(const std::out_of_range& oor) {
		    cout << "mot clef " << motclef << "	non renseigné. " << endl;
		}
		int valeur = (int) stoi( valStr.substr(0,valStr.size()) );  
		return valeur; 
	};
	
	double toDouble(string motclef){		
	string valStr; 
		if ( parametres.count(motclef)==0)  { cout << "Le mot clef <" << motclef << "> n'existe pas. " << endl; } 
		try {
			valStr = parametres.at(motclef);
		}
		catch(const std::out_of_range& oor) {
		    cout << "mot clef " << motclef << "	non renseigné. " << endl;
		}
		double valeur = stod(valStr.substr(0,valStr.size())); 
		return valeur; 
	};	
		
	string toString(string motclef){		
		string valStr; 
		if ( parametres.count(motclef)==0)  { cout << "Le mot clef <" << motclef << "> n'existe pas. " << endl; } 
		try {
			valStr = parametres.at(motclef);
		}
		catch(const std::out_of_range& oor) {
		    cout << "mot clef " << motclef << "	non renseigné. " << endl;
		}
		string valeur = valStr.substr(0,valStr.size());
		return valeur; 
	};
	
	string toUpper(string chaine){
		string CHAINE="";
		for (int i=0; i< (int) chaine.size() ; i++) {
			char ch=(char)toupper(chaine[i]);
			string s=&ch;
			CHAINE=CHAINE+s[0];
		} ;
		return CHAINE;
	}
};

class MatGP : public Mat
{    
	protected:

	public:
	EoS* eos;
	
	MatGP(const std::string material);
	void LireDonnees(std::string nomfic) override;
	virtual void InitParam() override;
	virtual void calculPc(int ideb, int ifin, double* p, double* c, const double* rho, const double* epsilon) override;
	virtual void calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* 𝒢, double* S,  
			const double* rho, const double* epsilon) override;
	virtual void calculEtatsRhoT(int N, double* p, double* c, double* epsilon, 
			const double* rho, const double* T) override;
	virtual void calculEtatVE(double v,double e) override;			
	virtual void ecrire() override;
	
	void* openLib(string nomLib);	
	create_t* createur(void* handle);
	destroy_t* destructeur(void* handle);
};


class MatBz : public Mat
{    
	protected:

	public:

	double Ko,ρo,Cvo,To,εo,Γo,s,q,r;
	EoS* eos;
	
	MatBz(const std::string material);
	void LireDonnees(std::string nomfic) override;
	virtual void InitParam() override;
	virtual void calculPc(int ideb, int ifin, double* p, double* c, const double* rho, const double* epsilon) override;
	virtual void calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* 𝒢, double* S, 
			const double* rho, const double* epsilon) override;
	virtual void calculEtatsRhoT(int N, double* p, double* c, double* epsilon, 
			const double* rho, const double* T) override;
	virtual void calculEtatVE(double v,double e) override;		
	virtual void ecrire() override;
	
	void* openLib(string nomLib);	
	create_t* createur(void* handle);
	destroy_t* destructeur(void* handle);
};

class MatMGC : public Mat
{    
	protected:

	public:
	string  nom,modele,materiau,PhasesRef;
	int	zone,Num;
	double	ρ0,Ko,No,Γo,Cvr,θo,To,Po,ΔV,dPdT,Tmin,Tmax,Pmin,Pmax,Eo,Sr,ur;
	EoS* eos;
	
	MatMGC(const std::string material);
	void LireDonnees(std::string nomfic) override;
	virtual void InitParam() override;
	virtual void calculPc(int ideb, int ifin, double* p, double* c, const double* rho, const double* epsilon) override;
	virtual void calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* 𝒢, double* S, 
		 const double* rho, const double* epsilon) override;
	virtual void calculEtatsRhoT(int N, double* p, double* c, double* epsilon, 
			const double* rho, const double* T) override;
	virtual void calculEtatVE(double v,double e) override;		
	virtual void ecrire() override;
	
	void* openLib(string nomLib);	
	create_t* createur(void* handle);
	destroy_t* destructeur(void* handle);
};

class MatHybride : public Mat
{    
	protected:

	public:

	vector <ZoneParam> zonesP;  
	int nV,nE; 
	double Vmin,Vmax,Emin,Emax,Punit,Vunit,Eunit; 
	std::string Vscale,Escale; 
	vector < vector <Box>  > grille;
	vector <EoS*> eoz;

	MatHybride(const std::string material);
	void LireDonnees(std::string nomfic) override;
	int FindZone(double V,double E);
	bool ineqPos(double V, double E, BiPoint Bip);
	virtual void InitParam() override;
	virtual void calculPc(int ideb, int ifin, double* p, double* c, const double* rho, const double* epsilon) override;
	virtual void calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* 𝒢, double* S, 
			const double* rho, const double* epsilon) override;
	virtual void calculEtatsRhoT(int N, double* p, double* c, double* epsilon, 
			const double* rho, const double* T) override;
	virtual void calculEtatVE(double v,double e) override;		
	virtual void ecrire() override;

	void* openLib(string nomLib);	
	create_t* createur(void* handle);
	destroy_t* destructeur(void* handle);
};

#endif // _Mat_H
