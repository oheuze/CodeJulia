#include "EoS.hpp"
#include <cmath>
#include <iostream>

class EoS_SG : public EoS {

protected :
	
public:	
	double Po;	// paramètres du modèle
	
	EoS_SG(map <string,string> Parametres){		
		parametres= Parametres;  
		cout << "	Initialisation SG  ("<< parametres.size() << " paramètres ) : ";
		nom=toString("nom");
		R=toDouble("R");
		γ=toDouble("γ");
		Po=toDouble("Po");
		ecrire();
	}
	
	void calculVE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S, 
		 const double* v, const double* ) {
		for (int i = ideb-1; i < ifin; i++) {
			p[i]= 0;
			T[i]= 0;
			S[i]= 0;
			c[i]=0;	
			g[i]=0;
    		}
    	}

	void calculEtatVE(double v,double e) {
		V=v;
		E=e;
		P= (γ-1)*E/V - Po ;
		T= (γ-1)*(E-Po*V/γ)/R ;
		S= R/(γ-1)*(log(γ*P+Po)+γ*log(V));
		c2= (γ*P+Po)*V;
		c=sqrt(c2);	
	}
	
	void calculEtatVT(double v,double t) {
		V=v;
		T=t;
		P= (γ-1)*E/V - Po ;
		E= R*T/(γ-1)+Po*V/γ;
		S= R/(γ-1)*(log(γ*P+Po)+γ*log(V));
		c2= (γ*P+Po)*V;
		c=sqrt(c2);	
    	}
    	
	void ecrire() {  
		cout << "	nom = " << nom ;
		cout << "	R = " << R ;
		cout << ",	gam = " << γ ;
		cout << ",	Po = " << Po;
		cout << "\n";
	}
};

// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_SG(Parametres);	}
extern "C" void destroy(EoS* p) {	delete p;	}
