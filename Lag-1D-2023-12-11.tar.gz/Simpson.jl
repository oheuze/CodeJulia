f(x)=x^3-3*x^2+4*x-2
F(x)=x^4/4-x^3+2*x^2-2*x
a=3;b=8;
S=F(b)-F(a)
n=5
h=(b-a)/n
y=[ f(a+(i-1)/2*(b-a)/n) for i in 1:2n+1 ]
function trapezes() 
           sum=0
           for i in 1:2*n
             sum+= h/2*(y[i]+y[i+1])/2
           end
           return sum
end

trapezes()
# 621.5625
S
# 618.75

# using Plots
 xx=[ a+(i-1)/2*h for i in 1:2n+1 ]
# plot(xx,y)

function simpson() 
           sum=h/6*(y[1]+y[2*n+1])
           for j in 1:n-1
             sum+= h/6*2*y[2*j+1]
           end
           for j in 1:n
             sum+= h/6*4*y[2*j]
           end
           return sum
end
simpson()
#618.75

function Simpson(x,y)
           n::Int64 =(length(x)-1)/2
           h=(x[end]-x[1])/n
           sum=h/6*(y[1]+y[2*n+1])
           for j in 1:n-1 sum+= h/6*2*y[2*j+1] end
           for j in 1:n   sum+= h/6*4*y[2*j]   end
           return sum
end
Simpson(xx,y)



