nom="Bi-Sn-MGC"
test=nom
include("../Lag-1D.jl")

