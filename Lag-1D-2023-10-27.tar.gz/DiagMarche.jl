using Plots
larg=2;
bornes=finMilieu[1]-larg+1:debMilieu[2]+larg
global x0= [ x[i] for i in bornes ];
global t0= [ t  for i in bornes ];
scatter(x0,t0,legend=false)
dt = dtCFL(cfl, Dt, dta, x, cmat, ideb, ifin)
xz= [ x[i] for i in bornes ]
tz= [ t  for i in bornes ]
# scatter!(xz,tz)
for i in 1:length(x0)
	plot!([ x0[i] ,xz[i] ],[ t0[i] ,tz[i] ]);
end
plot!([ x0[1] ,x0[end] ],[ t ,t ]);
for k in bornes 
	annotate!((x[k]+x[k+1])/2,t+0.7*dt, text("P="*string(round(pmat[k]*1000.)/1000), :blue, :center,6))
	annotate!((x[k]+x[k+1])/2,t+0.5*dt, text("u="*string(round(umat[k]*1000.)/1000), :blue, :center,6))
	annotate!((x[k]+x[k+1])/2,t+0.3*dt, text("ρ="*string(round(ρmat[k]*1000.)/1000), :blue, :center,6))
	annotate!((x[k]+x[k+1])/2,t+0.1*dt, text("E="*string(round(emat[k]*1000.)/1000), :blue, :center,6))
end	

function Avancer()
	for nit in 1:5
		Iteration()
		dt = dtCFL(cfl, Dt, dta, x, cmat, ideb, ifin)
		xz= [ x[i] for i in bornes ]
		tz= [ t    for i in bornes ]
		# scatter!(xz,tz)
		for i in 1:length(x0)
			plot!([ x0[i] ,xz[i] ],[ t0[i] ,tz[i] ]);
		end
		plot!([ xz[1] ,xz[end] ],[ t ,t ]);
		annotate!(xz[end] , t, text("  "*string(cycle), :black, :left,6))
		for k in bornes 
			annotate!((x[k]+x[k+1])/2,t+0.7*dt, text("P="*string(round(pmat[k]*1000.)/1000), :blue, :center,6))
			annotate!((x[k]+x[k+1])/2,t+0.5*dt, text("u="*string(round(umat[k]*1000.)/1000), :blue, :center,6))
			annotate!((x[k]+x[k+1])/2,t+0.3*dt, text("ρ="*string(round(ρmat[k]*1000.)/1000), :blue, :center,6))
			annotate!((x[k]+x[k+1])/2,t+0.1*dt, text("E="*string(round(emat[k]*1000.)/1000), :blue, :center,6))
			annotate!(x[k],t-0.2*dt, text("P*"*string(round(pstar[k]*1000.)/1000), :red, :center,4))
			annotate!(x[k],t-0.4*dt, text("u*"*string(round(ustar[k]*1000.)/1000), :red, :center,4))
		end	
		global x0=xz;
		global t0=tz;
	end
	plot!()
end

println("Avancer()")
println("plot!()")
Avancer()
plot!()	



