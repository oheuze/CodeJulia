#!/bin/bash

cat <<EOF > modifs.jl
riemann="acoustic";nom=riemann
EOF
julia Hyb3Ph.jl

cat <<EOF > modifs.jl
riemann="three-term_acoustic";nom=riemann
EOF
julia Hyb3Ph.jl

cat <<EOF > modifs.jl
riemann="one-iteration_acoustic";nom=riemann
EOF
julia Hyb3Ph.jl


cat <<EOF > modifs.jl
riemann="two-iteration_acoustic";nom=riemann
EOF
julia Hyb3Ph.jl

julia ../PostProcessingAll.jl






