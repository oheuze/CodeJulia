﻿#include <iostream>
#include <string>
#include <unistd.h>
#include <filesystem>

#include "LecteurEtatThermo.hpp" 
using namespace std; 
namespace fs = std::filesystem;

LecteurEtatThermo etatsThermo;	

int main (int argc, char* args[]) { 
	if (argc<2) 	{cout <<" Syntaxe :  test-Etats <pts.xml>" <<endl;} 
	if (argc<2) 	{cout << " Argument manquant"<<endl; } 
		else 	{ cout << " Argument " << (char*)args[1] << endl; }; 
	string etatsFile    = (string) args[1]; 

	//	CHARGEMENT DES ETATS
	etatsThermo.LireDonnees(etatsFile);
	cout << "Matériau : " << etatsThermo.nom << endl;
	vector <EtatThermo> etats = etatsThermo.etats;
	cout << etats.size() << " points." << endl; 
	for (int i=0; i < etats.size(); i++){
		cout << i+1 ;
		etats[i].ecrire();
	}	 
	cout << Egaux(etats[1],etats[1]) << endl;
	cout << Egaux(etats[1],etats[2]) << endl;
	cout << EtatsToTag(etats);
	cout << "Fin"<< endl; 

	return 0; 
} 

