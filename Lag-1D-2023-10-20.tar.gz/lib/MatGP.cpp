//	OH-5-10-2023
#include "Mat.h"
//
// MatGP
//

MatGP::MatGP(const std::string material):Mat(material)
{
	string pwd = std::filesystem::current_path();
	cout << "Matériau  GP , Fichier de paramètres: "  <<  pwd << "/" << material  << endl ;
	materiau=material;
}

void MatGP::LireDonnees(std::string nomfic){
	LireDonneesStandard(nomfic);
}
	
void MatGP::InitParam(){
	if (details) cout << "	Initialisation Mat GP (" << parametres.size() << " paramètres). " << endl;
	nom	=	toString("Nom");
	R 	=	toDouble("R");
	γ 	=	toDouble("γ");
}
	
//	OH-5-10-2023
void MatGP::ecrire(){
	cout << "MatGP : ecrire" << endl ;
}

void MatGP::calculPc(int ideb, int ifin, double* p, double* c, const double* rho, const double* epsilon)
{
	for (int i = ideb; i <= ifin; i++) {
	        p[i] = (γ - 1.) * rho[i] * epsilon[i];
        	c[i] = sqrt(γ * p[i] / rho[i]);
        }	
}

void MatGP::calculEtats(int ideb, int ifin, double* p, double* c, double* T, double* g, double* S,
	const double* rho, const double* epsilon)
{
	double v[ifin+1];
	for (int i = ideb; i <= ifin; i++) {
        	v[i]=1/rho[i];
        }	
        
        eos->calculVE(ideb,ifin,p,T,c,g,S,v,epsilon);
}

void MatGP::calculEtatsRhoT(int N, double* p, double* c, double* epsilon, 
		const double* rho, const double* T)
{
	for (int i = 0; i < N; i++) {
	        p[i] = rho[i] * R * T[i];
        	c[i] = sqrt(γ * p[i] / rho[i]);
        	epsilon[i] = R * T[i] /  (γ - 1.);
        }	
}

void MatGP::calculEtatVE(double v,double e){
	V = v;
	E = e; 
	P = (γ - 1.)* E/V;
        c = sqrt(γ * P*V);
        T = (v - 1.) *E / R / V;
       	g= (γ + 1.)/2;
       	H=E+P*V;
       	F=E-T*S;
       	G=F+P*V; 
       	Γ=+1;
       	// à compléter
       	S=0; 
        ecrireEtat();       
}	


