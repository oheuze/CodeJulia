#include "HybHandler.hpp"
#include <cmath>
	
void  HybHandler::StartDocument(){
	cout << "Début parser XML Hybride"  << endl;
	map <string,string> vide;
	vide["zone"]="0";
	vide["EOS"]= "None";
	vide["Nom"]= "??";
	ZoneParam zoneP0=ZoneParam(vide);
	zonesP.push_back(zoneP0);
} 

void  HybHandler::StartElement(string Element,map <string,string> Attributs){
	//cout << "Début Element : " << Element  << endl ;
	if (Element==(string)"Materiau"){ 
		nom= recupString( (string) "nom" ,Attributs); 
		string const nomFichier(nom+"-VE.pts");
    		ficPts=ofstream(nomFichier.c_str());
	} ;
	if (Element== (string) "Cadre") { 
		Vmin = recupDouble ( (string) "Vmin", Attributs); 
		Vmax = recupDouble ( (string) "Vmax", Attributs); 
		Emin = recupDouble ( (string) "Emin", Attributs);
		Emax = recupDouble( (string) "Emax" ,Attributs); 
		nV = recupInt((string)"nV",Attributs); 
		nE = recupInt((string)"nE",Attributs); 
		Vscale = recupString((string)"Vscale",Attributs); 
		Escale = recupString( (string) "Escale" ,Attributs); 
		Box caseVide=Box();
		for (int i=0;i<=nV;i++){
			vector <Box> ligneVide;
			for (int j=0;j<=nE;j++){caseVide.i=i;caseVide.j=j;ligneVide.push_back(caseVide);}
			grille.push_back(ligneVide);
		 }
	} ;
	if ( Element== (string) "GeomUnits" ){ 
		Punit = recupDouble((string)"P",Attributs);  if (Punit<=0) Eunit=1;
		Vunit = recupDouble ( (string) "V", Attributs);  if (Vunit<=0) Eunit=1;
		Eunit = recupDouble ( (string) "E", Attributs) ; if (Eunit<=0) Eunit=1;
	} ;
	if (Element==(string) "ZoneParam"){ 
		ZoneParam zoneP=ZoneParam(Attributs);
		zoneP.ecrire();
		zonesP.push_back(zoneP);
	} ;
	if (Element==(string)"Mono"){ 
		nZ = recupInt( (string) "zone" ,Attributs);
		std::string listBoxes = recupString((string)"cases",Attributs);
		//cout << " Mono -->  zone= " << nZ << " , " << listBoxes << endl ;
		listBoxes=listBoxes.substr(listBoxes.find("{")+1,listBoxes.size()) ;
		while ( listBoxes.find("{") < listBoxes.size() ) { 
			int deb= listBoxes.find("{");
			int fin= listBoxes.find("}");
			string caseStr = listBoxes.substr( deb , fin-deb+1 ); 
			listBoxes = listBoxes.substr( fin+1 ); 
			Box caseIJ=Box(caseStr,nZ);
			//caseIJ.ecrire();
			grille[caseIJ.i][caseIJ.j]=caseIJ;
		}  ; 
	} ;
	if (Element==(string)"Mixte"){ 
		biZone = recupString ( (string)"zones", Attributs);  
		std::string beg="{",mid=",",end="}"; 
		std::string nz1Str= biZone.substr(biZone.find(beg)+1 ,biZone.find(mid)-biZone.find(beg) ) ; 
		std::string nz2Str= biZone.substr(biZone.find(mid)+1 ,biZone.find(end)-biZone.find(mid) ) ;
		nz1=stoi(nz1Str); 
		nz2=stoi(nz2Str); 
	} ;
	if (Element==(string)"Case"){ 
		string box = recupString((string)"case",Attributs); 
		string strBip = recupString((string)"segment",Attributs); 
		BiPoint bip=BiPoint(strBip);
		Box caseIJ=Box(box,nz1,nz2,bip);
		ficPts << "# Case Mixte " << box << endl;
		ficPts << bip.pt1.x << "  " << bip.pt1.y <<endl; 
		ficPts << bip.pt2.x << "  " << bip.pt2.y << endl <<endl;
		//caseIJ.ecrire(); 
		grille[caseIJ.i][caseIJ.j]=caseIJ;
	} ;
	if (Element==(string)"Multi"){
		zonesG.clear();
		strBox = recupString((string)"Case",Attributs);
		//cout << " Multi -->   box= " << strBox << endl ;
		ficPts << "# Case Multi " << strBox << endl;
	 } ;
	if (Element==(string)"ZoneGeom"){
		int nz = recupInt ( (string)"zone", Attributs); 
		std::string segsStr = recupString ( (string)"segments", Attributs);
		ZoneGeom zoneG=ZoneGeom(nz,segsStr);
		//zoneG.ecrire();
		zonesG.push_back(zoneG);
		Box caseIJ=Box(strBox,zonesG); 
		//cout << "zone " << nz << " , " << zoneG.bips.size() << " segments." << endl; 
		for(std::size_t i=0; i<  zoneG.bips.size();i++){ 
			ficPts << zoneG.bips[i].pt1.x << "  " << zoneG.bips[i].pt1.y <<endl; 
			ficPts << zoneG.bips[i].pt2.x << "  " << zoneG.bips[i].pt2.y << endl <<endl;
		}
		//caseIJ.ecrire(); 
		grille[caseIJ.i][caseIJ.j]=caseIJ;
	}			
}

string  HybHandler::trim(string str){
	while( 	str.find(" ") ==0 || str.find("\n")==0  || 
		str.find("\t")==0  ) str=str.substr(1,str.size());
	string last=str.substr(str.size(),str.size());
	while( last.compare(" ")==0 || last.compare("\n")==0  || last.compare("\t")==0  ) 		
			str=str.substr(0,str.size()-1);
	return str;
}

string HybHandler::recupString(string motClef,map <string,string> Attributs) { 
	string valStr; 
	try {
		valStr = Attributs.at(motClef);
	}
	catch(const std::out_of_range& oor) {
	    cout << motClef << "non renseigné. " << endl;
	}
	string valeur = valStr.substr(0,valStr.size());
	return valeur; 
} 

int HybHandler::recupInt(string motClef,map <string,string> Attributs) { 
	string valStr; 
	try {
		valStr = Attributs.at(motClef);
	}
	catch(const std::out_of_range& oor) {
	    cout << motClef << "non renseigné. " << endl;
	}
	int valeur = (int) stoi( valStr.substr(0,valStr.size()) );  
	return valeur; 
} 

double HybHandler::recupDouble(string motClef,map <string,string> Attributs) { 
	string valStr; 
	try {
		valStr = Attributs.at(motClef);
	}
	catch(const std::out_of_range& oor) {
	    cout << motClef << "non renseigné. " << endl;
	}
	double valeur = stod(valStr.substr(0,valStr.size())); 
	return valeur; 
} 

void  HybHandler::EndElement(string Element){
	//cout << "Fin Element   : " << Element  << endl;
}

void HybHandler::Characters(string CaracStr){
	argument = trim(CaracStr);	
	//if ( argument.size()>0 ) cout << "#	Argument : " << argument  << endl;
}

void  HybHandler::EndDocument(){
	std::string noms[zonesP.size()];
	map<string,int> mapPhases;
	for(std::size_t i=1; i< 0;i++){
	//for(std::size_t i=1; i<  zonesP.size();i++){ 
		map<string,string> parami=zonesP[i].parametres;
		noms[i]=parami["Nom"];
		mapPhases[noms[i]]=(int) i;
		size_t posVirg = noms[i].find(",");
		if ( posVirg < noms[i].size() ){	// detection de mélange
			cout << "	Zone " << i << "   : " << noms[i] << endl;
			string nomPhA=noms[i].substr(1,posVirg-1);
			string nomPhB=noms[i].substr(posVirg+2,noms[i].size()-posVirg-3);
			cout << "Mélange des phases (" << nomPhA << ") et (" << nomPhB  << ")." << endl;
			map<string,string> paramMel;
			paramMel["PhaseA"]=nomPhA;
			paramMel["PhaseB"]=nomPhB;
			paramMel["Nom"]=noms[i];
			paramMel["EOS"]="Mel";
			zonesP[i].parametres=paramMel;
			int phA = mapPhases[nomPhA];
			int phB = mapPhases[nomPhB];
			cout << "Phases " << phA << " et " << phB  << "." << endl;
		}
	}
	ficPts.close();	
	cout << "Fin parser XML Hybride"  << endl;
}

