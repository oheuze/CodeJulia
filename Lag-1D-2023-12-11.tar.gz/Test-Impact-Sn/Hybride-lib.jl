# OH 6/12/2023
using Plots,DataFrames,CSV

include("../MateriauJ.jl")
Sn3Ph = Materiau.Hybride("Sn-thèse-24x35.xml")
cd("../Matériaux")
Materiau.LireDonnees(Sn3Ph,"Sn-thèse-24x35.xml")
# Materiau.InitParam(Sn3Ph)

function DiagVE()
	#	Diagramme (V,E)
	# CSV.read("Sn-VE.pts",DataFrame;comment="#")
	df = DataFrame(CSV.File("Sn-VE.pts";comment="#"))
	rename!(df,[:V,:Z,:E])
	Vi=df[:,1];
	Ei=df[:,3];
	plot(title="Diagramme V-E",xlabel="V (m3/kg)",ylabel="E (J/kg)")
	for i in 1:Int((nrow(df)-1)/2)
		Vz = [ Vi[2*i]*1e-6 , Vi[2i+1]*1e-6 ]
		Ez = [ Ei[2*i] , Ei[2i+1] ]
		plot!(Vz,Ez,label="",lc=:blue)
	end
	plot!()
	# scatter!(Vi,Ei)
end	

function DiagρE()
	#	Diagramme (ρ,E)
	# CSV.read("Sn-VE.pts",DataFrame;comment="#")
	df = DataFrame(CSV.File("Sn-VE.pts";comment="#"))
	rename!(df,[:V,:Z,:E])
	Vi=df[:,1];
	Ei=df[:,3];
	plot(title="Diagramme ρ-E",xlabel="ρ (kg/m3)",ylabel="E (J/kg)")
	for i in 1:Int((nrow(df)-1)/2)
               ρz = [ 1.e6/Vi[2*i] , 1.e6/Vi[2i+1] ]
               Ez = [ Ei[2*i] , Ei[2i+1] ]
               plot!(ρz,Ez,legend=false,lc=:blue)
	end
	plot!()
end	

