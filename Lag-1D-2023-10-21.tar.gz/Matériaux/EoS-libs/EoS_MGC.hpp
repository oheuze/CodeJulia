﻿#ifndef _EoS_MGC_H 
#define _EoS_MGC_H 

#include "EoS.hpp"
#include <cmath>
#include <iostream>

#	OH	21-10/2023

class EoS_MGC : public EoS {	

protected :
	
public:	
	// paramètres EoS_MGC	
	double Ko,No,Γo,Cvr,Theta0,Po,DeltaV,dPdT,Tmin,Tmax,Pmin,Pmax,Rho0,Sr,ur;
		
	// grandeurs EoS_MGC	
	double Es,Ps,PsP,eps,epsP,epsS,psi,psiP,theta,gamma;
	
	void Potentiel()

	//Potentiel Inversible  -> eps, epsP
	void PotInv(double V)

	//  Température de Debye   Gamma*Rho=cste=Gamma0*Rho0
	void ThetaGamma(double V)

	// fonction Psi  : psi=log <=>  Cv= cste	
	void Psi(double u)
};

// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_MGC(Parametres);	}
extern "C" void destroy(EoS* p) {	delete p;	}

#endif
