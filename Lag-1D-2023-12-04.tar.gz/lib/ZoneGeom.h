#ifndef _ZoneGeom_ 
#define _ZoneGeom_

#include <string> 
#include <iostream> 
#include <vector>
#include "BiPoint.h" 

using namespace std; 

class ZoneGeom { 

protected: 

public: 

	int nz;
	vector <BiPoint> bips;
	
	ZoneGeom(); 
	ZoneGeom(int Nz,std::string strBips); 
	~ZoneGeom (); 
	
	vector <BiPoint> strToBips(std::string strBips);

	void ecrire(); 
} ; 

#endif
