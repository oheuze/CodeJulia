#include "LecteurHybride.hpp" 
	
LecteurHybride::LecteurHybride(){ 
	//cout <<" Appel de LecteurHybride "<< endl;
} 
	
LecteurHybride::~LecteurHybride(){} 

void LecteurHybride::ecrire(){ 
	cout << nom  << endl;
} 

int LecteurHybride::LireDonnees(std::string ficXML) { 
	cout << "Fichier Hybride : " << ficXML << endl; 
	if (details) cout << "Détails du lecteur activés. "<< endl;
	ParserSAX* parser =new ParserSAX();
	parser->detailed=false;
	if (details) parser->detailed=true;
	HybHandler* handler = new HybHandler();
	parser->InitHandler(handler);
	parser->parse(ficXML);
	
	nom	= handler->nom;
	nV	= handler->nV;
	nE	= handler->nE;
	Vmin	= handler->Vmin;
	Vmax	= handler->Vmax;
	Emin	= handler->Emin;
	Emax	= handler->Emax;
	Punit	= handler->Punit;
	Vunit	= handler->Vunit;
	Eunit	= handler->Eunit;
	Vscale	= handler->Vscale;
	Escale	= handler->Escale;
	zonesP  = handler->zonesP;
	grille	= handler->grille;
	eoz	= handler->eoz;
	//cout << handler->pointsparam.size() << " points." << endl; 
//		for (int i=0; i< (int) handler->pointsparam.size(); i++) pointsparam.push_back(handler->pointsparam[i]);
		//cout << "Fin de try"<< endl; 
	return 0; 
} 
