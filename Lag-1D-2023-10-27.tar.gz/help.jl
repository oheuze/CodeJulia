# OH 26/10/2023
println(" taper :")
println(" 	helpMat")
println(" 	helpCas")
helpMat = [
"o Chargement des EE : ",
"       gp  = Materiau.GP(&Gaz Parfait&) ",
"       mgc = Materiau.MGC(&Mie-Grüneisen Complète&) ",
"       bz  = Materiau.Bizarrium(&Bz&) ",
"       hyb = Materiau.Hybride(&Hybride&) ",
"o Fonctions  : ",
"       LireDonnees :     Materiau.LireDonnees(bz,&Bz.mat&) ",
"       InitParam   :     Materiau.InitParam(mgc) ",
"       setParam    :     Materiau.setParam(gp,&Gamma&,&1.4&) ",
"       getVal      :     Ko=Materiau.getVal(mgc,&Ko&) ",
"       ecrire      :     Materiau.ecrire(mgc) ",
"       calculEtats :     Materiau.calculEtats(gp,ideb,ifin,p,c,T,ρ,ε)",     
"       calculEtatsRhoT : Materiau.calculEtatsRhoT(gp,ideb,ifin,p,c,ε,ρ,T)", "       calculEtatVE:     Materiau.calculEtatVE(gp,V,E) ",
"       detailler   :     Materiau.detailler(mgc) "
];

antislash="\"";
helpCas = [
"o Lancement d'un cas (associé au fichier zzz.xml",
"       nom="*antislash*"zzz"*antislash*";include(\"../Lag-1D.jl\")",
"o Initialisation d'un cas :",
"       nom=\"zzz\";include(\"../Init-Lag.jl\")",
"       puis enchainer avec","       Run()",
"       ou itération par itération",
"       Iteration();focus()",
"o Fonctions  : ",
"       ..."
];

""
