#ifndef _EOS_ 
#define _EOS_ 

#include <iostream> 
#include <map>
#include <math.h>
using namespace std;

class EoS {

protected:
	double R, gammaGP;		// constantes physiques
	double dPdVe,dPdEv,Gamma,Cv,Gruneisen; 
	double Vo,Eo,So,To;

public:
	string nom,EOS;
	int zone;
	map <string,string> parametres;
	double V,E,P, T, S, G, c2, Γρ, c, g;	// variables thermodynamiques
	double Pv,Pe,Tv,Te;	
	EoS* eosA;		//   pour les mélanges
	EoS* eosB;		//   pour les mélanges 
	
	EoS(){ }
	EoS(map <string,string> Parametres){ parametres=Parametres;	}
	
	EoS(const EoS &Source){
		cout <<"Constructeur de copie de EoS"<< endl;
		parametres= Source.parametres;
		cout <<"Fin du constructeur de copie de EoS"<< endl;
	}

	virtual ~EoS() { EOS="GP"; }
	virtual	void calculEtatVE(double v,double e){  cout << "calculVE EoS " << endl;	}
	virtual void calculVE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S, 
			const double* v, const double* e) {  cout << "calculEtatVE EoS " << endl;	}
	virtual void calculEtatVT(double v,double t) {  cout << "calculEtatVT EoS " << endl;	}
	virtual void ecrire() {	cout << "ecrire EoS " << endl;   }
	
	void ecrireEtat()
	{
		cout << "	(" << zone <<")	";
		cout << "V = " << V <<" , ";
		cout << "E = " << E <<" , ";
		cout << " " << EOS << "(" << nom << ") ->	";
		cout << "P = " << P <<" , ";
		cout << "T = " << T <<" , ";
		cout << "S = " << S <<" , ";
		cout << "c = " << c;
		cout << endl;
	}
	
	int toInt(string name){
		string valStr; 
		try {
			valStr = parametres.at(name);
		}
		catch(const std::out_of_range& oor) {
		    cout << name << "	non renseigné. " << endl;
		}
		int valeur = (int) stoi( valStr.substr(0,valStr.size()) );  
		return valeur; 
	};
	
	double toDouble(string name){		
		string valStr; 
		try {
			valStr = parametres.at(name);
		}
		catch(const std::out_of_range& oor) {
		    cout << name << "	non renseigné. " << endl;
		}
		double valeur = stod(valStr.substr(0,valStr.size())); 
		return valeur; 
	};	
		
	string toString(string name){		
		string valStr; 
		try {
			valStr = parametres.at(name);
		}
		catch(const std::out_of_range& oor) {
		    cout << name << "	non renseigné. " << endl;
		}
		string valeur = valStr.substr(0,valStr.size());
		return valeur; 
	};
};

// the types of the class factories

typedef EoS* create_t(map <string,string>);
typedef void destroy_t(EoS*);

#endif
