nom="Hyb3Ph"
test=nom
include("../Lag-1D.jl")

