
# OH 5/05/2023

import EzXML
using EzXML ,Dates

struct Cas
	test  		:: String
	nom  		:: String 
	scheme  	:: String 
	ieee_bits  	:: Int
	maxcycle  	:: Int
	riemann  	:: String 
	iterations  	:: Int 
	nghost 		:: Int 
	silent 		:: Int 
	maxtime 	:: Float64 
	cfl 		:: Float64  
	Dt  		:: Float64  
	xmin   		:: Float64 
	bcDeb 		:: String
	bcFin 		:: String
	milieux 	:: Vector{Milieu}	
end	

struct EOS
	Modele 		:: String
	Sigle  		:: String 
	Parametres  	:: String 	
end	

function LireXML(FicXML)::Cas
	monxml=EzXML.readxml(FicXML)
	racine=monxml.root
	#println(" racine = ",racine)
	global tags=EzXML.elements(racine)
#	for i=1:length(tags)
#              println("tag ",i,"	#	",tags[i]);
#              println("		argument = ",tags[i].content)
#              for j=1:length(EzXML.attributes(tags[i]))
#                      println("\t attribut ",j,"\t",EzXML.attributes(tags[i])[j])
#              end
#	end 
	for i=1:length(tags) 
		tagi =tags[i];
		if  EzXML.nodename( tagi)=="DonneesGlobales" 
			if haskey( tagi,"Nom")	global nom= tagi["Nom"];end
			if haskey( tagi,"Ieee_bits") 	global ieee_bits=parse(Int, tagi["Ieee_bits"]);end
		end	
		if  EzXML.nodename( tagi)=="Test" 	global test= tagi.content end	
		if  EzXML.nodename( tagi)=="Scheme" 	global scheme= tagi.content end	
		if  EzXML.nodename( tagi)=="Riemann"
			if haskey( tagi,"Solveur")	global riemann= tagi["Solveur"];end
			if haskey( tagi,"Iterations") global iterations=parse(Int, tagi["Iterations"]);end 
		 end	
		if  EzXML.nodename( tagi)=="ConditionsLimites"
			if haskey( tagi,"Gauche")	global bcDeb= tagi["Gauche"];end
			if haskey( tagi,"Droite") 	global bcFin= tagi["Droite"];end 
	       		if haskey( tagi,"Xmin")    	global xmin=parse(Float64, tagi["Xmin"]);end
		 end	
		if  EzXML.nodename( tagi)=="ConditionsInitiales"
			if haskey( tagi,"Dt")		global Dt=parse(Float64, tagi["Dt"]);end
			if haskey( tagi,"Cfl") 	global cfl=parse(Float64, tagi["Cfl"]);end 
	       		if haskey( tagi,"Nghost")    	global nghost=parse(Int, tagi["Nghost"]);end
		 end	
		if  EzXML.nodename( tagi)=="ConditionsFinales"
			if haskey( tagi,"Time")	global maxtime=parse(Float64, tagi["Time"]);end
			if haskey( tagi,"Cycles") 	global maxcycle=parse(Int, tagi["Cycles"]);end 
		 end	
		if  EzXML.nodename( tagi)=="Sorties"
			global sorties=EzXML.elements( tagi);
			for k=1:length(sorties)
	       			if haskey(sorties[k],"Silent") global silent=parse(Int,sorties[k]["Silent"]); end
	       		end
		end
		if  EzXML.nodename( tagi)=="Milieux"	
	       		local milieux=EzXML.elements( tagi);
	       		global mils=Vector{Milieu}(undef, length(milieux))
	       		# global mils = Milieu[]
	       		for k=1:length(milieux)
	       			#println("milieu ",k,"  :  ",milieux[k])
	       			nomMil=milieux[k]["Nom"];
	       			ρMil=parse(Float64,milieux[k]["rho"]);
	       			uMil=parse(Float64,milieux[k]["u"]);
	       			eMil=parse(Float64,milieux[k]["e"]);
	       			xmaxMil=parse(Float64,milieux[k]["xmax"]);
	       			ncellsMil=parse(Int,milieux[k]["ncells"]);
	       			EOSmodelMil=milieux[k]["EOSmodel"];
	       			EOSsigleMil=milieux[k]["EOSparam"]
	       			mil=Milieu(nomMil,ρMil,uMil,eMil,xmaxMil,ncellsMil,EOSmodelMil,EOSsigleMil);
	       			mils[k]=mil;
	       		end
	       	end
		if  EzXML.nodename( tagi)=="EOS"	
	       		local tagseos=EzXML.elements( tagi);
	       		global tabEoS=Vector{EOS}(undef, length(tagseos))
	       		for k=1:length(tagseos)
	       			eosk   = tagseos[k]
	       			println(eosk)
	       			modele = eosk["Modele"];
	       			sigle  = eosk["Sigle"];
	       			parametres = eosk["Parametres"];
	       			tabEoS[k]=EOS(modele,sigle,parametres);
	       		end
	       	end
		if  EzXML.nodename( tagi)=="Preprocessing"
				global ficPre=tagi["Fichier"]
		    		println("Preprocessing  :  ", ficPre)
		end   
		if  EzXML.nodename( tagi)=="Postprocessing"
				global ficPost=tagi["Fichier"]
		    		println("Postprocessing  :  ",ficPost)
		end   		
	end
	global cas=Cas(test,nom,scheme,ieee_bits,maxcycle,riemann,iterations,
		nghost,silent,maxtime,cfl,Dt,xmin,bcDeb,bcFin,mils)
	return cas
end

function EcriXML(cas::Cas,FicXML::String)
	println("Fichier : ",FicXML)
	f = open(FicXML, "w")
	french_months = ["janvier", "février", "mars", "avril", "mai", "juin",
	        "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
	french_monts_abbrev = ["janv","févr","mars","avril","mai","juin",
	        "juil","août","sept","oct","nov","déc"];
	french_days = ["Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi","Dimanche"];
	Dates.LOCALES["french"] = Dates.DateLocale(french_months, french_monts_abbrev, french_days, [""]);
	maintenant=Dates.dayname(now();locale="french")*Dates.format(now(), " dd-mm-yyyy à  HH:MM:SS")
	print(f,"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
	print(f,"<Cas1D DateHeure =\"$maintenant\" >\n") 
	print(f,"	<!--  \n\t\t	Commentaires  \n	-->   \n")
	print(f,"	<DonneesGlobales Nom=\"",cas.nom,"\" Ieee_bits = \"",cas.ieee_bits,"\" />\n")   
	print(f,"	<Test>",cas.test,"</Test>\n")
	print(f,"	<Scheme>",cas.scheme,"</Scheme>\n")
	print(f,"	<Riemann Solveur=\"",cas.riemann,"\" Iterations =\"",cas.iterations,"\" />\n")
	print(f,"	<ConditionsLimites Gauche=\"",cas.bcDeb,"\" Droite=\"",cas.bcFin,
		"\" Xmin=\"",cas.xmin,"\" />\n")
	print(f,"	<ConditionsInitiales Dt=\"",cas.Dt,"\" Cfl=\"",cas.cfl,
		"\" Nghost=\"",cas.nghost,"\" />\n")
	print(f,"	<ConditionsFinales Time=\"",cas.maxtime,"\" Cycles=\"",cas.maxcycle,"\" />\n")
	print(f,"	<Sorties>\n")
	print(f,"			<Display Silent   = \"",cas.silent,"\"></Display>\n")
	print(f,"			<Graphique></Graphique>\n")
	print(f,"			<Fichier>	</Fichier>\n")
	print(f,"	</Sorties>\n")
	print(f,"	<Milieux>\n")
	for i=1:length(cas.milieux)
		mili=cas.milieux[i]
		print(f,"		<Milieu Nom=\"",mili.Nom,
		"\"\n\t\t	rho=\"",mili.ρ,"\"	u=\"",mili.u,"\"	e=\"",mili.e,
		"\"\n\t\t	xmax=\"",mili.xmax,"\"	ncells=\"",mili.ncells,
		"\"\n\t\t	EOSmodel=\"",mili.EOSmodel,"\"	EOSparam=\"",mili.EOSsigle,"\"	EOSparam=\"",mili.EOSparam,
		"\"\n		/>\n")
	end	
	print(f,"	</Milieux>\n")
	print(f,"	<EOS>\n")
	for i=1:length(cas.milieux)
		mili=cas.milieux[i]
		print(f,"		<Materiau \n\t\t	Modele=\"",mili.EOSmodel,"\"	Sigle=\"",mili.EOSsigle,"\"\n","\"	Parametres=\"",mili.EOSparam,"\"\n")
	end	
	print(f,"	</EOS>\n")
	print(f,"</Cas1D>\n")  
	close(f)
	println("file XML  "*FicXML*" closed")    
end

