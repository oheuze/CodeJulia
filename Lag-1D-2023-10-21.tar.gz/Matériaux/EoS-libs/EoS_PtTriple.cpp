#include "EoS.hpp"
#include <cmath>
#include <iostream>

//	OH	21-10-2023

class EoS_PtTriple : public EoS {	

protected :
	
public:
	double Pt,Tt,Sr;
	
	EoS_PtTriple(map <string,string> Parametres){		
		parametres= Parametres;  
		cout << "	Initialisation EoS_PtTriple  ("<< parametres.size() << " paramètres ) : ";
		zone = toInt("zone");
		EOS  = toString("EOS");
		nom  = toString("Nom");
		Pt = toDouble("Pt");
		Tt = toDouble("Tt");	
		//	Sr = toDouble("Sr");
		ecrire();
	}

	void calculVE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S, 
		 const double* v, const double* ) {
		for (int i = ideb; i <= ifin; i++) {
			p[i]= Pt;
			T[i]= Tt;
			S[i]= 0;
			c[i]= 0;	
			g[i]= 0;
    		}
    	}

	void calculρE(int ideb, int ifin, double* p,double* T,double* c, double* g, double* S, 
		 const double* ρ, const double* ) {
		for (int i = ideb; i <= ifin; i++) {
			p[i]= Pt;
			T[i]= Tt;
			S[i]= 0;
			c[i]= 0;	
			g[i]= 0;
    		}
    	}

	void calculEtatVE(double v,double e){
		V=v;
		E=e;
		P=Pt;
		T=Tt;
		c2=0;
		c=sqrt(c2);
		S=0;
	}

	void calculEtatVT(double v,double t){
		V=v;
		E=1000000;	//	indéterminé pour un point triple
		P=Pt;
		T=Tt;
		c2=0;
		c=sqrt(c2);
		S=0;
	}

	void ecrire(){
		cout << "	" << EOS <<" : " << "	Pt= " << Pt << " , Tt= " << Tt << endl;
	}

};

// the class factories
extern "C" EoS* create(map <string,string> Parametres) {	    return new EoS_PtTriple(Parametres);	}
extern "C" void destroy(EoS* p) {	delete p;	}
