pole=MieGru.Etat("pole",7287.0,0.0,Snβ)

MieGru.Hugoniot(8515.216238379,pole,Snβ)

etatChoc=MieGru.Etat("EtatChoc",8515.216238379,125000.00000001672,Snβ)
