module MieGru
# OH 2/12/2022
#  ;
# Crtl C puis ]
#  ( generate MieGru pour créer le module
# (@v1.4) pkg> activate ./MieGru
#(MieGru) pkg> dev ./ZZZ pour ajouter la dépendance du module ZZZ
#(MieGru) pkg> build
# Crtl C 
# import MieGru
# αβγδεζηθικλμνξοπρςστυχψφωϕΓΔΘΛΞΠΣΦΨΩ

export Etat,AffEtat
export Es,Ps,Psρ,Γρ,θ,Γ,Γρp
export Pρe,Sρe,Tρe
export Pv,Pe,Tv,Te
export Ph,Eh,Th,Hugoniot
export SolveMelNewtonIter,SolveMelNewton

struct ParametresMieGru
	Nom :: String
	ρ0 :: Float64
	Ko :: Float64
	No :: Float64
	Γo :: Float64
	Γ1 :: Float64
	θo :: Float64
	Cv :: Float64
	ur :: Float64
	Eo :: Float64
	So :: Float64
	Commentaire :: String
end

mutable struct EtatThermo
	Nom :: String
	Phase :: String
	ρ :: Float64
	E :: Float64
	P :: Float64
	T :: Float64
	S :: Float64
	G :: Float64
	c:: Float64
end

function Init(parametres::ParametresMieGru)
	println("Iniialisation de ",parametres.Nom)
	Nom = parametres.Nom
	ρ0 = parametres.ρ0
	Ko = parametres.Ko
	No = parametres.No
	Γo = parametres.Γo
	Γ1 = parametres.Γ1
	θo = parametres.θo
	Cv = parametres.Cv
	ur = parametres.ur
	Eo = parametres.Eo
	So = parametres.So
	Commentaire = parametres.Commentaire
	return parametres
end


function Etat(Nom::String,ρ,E,Mat::ParametresMieGru)
       etat=EtatThermo(Nom,Mat.Nom,ρ,E,0,0,0,0,0);
       etat.P=Pρe(ρ,E,Mat)
       etat.T=Tρe(ρ,E,Mat)
       etat.S=Sρe(ρ,E,Mat)
       etat.G=E+etat.P/ρ-etat.T*etat.S
       c2= Psρ(ρ,Mat) + (Γρ(ρ,Mat)/ρ^2+Γρp(ρ,Mat)/Γρ(ρ,Mat))*(etat.P - Ps(ρ,Mat))
       etat.c= sqrt(c2)
       return etat;
end
	
function AffEtat(etat)
	print(etat.Nom,"  (",etat.Phase.Nom,") : ")
	print("	ρ = ",etat.ρ)
	println("	E = ",etat.E)
	print("	P = ",etat.P)
	print("	T = ",etat.T)
	print("	S = ",etat.S)
	print("	G = ",etat.G)
	println("	c^2 = ",etat.c2)
end
	
function AfficheParams(param::ParametresMieGru)
	println("Matériau = ",param.Nom)
	print("	ρ0 = ",param.ρ0)
	print("	Ko = ",param.Ko)
	println("	No = ",param.No)
	print("	Γo = ",param.Γo)
	print("	Γ1 = ",param.Γ1)
	println("	θo = ",param.θo)
	print("	Cv = ",param.Cv)
	println("	ur = ",param.ur)
	print("	Eo = ",param.Eo)
	println("	So = ",param.So)
	println("	Commentaire = ",param.Commentaire)
end

function TagToParams(tag)
	Nom=tag["Nom"]       
	ρ0=parse(Float64,tag["ρ0"])
	Ko=parse(Float64,tag["Ko"])
	No=parse(Float64,tag["No"])
	Γo=parse(Float64,tag["Γo"])
	Γ1=0.0
	θo=parse(Float64,tag["θo"])
	Cv=parse(Float64,tag["Cvr"])
	ur=parse(Float64,tag["ur"])
	Eo=parse(Float64,tag["Eo"])
	So=parse(Float64,tag["Sr"])
	Commentaire=""
	return ParametresMieGru(Nom,ρ0,Ko,No,Γo,Γ1,θo,Cv,ur,Eo,So,Commentaire)
end

#################
# Mie-Grüneisen EOS
#################

function EOS!(ρ, e, P, T, c, G, ideb, ifin, Mat::ParametresMieGru)
#	input : ρ, e, ideb, ifin, Mat(parametres)
#	output : P, T, c, G (dérivée fondamentale)
	ρ0 = Mat.ρ0;	Ko = Mat.Ko;	No = Mat.No;	Γo = Mat.Γo;	Γ1 = Mat.Γ1;
	θo = Mat.θo;	ur = Mat.ur;	Cv = Mat.Cv;	Eo = Mat.Eo;	So = Mat.So;
	
	Threads.@threads for i in ideb:ifin

		x = 1 - ρ0/ρ[i]
		ex = exp((No+1)*x)
		Es = Ko/ρ0*((ex-1)/(No+1)-x)/(No+1)+Eo
		Ps = Ko*(ex-1)/(No+1)
		Γρ = Γo*ρ0 + Γ1*ρ[i]
		Psρ = Ko*ρ0/ρ[i]/ρ[i]*ex
		Psρρ = Ko/ρ[i]/ρ[i]*(1-x)*(1+x-No*(1-x))*ex			 
		Γρp = Γ1		
		θ = θo*exp(Γo*x)*(ρ[i]/ρ0)^Γ1
		u = ur+(e[i]-Es)/Cv/θ
#		S = So+Cv*log(u)
	
		P[i] = Ps + Γρ*(e[i] - Es)  
		T[i] = θ*u                                    
		c[i] = sqrt( Psρ + (Γρ/ρ[i]^2+Γρp/Γρ)*(P[i] - Ps))  
		G[i] = 1.2        #  à calculer       
	end
end

function Es(ρ,Mat)
		#  paramètres  ρ0,Ko,No,Eo
		x = 1 - Mat.ρ0/ρ
		Mat.Ko/Mat.ρ0*((exp((Mat.No+1)*x)-1)/(Mat.No+1)-x)/(Mat.No+1)+Mat.Eo
end

function Ps(ρ,Mat)
		#  paramètres  ρ0,Ko,No
		x = 1 - Mat.ρ0/ρ
		Mat.Ko*(exp((Mat.No+1)*x)-1)/(Mat.No+1)
end

function Psρ(ρ,Mat)
		#  paramètres  ρ0,Ko,No
		x = 1 - Mat.ρ0/ρ
		Mat.Ko*Mat.ρ0*exp((Mat.No+1)*x)/ρ/ρ
end

function Γρ(ρ,Mat)
		#  paramètres  Γo, ρ0 , Γ1
		Mat.Γo*Mat.ρ0 + Mat.Γ1*ρ
end

function θ(ρ,Mat)
		#  paramètres  ρ0,θo,Γo,Γ1
		x = 1 - Mat.ρ0 / ρ
		Mat.θo*exp(Mat.Γo*x)*(ρ/Mat.ρ0)^(Mat.Γ1)
end	

function Γ(ρ,Mat)
		#  paramètres  Γo, ρ0 , Γ1
		Mat.Γo*Mat.ρ0/ρ + Mat.Γ1
end

function Γρp(ρ,Mat)
		#  paramètres  Γo, ρ0 , Γ1
		Mat.Γ1
end

function Pρe(ρ,E,Mat)
	Ps(ρ,Mat)+Γρ(ρ,Mat)*(E-Es(ρ,Mat))
end

function Sρe(ρ,E,Mat)
	u=max((E-Es(ρ,Mat))/Mat.Cv/θ(ρ,Mat)+Mat.ur,0.0001)
	return Mat.So+Mat.Cv*log(u)
end	

function Tρe(ρ,E,Mat)
	u=Mat.ur+(E-Es(ρ,Mat))/Mat.Cv/θ(ρ,Mat)
	return θ(ρ,Mat)*u
end	

function Pv(ρ,E,Mat)
	-ρ^2*Psρ(ρ,Mat)-ρ^2*Γρp(ρ,Mat)*(E-Es(ρ,Mat))+Γρ(ρ,Mat)*Ps(ρ,Mat)
end

function Pe(ρ,E,Mat)
	Γρ(ρ,Mat)
end

function Tv(ρ,E,Mat)
	-Mat.ur*Γρ(ρ,Mat)*θ(ρ,Mat)+Ps(ρ,Mat)/Mat.Cv
end

function Te(ρ,E,Mat)
	1/Mat.Cv
end
#  Hugoniot
function Ph(ρ,Pole,Mat)
	Vo=1/Pole.ρ
	Po=Pole.P
	Eo=Pole.E
	V=1/ρ
	Γxρ=Γρ(ρ,Mat)
	num= Ps(ρ,Mat)+Γxρ*(Eo-Es(ρ,Mat)+Po*(Vo-V)/2)
	den=1-Γxρ*(Vo-V)/2
	return num/den
end

function Eh(ρ,Pole,Mat)
	Vo=1/Pole.ρ
	Po=Pole.P
	Eo=Pole.E
	V=1/ρ
	Γxρ=Γρ(ρ,Mat)
	num= Eo + (Ps(ρ,Mat)+Po-Γxρ*Es(ρ,Mat))*(Vo-V)/2
	den= 1-Γxρ*(Vo-V)/2
	return num/den
end

function Th(ρ,Pole,Mat)
	Tρe(ρ,Eh(ρ,Pole,Mat),Mat)
end

function Hugoniot(ρ,Pole,Phase)
           gr=Γρ(ρ,Phase)
           P1=Pρe(ρ,0,Phase)
           Ph=(P1+gr*(Pole.E+Pole.P*(1/Pole.ρ-1/ρ)))/(1. - gr*(1/Pole.ρ-1/ρ)/2)
           Eh=Pole.E+(Pole.P+Ph)*(1/Pole.ρ-1/ρ)/2
           u=sqrt((Ph-Pole.P)*(1/Pole.ρ-1/ρ))
           D=1/Pole.ρ*sqrt((Ph-Pole.P)/(1/Pole.ρ-1/ρ))
           return Ph,Eh,u,D
end

function SolveMelNewtonIter(V,E,phA,phB,Va,Ea,Vb,Eb,x)
               Pa=Pρe(1/Va,Ea,phA)
               Pb=Pρe(1/Vb,Eb,phB)
               Ta=Tρe(1/Va,Ea,phA)
               Tb=Tρe(1/Vb,Eb,phB)
               Sa=Sρe(1/Va,Ea,phA)
               Sb=Sρe(1/Vb,Eb,phB)
               Ga=Ea+Pa*Va-Ta*Sa
               Gb=Eb+Pb*Vb-Tb*Sb
               DV=Vb-Va
               DS=Sb-Sa
               DE=Eb-Ea
               dG=Gb-Ga
               dT=Tb-Ta
               dP=Pb-Pa
               dV=V-(1-x)*Va-x*Vb
               dE=E-(1-x)*Ea-x*Eb
       #  dérivées
               Pva=Pv(1/Va,Ea,phA)
               Pea=Pe(1/Va,Ea,phA)
               Tva=Tv(1/Va,Ea,phA)
               Tea=Te(1/Va,Ea,phA)
               Pvb=Pv(1/Vb,Eb,phB)
               Peb=Pe(1/Vb,Eb,phB)
               Tvb=Tv(1/Vb,Eb,phB)
               Teb=Te(1/Vb,Eb,phB)
               #println("[Pa  Pva  Pea  Ta  Tva  Tea] = ",[Pa  Pva  Pea  Ta  Tva  Tea]);
               #println("[Pb  Pvb  Peb  Tb  Tvb  Teb] = ",[Pb  Pvb  Peb  Tb  Tvb  Teb]);
               matA = [Pva            Pea            -Pvb          -Peb          0;
                       Tva            Tea            -Tvb          -Teb          0;
                       -Sa*Tva+Pva*Va -Sa*Tea+Pea*Va Sb*Tvb-Pvb*Vb Sb*Teb-Peb*Vb 0;
                       1-x            0              x             0             Vb-Va;
                       0              1-x            0             x             Eb-Ea]
               #println(matA)
       #Inversion de la matrice A 5x5  *)
               Ja = Pva*Tea - Pea*Tva ; 
               Jb = Pvb*Teb - Peb*Tvb;
               Jab = Pva*Teb - Pea*Tvb ; Jba = Pvb*Tea - Peb*Tva;
               Tba = Tva*Teb - Tea*Tvb ; Pba = Pva*Peb - Pea*Pvb ;
               dPa = Pea*DE + Pva*DV; dTa = Tea*DE + Tva*DV;
               dPb = Peb*DE + Pvb*DV; dTb = Teb*DE + Tvb*DV;
               DGa = DV*dPa - DS*dTa; DGb = DV*dPb - DS*dTb;
               dGa = dP*Va - dT*Sa; dGb = dP*Vb - dT*Sb;
               Wab = dTb*Pea - Tea*dPb; Wba = dTa*Peb - Teb*dPa;
               Zab = Tva*dPb - Pva*dTb; Zba = Tvb*dPa - Pvb*dTa;
               dPx = (Ja - Jab )*Va + (Jb - Jba )*Vb - DS*Tba;
               dTx = (Jba - Ja)*Sa + (Jab - Jb)*Sb - Pba*DV;
               dGx = Jba + Jab - Ja - Jb;
               DGva = DV*Pva - DS*Tva; DGea = DV*Pea - DS*Tea;
               DGvb = DV*Pvb - DS*Tvb; DGeb = DV*Peb - DS*Teb;
               J = (1 - x)*Jb + x*Ja;
               JGv = Jb*DGva*(1 - x) + DGvb*Ja*x; 
               JGe = Jb*DGea*(1 - x) + DGeb*Ja*x;
               det = Jb*DGa*(1 - x) + Ja*DGb*x;
       #  Solution
               Z11=          (1 - x)*Jb*DV*Vb + x*(Tea*DGb - Wab*Va) 
               Z12=         -(1 - x)*Jb*DV*Sb + x*(Wab*Sa - Pea*DGb) 
               Z13=         -(1 - x)*Jb*DV + x*Wab  
               Z14=        Jb*DGea*DE 
               Z15=        -Jb*DGea*DV
               Z21=         (1 - x)*DE*Jb*Vb - x*(Tva*DGb + Zab*Va) 
               Z22=         -(1 - x)*DE*Sb*Jb + x*(Sa*Zab + Pva*DGb) 
               Z23=         -(1 - x)*Jb*DE  + x*Zab 
               Z24=         -Jb*DGva*DE 
               Z25=         Jb*DGva*DV
               Z31=        -(1 - x)*(DGa*Teb + Wba*Vb)+ x*Ja*DV*Va  
               Z32=        (1 - x)*(Wba*Sb + DGa*Peb) - x*Ja*DV*Sa  
               Z33=        (1 - x)*Wba - x*Ja*DV  
               Z34=        Ja*DGeb*DE 
               Z35=        -Ja*DGeb*DV
               Z41=         (1 - x)*(Tvb*DGa - Zba*Vb) +   x*DE*Ja*Va  
               Z42=         (1 - x)*( Sb*Zba - Pvb*DGa) -  x*DE*Sa*Ja 
               Z43=         (1 - x)*Zba - x*Ja*DE  
               Z44=         -Ja*DGvb*DE 
               Z45=         Ja*DGvb*DV
               Z51=        -(1 - x)*Jb*Vb - x*Ja*Va + (1 - x)*x*dPx 
               Z52=         (1 - x)*Jb*Sb +  x*Ja*Sa + (1 - x)*x*dTx 
               Z53=         J + (1 - x)*x*dGx 
               Z54=         JGv 
               Z55=         JGe
               invA = [Z11 Z12 Z13 Z14 Z15;
                       Z21 Z22 Z23 Z24 Z25;
                       Z31 Z32 Z33 Z34 Z35;
                       Z41 Z42 Z43 Z44 Z45;
                       Z51 Z52 Z53 Z54 Z55]/det
               #println("invA= ",invA)  
               #println("det= ",det)      
               #println(matA .* invA)        
               Δ = [dP dT dG dV dE]
               #println("[dP dT dG dV dE]= ",Δ)
               δ = invA*Δ'
               δVa=δ[1] 
               δEa=δ[2] 
               δVb=δ[3] 
               δEb=δ[4] 
               δλ=δ[5]
               VA=Va+δVa 
               EA=Ea+δEa 
               VB=Vb+δVb 
               EB=Eb+δEb 
               λ=x+δλ
               #println("[δVa δEa δVb δEb δλ]= ",[δVa δEa δVb δEb δλ])
               return [VA EA VB EB λ]
end

function SolveMelNewton(V,E,phA,phB,NiterMax)
	Va=0.98*V
	Ea=E
	Vb=1.02*V
	Eb=E
	λ=0.5
	for i in 1:NiterMax
		sol=SolveMelNewtonIter(V,E,phA,phB,Va,Ea,Vb,Eb,λ)
		Va=sol[1]
		Ea=sol[2]
		Vb=sol[3]
		Eb=sol[4]
		λ =sol[5]
		#println([Va Ea Vb Eb λ])
	end
	return Va,Ea,Vb,Eb,λ
end

###################################################################
#	fonctions pour un seul matériau ou une seule phase
###################################################################
function Es(ρ)
		#  paramètres  ρ0,Ko,No,Eo
		x = 1 - ρ0/ρ
		Ko/ρ0*((exp((No+1)*x)-1)/(No+1)-x)/(No+1)+Eo
end

function Ps(ρ)
		#  paramètres  ρ0,Ko,No
		x = 1 - ρ0/ρ
		Ko*(exp((No+1)*x)-1)/(No+1)
end

function Psρ(ρ)
		#  paramètres  ρ0,Ko,No
		x = 1 - ρ0/ρ
		Ko*ρ0*exp((No+1)*x)/ρ/ρ
end

function Γρ(ρ)
		#  paramètres  Γo, ρ0 , Γ1
		Γo*ρ0 + Γ1*ρ
end

function θ(ρ)
		#  paramètres  ρ0,θo,Γo,Γ1
		x = 1 - ρ0 / ρ
		θo*exp(Γo*x)*(ρ/ρ0)^(Γ1)
end	

function Γ(ρ)
		#  paramètres  Γo, ρ0 , Γ1
		Γo*ρ0/ρ + Γ1
end

function Γρp(ρ)
		#  paramètres  Γo, ρ0 , Γ1
		Γ1
end

function Pρe(ρ,E)
	Ps(ρ)+Γρ(ρ)*(E-Es(ρ))
end

function Sρe(ρ,E)
	u=max((E-Es(ρ))/Cv/θ(ρ)+ur,0.0001)
	return So+Cv*log(u)
end	

function Tρe(ρ,E)
	u=ur+(E-Es(ρ))/Cv/θ(ρ)
	return θ(ρ)*u
end	

function Pv(ρ,E)
	-ρ^2*Psρ(ρ)-ρ^2*Γρp(ρ)*(E-Es(ρ))+Γρ(ρ)*Ps(ρ)
end

function Pe(ρ,E)
	Γρ(ρ)
end

function Tv(ρ,E)
	-ur*Γρ(ρ)*θ(ρ)+Ps(ρ)/Cv
end

function Te(ρ,E)
	1/Cv
end
#  Hugoniot
function Ph(ρ,Pole)
	Vo=1/Pole.ρ
	Po=Pole.P
	Eo=Pole.E
	V=1/ρ
	Γxρ=Γρ(ρ)
	num= Ps(ρ)+Γxρ*(Eo-Es(ρ)+Po*(Vo-V)/2)
	den=1-Γxρ*(Vo-V)/2
	return num/den
end

function Eh(ρ,Pole)
	Vo=1/Pole.ρ
	Po=Pole.P
	Eo=Pole.E
	V=1/ρ
	Γxρ=Γρ(ρ)
	num= Eo + (Ps(ρ)+Po-Γxρ*Es(ρ))*(Vo-V)/2
	den= 1-Γxρ*(Vo-V)/2
	return num/den
end

function Th(ρ,Pole)
	Tρe(ρ,Eh(ρ,Pole))
end

function Hugoniot(ρ,Pole,Phase)
           gr=Γρ(ρ,Phase)
           P1=Pρe(ρ,0,Phase)
           Ph=(P1+gr*(Pole.E+Pole.P*(1/Pole.ρ-1/ρ)))/(1. - gr*(1/Pole.ρ-1/ρ)/2)
           Eh=Pole.E+(Pole.P+Ph)*(1/Pole.ρ-1/ρ)/2
           u=sqrt((Ph-Pole.P)*(1/Pole.ρ-1/ρ))
           D=1/Pole.ρ*sqrt((Ph-Pole.P)/(1/Pole.ρ-1/ρ))
           return Ph,Eh,u,D
end

end # module
