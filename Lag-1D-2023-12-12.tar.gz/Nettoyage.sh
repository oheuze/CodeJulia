#!/usr/bin/bash

rm -r Matériaux/Essai-GP/build/*
rm -r Matériaux/Essai-Bz/build/*
rm -r Matériaux/Essai-MGC/build/*
rm -r Matériaux/Essai-Hybride/build/*
rm Test-Sod/*.dat	
rm Test-Sod/*.pdf	
rm Test-Sod/*.png
rm Test-Impact-Sn/*.dat	
rm Test-Impact-Sn/*.pdf
rm Test-Impact-Sn/*.png
rm Test-Bizarrium/*.dat	
rm Test-Bizarrium/*.pdf	
rm Test-Bizarrium/*.png
