global k=0
global nom
global test
for arg in ARGS 
	global k += 1
        if arg == "--help" || arg == "-h"
		println("")
		println("1D Lagrange hydrocode")
		println("")
		println("Usage:")
		println("")
		println(" -n nom ( pour lancer avec le fichier de données nom.XML )")
		println(" --help")
	end
        if arg == "-t"			global test=ARGS[k+1]	end
        if arg == "-n"			global nom=ARGS[k+1]	end
end
include("Init-Lag.jl")
Run()
println("Execution par défaut de Postprocessing.jl	 ->  figures")
include("PostProcessing.jl")
