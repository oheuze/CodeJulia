#include "EtatThermo.h" 

EtatThermo::EtatThermo(){} 
EtatThermo::~EtatThermo(){} 

EtatThermo::EtatThermo(double ρ,double E,double P,double T,double S,double c,double 𝒢){
		this->ρ=ρ;
		this->E=E;
		this->P=P;
		this->T=T;
		this->S=S;
		this->c=c;
		this->𝒢=𝒢;	
}   

void EtatThermo::ecrire(){
		cout <<	"	ρ = " << ρ ;
		cout <<	"	E = " << E ;
		cout <<	"	P = " << P ;
		cout <<	"	T = " << T ;
		cout <<	"	S = " << S ;
		cout <<	"	c = " << c ;
		cout <<	"	𝒢 = " << 𝒢 ;
		cout <<	 endl;
}

void EtatThermo::setZone(int n,string nom){
	zone=n;
	nomZone=nom;
}	
	
string EtatsToTag(vector<EtatThermo> &Etats){
	string tag="<EtatsThermo>\n";
	for (int i=0;i<Etats.size();i++){
		tag=tag+"	<EtatThermo  ";
		if ( Etats[i].zone >0) {
			tag=tag+" zone=\""+to_string(Etats[i].zone)+"\"";
			tag=tag+" phase=\""+Etats[i].nomZone+"\"";
		}
		tag=tag+" ρ=\""+to_string(Etats[i].ρ)+"\"";
		tag=tag+" E=\""+to_string(Etats[i].E)+"\"";
		tag=tag+" P=\""+to_string(Etats[i].P)+"\"";
		tag=tag+" T=\""+to_string(Etats[i].T)+"\"";
		tag=tag+" S=\""+to_string(Etats[i].S)+"\"";
		tag=tag+" c=\""+to_string(Etats[i].c)+"\"";
		tag=tag+" 𝒢=\""+to_string(Etats[i].𝒢)+"\"";
		tag=tag+"	/>\n";
	}
	tag=tag+"</EtatsThermo>\n";
	return tag;
}	

bool Egaux(EtatThermo EtatA,EtatThermo EtatB){
	bool egaux=true;
	if ( 2*abs(EtatA.ρ-EtatB.ρ)/(abs(EtatA.ρ)+abs(EtatB.ρ)+0.0000001)>0.01 ) egaux=false;
	if ( 2*abs(EtatA.E-EtatB.E)/(abs(EtatA.E)+abs(EtatB.E)+0.0000001)>0.01 ) egaux=false;
	return egaux;
}	 

