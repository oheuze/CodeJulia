#ifndef _POINT_   
#define _POINT_

#include <string> 
#include <iostream> 
#include <sstream> 

using namespace std; 

class PointXY 
{ 

protected: 

public: 

	PointXY(); 
	~PointXY(); 

	PointXY(double X,double Y); 
	PointXY(std::string chaine); 

	double x,y; 

	void ecrire(); 
}; 

#endif
