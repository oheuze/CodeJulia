#	OH- 27-11-2023
using Plots
include("../MateriauJ.jl")
include("../Thermo.jl")
cd("../Matériaux")
Sn = Materiau.Hybride("Sn-thèse-24x35.xml")
Materiau.detailler(Sn)
Materiau.LireDonnees(Sn,"Sn-thèse-24x35.xml")
cd("../Test-Impact-Sn")
println("Propriétés d'un impact Sn-Sn à 1000 m/s")
ρ0=Materiau.getVal(Sn,"ρ0")
pole=Etat(Sn,"Pôle",ρ0,0.0)
poleZone=Materiau.getVal(Sn,"zone")
println(pole)
ρvals=Vector{Float64}(undef, 30)
pH    =Vector{Float64}(undef, length(ρvals))
uHproj=Vector{Float64}(undef, length(ρvals))
uHcibl=Vector{Float64}(undef, length(ρvals))
Vproj=1000
ρ=ρ0;
dρ=50;
i=0;
pole1=pole
etatHug=pole
global past=false
global ρinf, ρsup
# Recherche du 2ème pôle, sur la ligne de mélange fin de phase Beta
while ( etatHug.u < Vproj-etatHug.u -60)
	global etatHug
	global pole
	global dρ;
	global i+=1;
	ρvals[i]=ρ;  
	pH[i]=etatHug.P
	uHproj[i]=Vproj-etatHug.u
	uHcibl[i]=etatHug.u
	# println("P = ",pH[i],"   ρ= ",ρ,"  uProj=  ",uHproj[i],"  uCibl= ",uHcibl[i]," ECibl= ",etatHug.E,"	",Materiau.getVal(Sn,"zone"))
	global ρinf=ρ
	global ρ+=dρ;
	global etatHug=Hugoniot(Sn,"Hug",pole,ρ)
	if ( (poleZone!=Materiau.getVal(Sn,"zone") ) && ( past==false ) )
		global  ρsup=ρ
		while ( abs(ρsup-ρinf)>1e-3 )
			ρ=(ρinf+ρsup)/2
			etatHug=Hugoniot(Sn,"Pole2",pole,ρ)
			global D1=D
			if ( poleZone!=Materiau.getVal(Sn,"zone") )
				ρsup=ρ
			else
				ρinf=ρ	
			end
		end
		println("Changement de pole : \n", etatHug)
		println("D = ", D1, " m/s")
		global past=true
		dρ=60
		pole=etatHug	
	end
	# println(i,"	",etatHug.u ,"	,	", Vproj-etatHug.u)
end
iend=i
pole2=pole
global EtatFinal=pole2
for i in 1:5
	local  dP=EtatFinal.ρ*EtatFinal.c*(500-EtatFinal.u)
	local  dρ=dP/EtatFinal.c/EtatFinal.c
	global EtatFinal=Hugoniot(Sn,"Etat final",pole2,EtatFinal.ρ+dρ)
end	
println("Etat final :")
println(EtatFinal)
D2=1/pole2.ρ*sqrt((EtatFinal.P-pole2.P)/(1/pole2.ρ-1/EtatFinal.ρ))
println("D = ", D2, " m/s")
AffEtats( [pole1 , pole2 , EtatFinal ])
ρvals[iend]=EtatFinal.ρ;  
pH[iend]=EtatFinal.P
uHproj[iend]=Vproj-EtatFinal.u
uHcibl[iend]=EtatFinal.u

resize!(ρvals,iend);resize!(pH,iend);resize!(uHproj,iend);resize!(uHcibl,iend)
plot(uHcibl,pH,xlabel="u (m/s)",ylabel="P (Pa)",label="Cible",title="Impact Sn-Sn à 1000 m/s")
figPu=plot!(uHproj,pH,label="Projectile")
figPρ=plot(ρvals,pH,xlabel="ρ (kg/m3)",ylabel="P (Pa)",label="Cible",title="Impact Sn-Sn à 1000 m/s")

xinterface=0.5
temps=6.0e-5
xg  = xinterface +(Vproj-D1)*temps
xcg = xinterface +(Vproj-(D2+pole2.u))*temps
xm  = xinterface +EtatFinal.u*temps
xcd = xinterface +(D2+pole2.u)*temps
xd  = xinterface +D1*temps
#vecx=[ 0      ,     0  , xg     , xg     ,     xg ,      xg ,      xm ,      xm ,      xm ,  xd     ,      xd ,      xd ,     xd ,     1  ,       1 ]
#vecρ=[ pole.ρ , pole.ρ , pole.ρ , pole.ρ , etatH.ρ , etatH.ρ , etatH.ρ , etatH.ρ , etatH.ρ , etatH.ρ , etatH.ρ , pole.ρ , pole.ρ , pole.ρ , pole.ρ  ]

vecx=[ 0      ,     0  , xg     , xg     ,     xg ,     xg ,     xcg ,    xcg ,      xcg ,     xcg ,      xm ,      xcd ,  xcd     ,   xcd     ,      xcd ,  xd     ,      xd ,     xd ,     xd ,     1  ,       1 ]
vecρ=[ pole1.ρ , pole1.ρ , pole1.ρ , pole1.ρ , pole2.ρ , pole2.ρ , pole2.ρ , pole2.ρ , EtatFinal.ρ , EtatFinal.ρ ,EtatFinal.ρ , EtatFinal.ρ ,  EtatFinal.ρ , pole2.ρ , pole2.ρ , pole2.ρ , pole2.ρ , pole1.ρ , pole1.ρ , pole1.ρ , pole1.ρ  ]
using Plots
nom="acoustic"
dirCas=pwd()
include("../PostProcessing.jl")
figρx = plot!(vecx,vecρ,label="Solution exacte multiphase",lc=:black)
include("../LagLib.jl")
#  Préparation du fichier .dat
nsol=length(vecx)-1;
xsol=zeros(Float64, nsol+1);
ρsol=zeros(Float64, nsol+1);
usol=zeros(Float64, nsol+1);
psol=zeros(Float64, nsol+1);
esol=zeros(Float64, nsol+1);
tsol=zeros(Float64, nsol+1);
csol=zeros(Float64, nsol+1);
gsol=zeros(Float64, nsol+1);
Ecritures("Solution exacte multiphase.dat",temps,vecx,vecρ,usol,psol,esol,tsol,csol,gsol,1,nsol)

println("Figures	: 	figPρ	,	figPu	,	figρx")
