#ifndef _LecteurDonnees_H 
#define _LecteurDonnees_H 

#include <string> 
#include <iostream> 
#include <vector> 
#include <map> 

using namespace std; 

class LecteurDonnees 
{ 
	public: 
	map <string,string> parametres;

	LecteurDonnees(){ };
	LecteurDonnees(std::string chaine){ cout << "LecteurDonnees " << chaine << endl;};

	virtual ~LecteurDonnees(){ };
	virtual int LireDonnees(std::string XMLfile){cout << "LecteurDonnees LireDonnees" << endl; return 0;} ;   
	virtual void ecrire(){cout << "LecteurDonnees ecrire" << endl;} ; 
	void setParam(std::string motclef, std::string valeur){
		parametres[motclef]=valeur;
	};
	
};

//extern "C" LecteurDonnees* creer() {	return new LecteurDonnees();	}
//extern "C" void detruire(LecteurDonnees* p){	delete p;	}

#endif 

