#include "LecteurMAT.hpp" 
	
LecteurMAT::LecteurMAT(){ 
	//cout <<" Appel de LecteurMAT "<< endl;
} 
	
LecteurMAT::~LecteurMAT(){} 

void LecteurMAT::ecrire(){ 
	cout << nom  << endl;
	//	cout <<" { ( "<< pt1.x <<" , "<< pt1.y <<" ) , ( "<< pt2.x <<" , " << pt2.y <<" ) } "; 
} 

int LecteurMAT::LireDonnees(std::string MATfile) { 
	if (details) 	{	cout <<" Lecteur MAT : détails activés" << endl; }
	else 		{	cout <<" Lecteur MAT : détails non activés" << endl;}
       	string egal="=";
	cout << "Fichier MAT : " << MATfile << endl; 
        ifstream fichier(MATfile, ios::in);  // on ouvre en lecture
        if(fichier)  // si l'ouverture a fonctionné
        {
                string ligne;
        	while(getline(fichier, ligne))  // tant que la ligne existe
        	{
                	if (details) cout << ligne << " :	";  // on l'affiche
                	std::size_t found = ligne.find(egal);
                	string nom = trim(ligne.substr(0,found-1));
                	string valeur =  trim(ligne.substr(found+1,ligne.length()));
                	if (details) cout << nom << " ==> " << valeur << endl;
                	parametres[nom]=valeur;
        	}
                fichier.close();
        }
        else
                cerr << "Impossible d'ouvrir le fichier !" << endl;
        cout << endl ; 
	return 0;
} 

