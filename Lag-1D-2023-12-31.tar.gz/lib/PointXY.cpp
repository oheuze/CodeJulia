#include "PointXY.h"   

PointXY::PointXY(){x=0;y=0; } 
PointXY::~PointXY(){  }

PointXY::PointXY(double X,double Y){ x=X;y=Y; } 

PointXY::PointXY(std::string chaine)
{
	std::string pbeg="("; std::string pmid=","; std::string pend=")"; 
	std::string strX=chaine.substr(chaine.find(pbeg)+1,chaine.find(pmid)-chaine.find(pbeg)-1); 
	std::string strY=chaine.substr(chaine.find(pmid)+1,chaine.find(pend)-chaine.find(pmid)-1); 
	x=atof(strX.c_str()); 
	y=atof(strY.c_str()); 
} 
 
void PointXY::ecrire() { 
	cout << "  (  " << x << " , " << y << " ) " << endl; 
}

